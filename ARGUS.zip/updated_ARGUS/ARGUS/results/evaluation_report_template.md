# ARGUS Evaluation Report Template

## Study Setup

- Floor plan:
- Activity goal:
- Constraints:
- ARGUS run timestamp:
- Expert reviewer:

## Deployment Efficiency

| Planner | Time to final plan (seconds) | Notes |
| --- | ---: | --- |
| ARGUS |  |  |
| Human expert |  |  |

## Coverage and Feasibility

| Metric | ARGUS | Expert | Notes |
| --- | ---: | ---: | --- |
| Coverage percent |  |  | Percent of recommended active zones covered |
| Average feasibility |  |  | Deterministic score from placement, constraints, and occlusion |
| Average occlusion risk |  |  | Lower is better |
| Constraint violations |  |  | Restricted sensor/area violations |
| Sensor count |  |  | Unique sensor type + segment + location |

## Recognition Accuracy

| Activity | Sensor layout | Precision | Recall | F1-score | Notes |
| --- | --- | ---: | ---: | ---: | --- |
|  | ARGUS |  |  |  |  |
|  | Expert |  |  |  |  |

## Qualitative Findings

- Strengths:
- Failure cases:
- Expert disagreements:
- Changes needed before deployment:

## Conclusion

Summarize whether ARGUS reduced planning effort while producing a physically feasible deployment plan.
