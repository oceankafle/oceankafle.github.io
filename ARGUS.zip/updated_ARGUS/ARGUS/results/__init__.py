"""
ArgusSense Results module.
Stores execution results from the Agent system.
"""

