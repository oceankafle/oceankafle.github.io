# ARGUS – Automated Sensor Deployment & Activity Analysis

ARGUS is an agent-based system for automated sensor deployment planning and activity analysis. It combines LLM/VLM backends with a Streamlit web UI for floor-plan upload, room editing, activity sequence analysis, sensor grounding, physically grounded placement, and deployment evaluation.

## Project Structure

```
ARGUS/
├── agent/                    # Agent core logic
│   ├── activity_analysis/    # Activity analysis pipeline
│   │   ├── manager_agent.py       # Orchestrates analysis flow
│   │   ├── vision_agent.py        # VLM-based image understanding
│   │   ├── spatial_anchor_agent.py
│   │   ├── behavior_analysis_agent.py
│   │   └── verify_agent.py        # Activity sequence verification
│   ├── sensor_deployment/    # Sensor deployment planning
│   │   ├── deployment_manager_agent.py
│   │   ├── segment_agent.py
│   │   └── deployment_agent.py
│   ├── sensor_grounding/     # Sensor suggestion & verification
│   │   ├── grounding_manager_agent.py
│   │   ├── sensor_suggestion_agent.py
│   │   └── sensor_verifier_agent.py
│   ├── llm/                  # LLM clients (GPT, DeepSeek, OpenRouter, Gemini)
│   ├── vlm/                  # VLM clients (Qwen, LLaVA/custom, Gemini, NVIDIA/OpenRouter)
│   ├── sensor_specs.py       # Sensor catalog loading, aliases, and constraint filtering
│   ├── physical_planning.py  # Coordinate placement, coverage, occlusion, feasibility scoring
│   ├── factory.py            # get_llm() / get_vlm() by name
│   └── utils.py
├── interface/                # Streamlit web UI
│   ├── app.py                # Entry point, page routing
│   ├── ui/                   # Panels and layout
│   │   ├── chat_panel.py         # Activity analysis chat
│   │   ├── activity_results.py   # Activity list / results
│   │   ├── image_panel.py        # Floor plan upload
│   │   ├── room_editor.py        # Room & object editing
│   │   ├── grounding_panel.py    # Sensor grounding page
│   │   ├── sidebar.py             # Page selector, settings
│   │   └── styles.py
│   ├── services/             # Storage, vision
│   └── utils/
├── prompt/                   # Agent prompt templates
│   ├── prompt_manager.py     # Load/render Jinja2 prompts
│   └── templates/
│       ├── activity_analysis/
│       ├── sensor_deployment/
│       └── sensor_grounding/
├── data/                     # Stored data, sensor specs, evaluation cases
├── results/                  # Execution output
├── scripts/                  # Test and dev scripts
│   ├── test_agent.py
│   ├── test_gpt.py
│   ├── test_deepseek.py
│   ├── test_qwen_vlm.py
│   ├── test_llm_messages.py
│   ├── test_manager_agent.py
│   ├── test_vision_agent.py
│   ├── test_prompt_manager.py
│   └── ...
├── requirements.txt
├── .env.example              # Environment variables template
└── README.md
```

## Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Configure Environment Variables

Copy `.env.example` to `.env` and fill in your API keys and settings:

```bash
cp .env.example .env
```

Edit `.env` and set at least one of:

- **LLM**: `OPENAI_*` / Azure OpenAI, `DEEPSEEK_API_KEY`, `OPENROUTER_API_KEY`, or `GEMINI_API_KEY`
- **VLM** (for activity analysis from images): `DASHSCOPE_API_KEY` (Qwen-VL), `REMOTE_VLM_*`, `GEMINI_API_KEY`, or `NVIDIA_API_KEY`

### 3. Run the Web Interface

```bash
streamlit run interface/app.py
```

The app exposes three main pages:

- **Activity Analysis** – Upload a floor plan, chat to generate/verify activity sequences, edit rooms and objects.
- **Sensor Grounding** – Sensor suggestion and verification workflows.
- **Sensor Deployment** – Segmentation, coordinate placement, coverage/occlusion scoring, and floor-plan overlays.

## Features

- **Activity Analysis** – VLM-based understanding of floor plans, LLM-driven activity sequence generation and verification, spatial anchors and behavior analysis.
- **Sensor Deployment** – Segmentation, deployment planning, coordinate estimates, FOV/range-derived coverage scores, occlusion risk, and feasibility summaries.
- **Sensor Grounding** – Suggest and verify sensors against environment, activities, user constraints, and `data/sensor_specs.json`.
- **Multi-backend** – LLMs: GPT (Azure/OpenAI), DeepSeek, OpenRouter, Gemini. VLMs: Qwen (DashScope), LLaVA/custom, Gemini, NVIDIA/OpenRouter.
- **Web UI** – Streamlit app with image upload, room editor, chat panel, and result views.
- **Prompt system** – Jinja2 templates under `prompt/templates/` for all agent prompts.

## Environment Variables (summary)

| Purpose   | Variables |
|----------|-----------|
| OpenAI   | `OPENAI_API_KEY`, `OPENAI_API_BASE`, … |
| Azure OpenAI | `AZURE_OPENAI_*`, `AZURE_OPENAI_VLM_DEPLOYMENT_NAME` |
| DeepSeek | `DEEPSEEK_API_KEY`, `DEEPSEEK_API_BASE`, `DEEPSEEK_MODEL` |
| OpenRouter | `OPENROUTER_API_KEY`, `OPENROUTER_ENDPOINT`, `OPENROUTER_MODEL` |
| Gemini | `GEMINI_API_KEY`, `GEMINI_MODEL`, `GEMINI_VLM_MODEL` |
| Qwen-VL  | `DASHSCOPE_API_KEY`, `DASHSCOPE_API_BASE`, `DASHSCOPE_MODEL` |
| NVIDIA/OpenRouter VLM | `NVIDIA_API_KEY`, `NVIDIA_MODEL`, `NVIDIA_API_BASE` |
| Remote VLM | `REMOTE_VLM_API_BASE`, `REMOTE_VLM_API_KEY`, `REMOTE_VLM_MODEL` |
| App      | `APP_NAME`, `APP_ENV`, `DEBUG`, `LOG_LEVEL` |

See `.env.example` for the full list.

## Development

### Agent (`agent/`)

- **activity_analysis** – Manager, vision, spatial anchor, behavior analysis, and verify agents; used by the Activity Analysis page.
- **sensor_deployment** – Segment, deployment, and deployment-manager agents for sensor placement planning.
- **sensor_grounding** – Grounding manager, sensor suggestion, and sensor verifier.
- **sensor_specs.py** – Loads the curated sensor catalog and enforces restricted sensor/area constraints.
- **physical_planning.py** – Enriches VLM recommendations with approximate coordinates, mounting height, coverage, occlusion, and feasibility metrics.
- **llm** – Base LLM interface and clients (GPT, DeepSeek, OpenRouter, Gemini).
- **vlm** – Base VLM interface and clients (Qwen, custom/LLaVA, Gemini, NVIDIA/OpenRouter).
- **factory** – `get_llm(name)`, `get_vlm(name)` for creating clients by name.

### Interface (`interface/`)

- **app.py** – Streamlit entry; routes to Activity Analysis or Sensor Grounding based on sidebar.
- **ui/** – Chat panel, activity results, image panel, room editor, grounding panel, sidebar, styles.
- **services/** – Storage (e.g. environment/activity data), vision-related helpers.
- **utils/** – Image and normalization utilities.

### Prompts (`prompt/`)

- **prompt_manager.py** – Loads and renders Markdown/Jinja2 templates from `templates/`.
- **templates/** – One directory per domain (`activity_analysis/`, `sensor_deployment/`, `sensor_grounding/`) with `.md` templates used by the agents.

### Data & Results

- **data/** – Persistent data (`activity_analysis.json`), curated sensor specifications (`sensor_specs.json`), and evaluation scenarios (`evaluation_cases.json`).
- **results/** – Output from agent runs and `evaluation_report_template.md`.

### Scripts (`scripts/`)

- **test_agent.py** – End-to-end agent (LLM/VLM, sync/async, streaming).
- **test_gpt.py**, **test_deepseek.py** – LLM client tests.
- **test_qwen_vlm.py** – Qwen VLM client tests.
- **test_llm_messages.py** – Multi-turn message-format tests.
- **test_manager_agent.py**, **test_vision_agent.py**, **test_prompt_manager.py**, etc. – Module-level tests.

Run from project root, e.g.:

```bash
python scripts/test_agent.py
python scripts/test_deepseek.py
python scripts/evaluate_argus.py
python scripts/evaluate_argus.py --write
```

## License

TBD
