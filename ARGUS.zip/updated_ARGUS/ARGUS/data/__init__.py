"""
ArgusSense Data module.
Stores and manages data related to sensor deployment.
"""

