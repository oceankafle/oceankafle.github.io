import google.genai as genai
import os
from dotenv import load_dotenv
from pathlib import Path

load_dotenv(Path('.env'), override=True)

client = genai.Client(api_key=os.getenv("GEMINI_API_KEY"))

for model in client.models.list():
    print(model.name)