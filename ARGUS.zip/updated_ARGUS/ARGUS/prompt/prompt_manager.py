"""
Prompt Manager
Manages prompt templates using Jinja2 for rendering
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Optional
from jinja2 import Environment, FileSystemLoader, Template, TemplateNotFound, TemplateError, meta, select_autoescape

from dotenv import load_dotenv

# Load environment variables
_REPO_ROOT = Path(__file__).resolve().parents[1]
load_dotenv(Path('.env'), override=True)


def _repo_root() -> Path:
    """Get the repository root directory"""
    return Path(__file__).resolve().parents[1]


class PromptManager:
    """
    Prompt Manager for loading and rendering Jinja2 templates
    
    Examples:
        # Initialize with custom template directory
        manager = PromptManager(template_dir="prompt/templates")
        
        # Render a template
        rendered = manager.render("my_template", name="Alice", age=30)
        
        # Get template content
        content = manager.get_template_content("my_template")
    """
    
    def __init__(
        self,
        template_dir: Optional[str | Path] = None,
        auto_reload: bool = False,
    ):
        """
        Initialize PromptManager
        
        Args:
            template_dir: Directory containing template files (default: prompt/templates relative to repo root)
            auto_reload: Whether to auto-reload templates on change (useful for development)
        """
        if template_dir is None:
            # Default to prompt/templates directory
            template_dir = _repo_root() / "prompt" / "templates"
        
        self.template_dir = Path(template_dir)
        
        # Create template directory if it doesn't exist
        self.template_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize Jinja2 environment
        self.env = Environment(
            loader=FileSystemLoader(str(self.template_dir)),
            auto_reload=auto_reload,
            autoescape=select_autoescape(),
            trim_blocks=True,
            lstrip_blocks=True,
        )
        
        # Cache for template paths and required variables
        self._template_path_cache: dict[str, str] = {}
        self._required_vars_cache: dict[str, set[str]] = {}
    
    def get_template_path(self, template_name: str) -> Path:
        """
        Get the full path to a template file
        
        Args:
            template_name: Name of the template (without extension)
        
        Returns:
            Path to the template file
        """
        # Try common extensions
        for ext in [".md", ".txt", ".j2", ".jinja2", ".jinja", ""]:
            template_path = self.template_dir / f"{template_name}{ext}"
            if template_path.exists():
                return template_path
        
        # Return default path if not found
        return self.template_dir / f"{template_name}.md"
    
    def template_exists(self, template_name: str) -> bool:
        """
        Check if a template exists
        
        Args:
            template_name: Name of the template
        
        Returns:
            True if template exists, False otherwise
        """
        template_path = self.get_template_path(template_name)
        return template_path.exists()
    
    def get_template(self, template_name: str) -> Template:
        """
        Get a Jinja2 Template object
        
        Args:
            template_name: Name of the template
        
        Returns:
            Jinja2 Template object
        
        Raises:
            TemplateNotFound: If template doesn't exist
        """
        try:
            # Try common extensions
            for ext in [".md", ".txt", ".j2", ".jinja2", ".jinja", ""]:
                try:
                    return self.env.get_template(f"{template_name}{ext}")
                except TemplateNotFound:
                    continue
            
            # If none found, raise error
            raise TemplateNotFound(template_name)
        except TemplateNotFound as e:
            raise TemplateNotFound(
                f"Template '{template_name}' not found in {self.template_dir}. "
                f"Available templates: {self.list_templates()}"
            ) from e
    
    def get_template_content(self, template_name: str) -> str:
        """
        Get the raw content of a template without rendering
        
        Args:
            template_name: Name of the template
        
        Returns:
            Raw template content as string
        """
        template_path = self.get_template_path(template_name)
        if not template_path.exists():
            raise FileNotFoundError(
                f"Template '{template_name}' not found at {template_path}"
            )
        return template_path.read_text(encoding="utf-8")
    
    def render(
        self,
        template_name: str,
        **kwargs: Any
    ) -> str:
        """
        Render a template with the given variables
        
        Args:
            template_name: Name of the template to render
            **kwargs: Variables to pass to the template
        
        Returns:
            Rendered template as string
        
        Raises:
            TemplateNotFound: If template doesn't exist
            TemplateError: If template rendering fails
        """
        try:
            template = self.get_template(template_name)
            return template.render(**kwargs)
        except TemplateError as e:
            raise TemplateError(
                f"Error rendering template '{template_name}': {e}"
            ) from e
    
    def list_templates(self) -> list[str]:
        """
        List all available templates in the template directory
        
        Returns:
            List of template names (without extensions)
        """
        templates = []
        if not self.template_dir.exists():
            return templates
        
        # Supported extensions
        extensions = [".md", ".txt", ".j2", ".jinja2", ".jinja"]
        
        for file_path in self.template_dir.iterdir():
            if file_path.is_file():
                # Remove extension if it's a template extension
                name = file_path.stem
                if file_path.suffix in extensions:
                    # Check if there's a double extension (e.g., .md.j2)
                    if name.endswith(tuple(extensions)):
                        # Remove the template extension too
                        for ext in extensions:
                            if name.endswith(ext):
                                name = name[:-len(ext)]
                                break
                    templates.append(name)
        
        return sorted(set(templates))
    
    def resolve_template_path(self, template_name: str) -> str:
        """
        Resolve template name to relative path within template directory
        
        Args:
            template_name: Name of the template (may include subdirectory, e.g., "subdir/template")
        
        Returns:
            Relative path to the template file
        """
        # Check cache first
        if template_name in self._template_path_cache:
            return self._template_path_cache[template_name]
        
        # Try to find the template with various extensions
        base_path = Path(template_name)
        extensions = [".md", ".txt", ".j2", ".jinja2", ".jinja", ""]
        
        for ext in extensions:
            candidate = base_path.with_suffix(ext) if ext else base_path
            full_path = self.template_dir / candidate
            
            if full_path.exists() and full_path.is_file():
                rel_path = str(candidate)
                self._template_path_cache[template_name] = rel_path
                return rel_path
        
        # If not found, return the original name with .md extension as default
        rel_path = f"{template_name}.md"
        self._template_path_cache[template_name] = rel_path
        return rel_path
    
    def get_required_variables(self, template_name: str) -> set[str]:
        """
        Get the set of required variables for a template
        
        Args:
            template_name: Name of the template
        
        Returns:
            Set of required variable names
        """
        rel_path = self.resolve_template_path(template_name)
        
        # Check cache
        if rel_path in self._required_vars_cache:
            return self._required_vars_cache[rel_path].copy()
        
        try:
            # Get template source
            template_source, _, _ = self.env.loader.get_source(self.env, rel_path)
            
            # Parse template and find undeclared variables
            parsed = self.env.parse(template_source)
            required = set(meta.find_undeclared_variables(parsed))
            
            # Cache the result
            self._required_vars_cache[rel_path] = required
            return required.copy()
        except TemplateNotFound:
            # If template not found, return empty set
            return set()
    
    def render(
        self,
        template_name: str,
        *,
        validate: bool = True,
        optional_variables: Optional[set[str]] = None,
        **kwargs: Any
    ) -> str:
        """
        Render a template with the given variables
        
        Args:
            template_name: Name of the template to render
            validate: Whether to validate that all required variables are provided
            optional_variables: Set of variable names that are optional (will be set to empty string if missing)
            **kwargs: Variables to pass to the template
        
        Returns:
            Rendered template as string
        
        Raises:
            TemplateNotFound: If template doesn't exist
            TemplateError: If template rendering fails
            ValueError: If required variables are missing (when validate=True)
        """
        rel_path = self.resolve_template_path(template_name)
        
        try:
            template = self.env.get_template(rel_path)
        except TemplateNotFound as e:
            raise TemplateNotFound(
                f"Template '{template_name}' not found in {self.template_dir}. "
                f"Available templates: {self.list_templates()}"
            ) from e
        
        # Validate required variables if requested
        if validate:
            required = self.get_required_variables(template_name)
            provided = set(kwargs.keys())
            missing = required - provided
            
            # Handle optional variables
            if optional_variables:
                optional_missing = missing & optional_variables
                for var in optional_missing:
                    kwargs[var] = ""
                missing = missing - optional_missing
            
            if missing:
                raise ValueError(
                    f"Missing required template variables: {missing}\n"
                    f"Required: {required}\n"
                    f"Provided: {provided}"
                )
        
        try:
            return template.render(**kwargs)
        except TemplateError as e:
            raise TemplateError(
                f"Error rendering template '{template_name}': {e}"
            ) from e
    
    def validate_template(self, template_name: str, **kwargs: Any) -> dict[str, Any]:
        """
        Validate that a template can be rendered with the given variables
        
        Args:
            template_name: Name of the template
            **kwargs: Variables to validate
        
        Returns:
            Dict with 'valid' (bool) and 'errors' (list of error messages)
        """
        try:
            required = self.get_required_variables(template_name)
            provided = set(kwargs.keys())
            missing = required - provided
            
            if missing:
                return {
                    "valid": False,
                    "errors": [f"Missing required variables: {missing}"]
                }
            
            # Try to render
            self.render(template_name, validate=False, **kwargs)
            return {"valid": True, "errors": []}
        except TemplateError as e:
            return {"valid": False, "errors": [str(e)]}
        except Exception as e:
            return {"valid": False, "errors": [f"Unexpected error: {e}"]}


# Create a default manager instance
_manager_instance: Optional[PromptManager] = None


def get_manager() -> PromptManager:
    """
    Get the default PromptManager instance (singleton)
    
    Returns:
        Default PromptManager instance
    """
    global _manager_instance
    if _manager_instance is None:
        _manager_instance = PromptManager()
    return _manager_instance


# Export the default manager instance
manager = get_manager()

