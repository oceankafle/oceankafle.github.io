# Example Prompt Template

Hello {{ name }}!

This is an example prompt template using Jinja2 syntax.

{% if age %}
You are {{ age }} years old.
{% endif %}

{% if items %}
Here are your items:
{% for item in items %}
- {{ item }}
{% endfor %}
{% endif %}

Thank you for using our service!

