"""
Unified client factory.
Creates LLM or VLM client instances by name.
"""

from __future__ import annotations

from typing import Any

from .llm.base_llm import LLM
from .vlm.base_vlm import VLM

def get_llm(llm_type: str, **kwargs: Any) -> LLM:
    """Factory function to construct an LLM client by type name."""
    t = (llm_type or "").strip().lower()

    if t == "deepseek":
        from .llm.deepseek_client import DeepSeekClient as cls
    elif t == "gpt":
        from .llm.gpt_client import GPTClient as cls
    elif t == "openrouter":
        from .llm.openrouter_client import OpenRouterClient as cls
    elif t == "gemini":
        from .llm.gemini_client import GeminiClient as cls
    else:
        raise ValueError(f"Unsupported LLM type: {llm_type}")
    return cls(**kwargs)  # type: ignore[call-arg]


def get_vlm(vlm_type: str, **kwargs: Any) -> VLM:
    """Factory function to construct a VLM client by type name."""
    t = (vlm_type or "").strip().lower()

    if t == "qwen":
        from .vlm.qwen_client import QwenClient as cls
    elif t == "llava":
        from .vlm.custom_client import CustomClient as cls
    elif t == "gemini":
        from .vlm.gemini_client import GeminiVLMClient as cls
    elif t == "nvidia":
        from .vlm.nvidia_client import NVIDIAClient as cls
    elif t == "gpt":
        from .vlm.gpt_vlm import AzureOpenAIVLMClient as cls
    else:
        raise ValueError(f"Unsupported VLM type: {vlm_type}")
    return cls(**kwargs)  # type: ignore[call-arg]
