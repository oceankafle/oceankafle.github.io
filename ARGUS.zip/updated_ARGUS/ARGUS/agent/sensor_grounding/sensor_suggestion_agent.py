"""
Sensor Suggestion Agent
Recommends sensors and installation areas for behaviors in activity sequences
"""

from __future__ import annotations

import json
from typing import Any, Optional

from ..llm.base_llm import LLM
from ..factory import get_llm
from ..utils import load_activity_analysis, parse_json_response
from ..sensor_specs import apply_sensor_constraints, load_sensor_specs
from prompt import manager as prompt_manager


class SensorSuggestionAgent:
    """
    Sensor Suggestion Agent for sensor deployment
    
    Recommends sensors and installation areas based on activity sequences and constraints
    """

    def __init__(
        self,
        *,
        llm_name: str = "gemini",
        llm_kwargs: Optional[dict[str, Any]] = None,
        template_name: str = "sensor_grounding/sensor_suggestion",
    ):
        self.llm_name = llm_name
        self.llm_kwargs = llm_kwargs or {}
        self.template_name = template_name
        self._llm_client: Optional[LLM] = None

    def _get_llm_client(self) -> LLM:
        """Get or create LLM client"""
        if self._llm_client is None:
            self._llm_client = get_llm(self.llm_name, **self.llm_kwargs)
        return self._llm_client

    async def suggest(
        self,
        *,
        constraints: dict[str, Any],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        """
        Generate sensor suggestions for activities
        
        Args:
            constraints: Deployment constraints from grounding manager
            temperature: Temperature for LLM generation
            max_tokens: Maximum tokens for LLM response
        
        Returns:
            List of sensor suggestions for each activity
        """
        # Load current data
        data = load_activity_analysis()
        environment_info = data.get("environment_info", {})
        activities = data.get("activities", [])

        # Filter activities that have sequences
        activities_with_sequences = [
            act for act in activities if act.get("sequence") and len(act.get("sequence", [])) > 0
        ]

        if not activities_with_sequences:
            return []

        # Render prompt template
        prompt = prompt_manager.render(
            self.template_name,
            activities_with_sequences=json.dumps(activities_with_sequences, indent=2, ensure_ascii=False),
            constraints=json.dumps(constraints, indent=2, ensure_ascii=False),
            environment_info=json.dumps(environment_info, indent=2, ensure_ascii=False),
            sensor_catalog=json.dumps(load_sensor_specs(), indent=2, ensure_ascii=False),
        )

        # Get LLM client and generate suggestions
        llm = self._get_llm_client()
        response = await llm.chat(
            prompt=prompt,
            temperature=temperature,
            max_tokens=max_tokens,
        )

        # Parse JSON response
        result = parse_json_response(response)

        # Validate structure
        if not isinstance(result, dict):
            raise ValueError("Response must be a dictionary")

        if "sensor_suggestions" not in result:
            raise ValueError("Response missing required field: 'sensor_suggestions'")

        sensor_suggestions = result["sensor_suggestions"]
        if not isinstance(sensor_suggestions, list):
            raise ValueError("sensor_suggestions must be a list")

        # Validate each suggestion structure
        for i, suggestion in enumerate(sensor_suggestions):
            if not isinstance(suggestion, dict):
                raise ValueError(f"Suggestion at index {i} must be a dictionary")

            required_fields = ["activity_id", "activity_description", "behavior_sensors"]
            for field in required_fields:
                if field not in suggestion:
                    raise ValueError(f"Suggestion at index {i} missing required field: {field}")

            behavior_sensors = suggestion["behavior_sensors"]
            if not isinstance(behavior_sensors, list):
                raise ValueError(f"Suggestion at index {i} behavior_sensors must be a list")

            # Validate each behavior sensor
            for j, behavior_sensor in enumerate(behavior_sensors):
                if not isinstance(behavior_sensor, dict):
                    raise ValueError(
                        f"Suggestion at index {i}, behavior_sensor at index {j} must be a dictionary"
                    )

                required_behavior_fields = [
                    "behavior",
                    "sensor_type",
                    "installation_area",
                    "installation_location",
                    "rationale",
                ]
                for field in required_behavior_fields:
                    if field not in behavior_sensor:
                        raise ValueError(
                            f"Suggestion at index {i}, behavior_sensor at index {j} missing required field: {field}"
                        )

        return apply_sensor_constraints(sensor_suggestions, constraints)

    async def close(self) -> None:
        """Close LLM client"""
        if self._llm_client is not None:
            await self._llm_client.close()
            self._llm_client = None
