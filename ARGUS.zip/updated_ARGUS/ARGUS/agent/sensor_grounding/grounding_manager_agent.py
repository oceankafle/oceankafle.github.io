"""
Grounding Manager Agent
Interacts with users to determine sensor deployment constraints
"""

from __future__ import annotations

import json
from typing import Any, Optional

from ..llm.base_llm import LLM
from ..factory import get_llm
from ..utils import load_activity_analysis, parse_json_response
from prompt import manager as prompt_manager


class GroundingManagerAgent:
    """
    Grounding Manager Agent for sensor deployment
    
    Interacts with users to determine constraints for sensor deployment
    """

    def __init__(
        self,
        *,
        llm_name: str = "gemini",
        llm_kwargs: Optional[dict[str, Any]] = None,
        template_name: str = "sensor_grounding/grounding_manager",
    ):
        self.llm_name = llm_name
        self.llm_kwargs = llm_kwargs or {}
        self.template_name = template_name
        self._llm_client: Optional[LLM] = None

    def _get_llm_client(self) -> LLM:
        """Get or create LLM client"""
        if self._llm_client is None:
            self._llm_client = get_llm(self.llm_name, **self.llm_kwargs)
        return self._llm_client

    async def analyze_constraints(
        self,
        *,
        user_requirements: str,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> dict[str, Any]:
        """
        Analyze user requirements and determine sensor deployment constraints
        
        Args:
            user_requirements: User's requirements for sensor deployment
            temperature: Temperature for LLM generation
            max_tokens: Maximum tokens for LLM response
        
        Returns:
            Dictionary containing deployment constraints
        """
        # Load current data
        data = load_activity_analysis()
        environment_info = data.get("environment_info", {})
        activities = data.get("activities", [])
        current_constraints = data.get("constraints", {}) or {}

        # Render prompt template
        prompt = prompt_manager.render(
            self.template_name,
            user_requirements=user_requirements,
            current_constraints=json.dumps(current_constraints, indent=2, ensure_ascii=False),
            environment_info=json.dumps(environment_info, indent=2, ensure_ascii=False),
            activities=json.dumps(activities, indent=2, ensure_ascii=False),
        )

        # Get LLM client and analyze
        llm = self._get_llm_client()
        response = await llm.chat(
            prompt=prompt,
            temperature=temperature,
            max_tokens=max_tokens,
        )

        # Parse JSON response
        result = parse_json_response(response)

        # Validate structure
        if not isinstance(result, dict):
            raise ValueError("Response must be a dictionary")

        if "constraints" not in result:
            raise ValueError("Response missing required field: 'constraints'")

        constraints = result["constraints"]
        if not isinstance(constraints, dict):
            raise ValueError("constraints must be a dictionary")

        # Validate constraint categories (optional, but check structure if present)
        constraint_categories = [
            "privacy",
            "budget",
            "installation",
            "coverage",
            "sensor_preferences",
            "general_notes",
        ]
        for category in constraint_categories:
            if category in constraints and constraints[category] is not None:
                if not isinstance(constraints[category], dict) and category != "general_notes":
                    raise ValueError(f"constraints.{category} must be a dictionary or null")

        return result

    async def close(self) -> None:
        """Close LLM client"""
        if self._llm_client is not None:
            await self._llm_client.close()
            self._llm_client = None

