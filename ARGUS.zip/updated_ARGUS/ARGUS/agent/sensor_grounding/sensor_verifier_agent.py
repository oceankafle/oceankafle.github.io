"""
Sensor Verifier Agent
Verifies and adjusts sensor deployment suggestions using floor plan analysis
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

from ..vlm.base_vlm import VLM
from ..factory import get_vlm
from ..utils import load_activity_analysis, parse_json_response
from ..sensor_specs import apply_sensor_constraints
from prompt import manager as prompt_manager


class SensorVerifierAgent:
    """
    Sensor Verifier Agent for sensor deployment
    
    Verifies and adjusts sensor suggestions by analyzing floor plan images
    """

    def __init__(
        self,
        *,
        vlm_name: str = "nvidia",
        vlm_kwargs: Optional[dict[str, Any]] = None,
        template_name: str = "sensor_grounding/sensor_verifier",
    ):
        self.vlm_name = vlm_name
        self.vlm_kwargs = vlm_kwargs or {}
        self.template_name = template_name
        self._vlm_client: Optional[VLM] = None

    def _get_vlm_client(self) -> VLM:
        """Get or create VLM client"""
        if self._vlm_client is None:
            self._vlm_client = get_vlm(self.vlm_name, **self.vlm_kwargs)
        return self._vlm_client

    async def verify(
        self,
        *,
        sensor_suggestions: list[dict[str, Any]],
        constraints: dict[str, Any],
        image_path: Path,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        """
        Verify and adjust sensor suggestions using floor plan analysis
        
        Args:
            sensor_suggestions: Sensor suggestions from sensor suggestion agent
            constraints: Deployment constraints
            image_path: Path to the floor plan image
            temperature: Temperature for VLM generation
            max_tokens: Maximum tokens for VLM response
        
        Returns:
            List of verified and adjusted sensor suggestions
        """
        if not image_path.exists():
            raise FileNotFoundError(f"Image not found: {image_path}")

        # Load environment info
        data = load_activity_analysis()
        environment_info = data.get("environment_info", {})

        # Render prompt template
        prompt = prompt_manager.render(
            self.template_name,
            sensor_suggestions=json.dumps(sensor_suggestions, indent=2, ensure_ascii=False),
            constraints=json.dumps(constraints, indent=2, ensure_ascii=False),
            environment_info=json.dumps(environment_info, indent=2, ensure_ascii=False),
        )

        # Get VLM client and verify
        vlm = self._get_vlm_client()
        response = await vlm.chat(
            prompt=prompt,
            image_paths=[image_path],
            temperature=temperature,
            max_tokens=max_tokens,
        )

        # Parse JSON response
        result = parse_json_response(response)

        # Validate structure
        if not isinstance(result, dict):
            raise ValueError("Response must be a dictionary")

        if "verified_sensor_suggestions" not in result:
            raise ValueError("Response missing required field: 'verified_sensor_suggestions'")

        verified_suggestions = result["verified_sensor_suggestions"]
        if not isinstance(verified_suggestions, list):
            raise ValueError("verified_sensor_suggestions must be a list")

        # Validate each verified suggestion structure
        for i, suggestion in enumerate(verified_suggestions):
            if not isinstance(suggestion, dict):
                raise ValueError(f"Verified suggestion at index {i} must be a dictionary")

            required_fields = ["activity_id", "activity_description", "behavior_sensors"]
            for field in required_fields:
                if field not in suggestion:
                    raise ValueError(
                        f"Verified suggestion at index {i} missing required field: {field}"
                    )

            behavior_sensors = suggestion["behavior_sensors"]
            if not isinstance(behavior_sensors, list):
                raise ValueError(
                    f"Verified suggestion at index {i} behavior_sensors must be a list"
                )

            # Validate each behavior sensor
            for j, behavior_sensor in enumerate(behavior_sensors):
                if not isinstance(behavior_sensor, dict):
                    raise ValueError(
                        f"Verified suggestion at index {i}, behavior_sensor at index {j} must be a dictionary"
                    )

                required_behavior_fields = [
                    "behavior",
                    "sensor_type",
                    "installation_area",
                    "installation_location",
                    "rationale",
                    "feasible",
                ]
                for field in required_behavior_fields:
                    if field not in behavior_sensor:
                        raise ValueError(
                            f"Verified suggestion at index {i}, behavior_sensor at index {j} missing required field: {field}"
                        )

                # Validate feasible is boolean
                if not isinstance(behavior_sensor["feasible"], bool):
                    raise ValueError(
                        f"Verified suggestion at index {i}, behavior_sensor at index {j} feasible must be a boolean"
                    )

        # Filter out non-feasible sensors for each activity
        for suggestion in verified_suggestions:
            behavior_sensors = suggestion.get("behavior_sensors", [])
            feasible_sensors = [
                bs for bs in behavior_sensors if bs.get("feasible", False)
            ]
            suggestion["behavior_sensors"] = feasible_sensors

        # Filter out activities with no feasible sensors
        verified_suggestions = [
            sug for sug in verified_suggestions if len(sug.get("behavior_sensors", [])) > 0
        ]

        return apply_sensor_constraints(verified_suggestions, constraints)

    async def close(self) -> None:
        """Close VLM client"""
        if self._vlm_client is not None:
            await self._vlm_client.close()
            self._vlm_client = None
