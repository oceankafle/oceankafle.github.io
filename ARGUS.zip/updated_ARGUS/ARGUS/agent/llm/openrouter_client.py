"""
This is the file for using OpenRouter API keys.
This allows us to use multiple LLMs with one key.
OpenRouter Client
"""

from __future__ import annotations

import os
from typing import Optional
from pathlib import Path

import openai
import httpx
from dotenv import load_dotenv

from .base_llm import LLM


_REPO_ROOT = Path(__file__).resolve().parents[2]
load_dotenv(Path('.env'), override=True)


class OpenRouterClient(LLM):
    """
    OpenRouter LLM Client
    """

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        model: Optional[str] = None,
        timeout: float = 60.0,
    ) -> None:
        api_key = api_key or os.getenv("OPENROUTER_API_KEY")
        base_url = base_url or os.getenv("OPENROUTER_ENDPOINT", "https://openrouter.ai/api/v1")
        model = model or os.getenv("OPENROUTER_MODEL", "google/gemma-4-31b-it:free")

        if not api_key:
            raise ValueError("Missing OPENROUTER_API_KEY")

        http_client = httpx.AsyncClient(timeout=timeout)

        self._client = openai.AsyncOpenAI(
            api_key=api_key,
            base_url=base_url,
            http_client=http_client,
            default_headers={
                "HTTP-Referer": os.getenv("OPENROUTER_SITE_URL", "http://localhost"),
                "X-OpenRouter-Title": os.getenv("OPENROUTER_APP_NAME", "My App"),
            },
        )
        self.model = model

    async def chat(
        self,
        *,
        messages: Optional[list[dict[str, str]]] = None,
        prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> str:
        try:
            if messages is None:
                if prompt is None:
                    raise ValueError("Either `messages` or `prompt` must be provided.")
                messages = [{"role": "user", "content": prompt}]

            resp = await self._client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
            )
            return resp.choices[0].message.content or ""

        except Exception:
            try:
                await self._client.close()
            except Exception:
                pass
            raise

    async def stream_chat(
        self,
        *,
        messages: Optional[list[dict[str, str]]] = None,
        prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ):
        try:
            if messages is None:
                if prompt is None:
                    raise ValueError("Either `messages` or `prompt` must be provided.")
                messages = [{"role": "user", "content": prompt}]

            stream = await self._client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                stream=True,
            )

            async for chunk in stream:
                if chunk.choices:
                    delta = chunk.choices[0].delta
                    if delta and getattr(delta, "content", None):
                        yield delta.content

        except Exception:
            try:
                await self._client.close()
            except Exception:
                pass
            raise

    async def close(self) -> None:
        await self._client.close()