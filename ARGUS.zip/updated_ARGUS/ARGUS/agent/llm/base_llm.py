"""
LLM Base Class
Defines the unified interface for Large Language Models
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Optional, AsyncGenerator

class LLM(ABC):
    """
    LLM Base Class
    Defines the unified interface for Large Language Models
    """
    @abstractmethod
    async def chat(
        self,
        *,
        messages: Optional[list[dict[str, str]]] = None,
        prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> str:
        """Asynchronously call LLM for conversation"""
        raise NotImplementedError

    async def stream_chat(
        self,
        *,
        messages: Optional[list[dict[str, str]]] = None,
        prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> AsyncGenerator[str, None]:
        """Stream chat with LLM"""
        # Default implementation: if subclass doesn't implement streaming,
        # use regular chat and yield character by character
        response = await self.chat(
            messages=messages,
            prompt=prompt,
            temperature=temperature,
            max_tokens=max_tokens,
        )

        # Yield character by character (simplest implementation, should be token-based in practice)
        for char in response:
            yield char

    async def close(self) -> None:
        """Optional: override this method to close underlying SDK clients"""
        return None


