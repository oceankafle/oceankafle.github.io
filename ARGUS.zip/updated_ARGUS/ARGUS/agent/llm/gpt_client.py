"""
Azure OpenAI LLM client.
"""

from __future__ import annotations
import os
from typing import Optional
import openai
from dotenv import load_dotenv
from pathlib import Path
from .base_llm import LLM

_REPO_ROOT = Path(__file__).resolve().parents[2]
load_dotenv(Path('.env'), override=True)


class GPTClient(LLM):
    """
    GPT LLM Client
    """

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        api_version: Optional[str] = None,
        model: Optional[str] = None,
    ) -> None:
        api_key = api_key or os.getenv("AZURE_OPENAI_API_KEY")
        base_url = base_url or os.getenv("AZURE_OPENAI_ENDPOINT")
        api_version = api_version or os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")
        model = model or os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")

        self._client = openai.AsyncAzureOpenAI(
            api_key=api_key,
            azure_endpoint=base_url,
            api_version=api_version,
        )
        self.model = model

    async def chat(
        self,
        *,
        messages: Optional[list[dict[str, str]]] = None,
        prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> str:
        try:
            if messages is None:
                messages = [{"role": "user", "content": prompt}]
            resp = await self._client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
            )
            return resp.choices[0].message.content or ""
        except Exception as e:
            try:
                await self._client.close()
            except:
                pass
            raise

    async def stream_chat(
        self,
        *,
        messages: Optional[list[dict[str, str]]] = None,
        prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ):
        try:
            if messages is None:
                messages = [{"role": "user", "content": prompt}]
            stream = await self._client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                stream=True,
            )
            async for chunk in stream:
                if chunk.choices and len(chunk.choices) > 0:
                    delta = chunk.choices[0].delta
                    if delta and delta.content:
                        yield delta.content
        except Exception as e:
            try:
                await self._client.close()
            except:
                pass
            raise

    async def close(self) -> None:
        await self._client.close()

