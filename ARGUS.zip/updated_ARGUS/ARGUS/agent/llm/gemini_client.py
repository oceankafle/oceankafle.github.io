"""
Gemini LLM client.
"""

from __future__ import annotations
import os
from typing import Optional, AsyncIterator
from google import genai
from google.genai import types
from dotenv import load_dotenv
from pathlib import Path
from .base_llm import LLM

_REPO_ROOT = Path(__file__).resolve().parents[2]
load_dotenv(Path('.env'), override=True)


class GeminiClient(LLM):
    """
    Gemini LLM Client
    """

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
    ) -> None:
        api_key = api_key or os.getenv("GEMINI_API_KEY")
        self.model = model or os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

        self._client = genai.Client(api_key=api_key)

    def _build_contents(
        self,
        messages: Optional[list[dict[str, str]]],
        prompt: Optional[str],
    ) -> list[types.Content]:
        """Convert OpenAI-style messages to Gemini Content format."""
        if messages is None:
            messages = [{"role": "user", "content": prompt}]

        contents = []
        for msg in messages:
            role = "user" if msg["role"] != "assistant" else "model"
            contents.append(
                types.Content(
                    role=role,
                    parts=[types.Part(text=msg["content"])]
                )
            )
        return contents

    async def chat(
        self,
        *,
        messages: Optional[list[dict[str, str]]] = None,
        prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> str:
        contents = self._build_contents(messages, prompt)
        config = types.GenerateContentConfig(
            temperature=temperature,
            max_output_tokens=max_tokens,
        )
        resp = await self._client.aio.models.generate_content(
            model=self.model,
            contents=contents,
            config=config,
        )
        return resp.text or ""

    async def stream_chat(
        self,
        *,
        messages: Optional[list[dict[str, str]]] = None,
        prompt: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> AsyncIterator[str]:
        contents = self._build_contents(messages, prompt)
        config = types.GenerateContentConfig(
            temperature=temperature,
            max_output_tokens=max_tokens,
        )
        async for chunk in await self._client.aio.models.generate_content_stream(
            model=self.model,
            contents=contents,
            config=config,
        ):
            if chunk.text:
                yield chunk.text

    async def close(self) -> None:
        pass