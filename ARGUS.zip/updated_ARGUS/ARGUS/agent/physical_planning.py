"""
Deterministic spatial grounding helpers for deployment recommendations.

The VLM chooses semantic grid segments. This module adds repeatable physical
metadata: approximate coordinates, sensor coverage, occlusion risk, and a
feasibility summary that can be evaluated without another model call.
"""

from __future__ import annotations

from pathlib import Path
from statistics import mean
from typing import Any

from PIL import Image

from .sensor_specs import (
    canonical_sensor_type,
    is_area_restricted,
    is_restricted,
    recommend_alternative,
    sensor_spec,
)


_PRIORITY_WEIGHT = {"high": 1.0, "medium": 0.78, "low": 0.58}
_OCCLUSION_RISK = {"low": 0.12, "medium": 0.28, "high": 0.48}


def _image_size(image_path: Path | None) -> tuple[int | None, int | None]:
    if not image_path or not image_path.exists():
        return None, None
    with Image.open(image_path) as img:
        return img.size


def _segments_by_id(grid: dict[str, Any]) -> dict[str, dict[str, Any]]:
    g = grid.get("grid") if isinstance(grid.get("grid"), dict) else grid
    return {
        str(seg.get("id")): seg
        for seg in (g or {}).get("segments", [])
        if seg.get("id")
    }


def _grid_shape(grid: dict[str, Any]) -> tuple[int, int]:
    g = grid.get("grid") if isinstance(grid.get("grid"), dict) else grid
    return int((g or {}).get("rows") or 1), int((g or {}).get("columns") or 1)


def _segment_center(
    segment: dict[str, Any],
    rows: int,
    columns: int,
    width: int | None,
    height: int | None,
) -> dict[str, Any]:
    row = max(1, int(segment.get("row") or 1))
    col = max(1, int(segment.get("column") or 1))
    x_pct = ((col - 0.5) / max(columns, 1)) * 100
    y_pct = ((row - 0.5) / max(rows, 1)) * 100
    out: dict[str, Any] = {
        "x_percent": round(x_pct, 1),
        "y_percent": round(y_pct, 1),
    }
    if width and height:
        out["x_px"] = round(width * x_pct / 100)
        out["y_px"] = round(height * y_pct / 100)
    return out


def _sensor_suggestion_lookup(
    sensor_suggestions: list[dict[str, Any]],
) -> dict[tuple[str, str, str], dict[str, Any]]:
    out: dict[tuple[str, str, str], dict[str, Any]] = {}
    for suggestion in sensor_suggestions:
        activity_id = str(suggestion.get("activity_id", ""))
        for behavior_sensor in suggestion.get("behavior_sensors") or []:
            key = (
                activity_id,
                canonical_sensor_type(behavior_sensor.get("sensor_type", "")),
                str(behavior_sensor.get("behavior", "")).lower(),
            )
            out[key] = behavior_sensor
    return out


def _matching_suggestion(
    lookup: dict[tuple[str, str, str], dict[str, Any]],
    recommendation: dict[str, Any],
) -> dict[str, Any]:
    activity_id = str(recommendation.get("activity_id", ""))
    sensor_type = canonical_sensor_type(recommendation.get("sensor_type", ""))
    behavior = str(recommendation.get("behavior", "")).lower()
    return lookup.get((activity_id, sensor_type, behavior), {})


def _coverage_score(spec: dict[str, Any], priority: str, segment: dict[str, Any]) -> float:
    range_score = min(float(spec.get("range_m") or 1.0) / 6.0, 1.0)
    fov_score = min(float(spec.get("fov_deg") or 60) / 120.0, 1.0)
    priority_score = _PRIORITY_WEIGHT.get(priority, 0.6)
    feature_bonus = 0.05 if segment.get("features") else 0.0
    return round(min((range_score * 0.38) + (fov_score * 0.32) + (priority_score * 0.25) + feature_bonus, 1.0), 3)


def _occlusion_risk(spec: dict[str, Any], segment: dict[str, Any]) -> float:
    base = _OCCLUSION_RISK.get(str(spec.get("occlusion_sensitivity", "medium")), 0.28)
    features = [str(item).lower() for item in segment.get("features") or []]
    bulky = any(item in " ".join(features) for item in ("closet", "cabinet", "island", "wall", "storage"))
    return round(min(base + (0.12 if bulky else 0.0), 1.0), 3)


def enrich_deployment_recommendations(
    *,
    sensor_suggestions: list[dict[str, Any]],
    grid: dict[str, Any],
    recommendations: list[dict[str, Any]],
    constraints: dict[str, Any] | None = None,
    image_path: Path | None = None,
) -> list[dict[str, Any]]:
    rows, columns = _grid_shape(grid)
    width, height = _image_size(image_path)
    segments = _segments_by_id(grid)
    lookup = _sensor_suggestion_lookup(sensor_suggestions)
    constraints = constraints or {}

    enriched: list[dict[str, Any]] = []
    for recommendation in recommendations:
        rec = dict(recommendation)
        rec["sensor_type"] = canonical_sensor_type(rec.get("sensor_type", ""))
        replacement_note = str(rec.get("rationale_adjustment") or "")
        if not replacement_note and rec.get("constraint_adjustment"):
            replacement_note = f"Final sensor type is {rec['sensor_type']} because the original recommendation violated constraints."
        if is_restricted(rec["sensor_type"], constraints):
            alternative = recommend_alternative(str(rec.get("behavior", "")), constraints)
            if alternative:
                original = rec["sensor_type"]
                rec["sensor_type"] = alternative
                rec["constraint_adjustment"] = "Sensor type replaced because the original recommendation was restricted."
                rec["rationale_adjustment"] = f"Replaced restricted {original} with {alternative}."
                replacement_note = rec["rationale_adjustment"]
        spec = sensor_spec(rec["sensor_type"])
        source_suggestion = _matching_suggestion(lookup, rec)

        grounded_segments: list[dict[str, Any]] = []
        for seg_choice in rec.get("recommended_segments") or []:
            seg = segments.get(str(seg_choice.get("segment_id", "")), {})
            priority = str(seg_choice.get("priority", "medium"))
            placement = _segment_center(seg, rows, columns, width, height) if seg else {}
            mounting = (spec.get("mounting") or ["room surface"])[0]
            if placement:
                placement.update(
                    {
                        "mounting": mounting,
                        "height_m": spec.get("recommended_height_m"),
                        "range_m": spec.get("range_m"),
                        "fov_deg": spec.get("fov_deg"),
                        "coordinate_basis": "segment center",
                    }
                )

            restricted = is_restricted(rec["sensor_type"], constraints) or is_area_restricted(
                source_suggestion.get("installation_area", seg.get("room", "")),
                constraints,
            )
            coverage = _coverage_score(spec, priority, seg) if seg and spec else 0.0
            occlusion = _occlusion_risk(spec, seg) if seg and spec else 0.5
            feasibility = max(0.0, min(1.0, coverage - (occlusion * 0.35) - (0.45 if restricted else 0.0)))

            grounded = dict(seg_choice)
            if replacement_note:
                if rec.get("constraint_adjustment") and not rec.get("rationale_adjustment"):
                    grounded["rationale"] = replacement_note
                else:
                    grounded["rationale"] = (
                        f"{grounded.get('rationale', '').strip()} {replacement_note}"
                    ).strip()
            grounded["placement"] = placement
            grounded["coverage"] = {
                "coverage_score": round(coverage, 3),
                "active_zone_covered": bool(seg and coverage >= 0.45 and not restricted),
                "occlusion_risk": occlusion,
                "feasibility_score": round(feasibility, 3),
                "constraint_violation": bool(restricted),
            }
            grounded_segments.append(grounded)

        rec["recommended_segments"] = grounded_segments
        if spec:
            rec["sensor_spec"] = {
                "range_m": spec.get("range_m"),
                "fov_deg": spec.get("fov_deg"),
                "mounting": spec.get("mounting", []),
                "recommended_height_m": spec.get("recommended_height_m"),
                "occlusion_sensitivity": spec.get("occlusion_sensitivity"),
                "privacy_level": spec.get("privacy_level"),
            }
        enriched.append(rec)
    return enriched


def summarize_deployment_evaluation(
    recommendations: list[dict[str, Any]],
) -> dict[str, Any]:
    segment_scores: list[dict[str, Any]] = []
    unique_sensors: set[tuple[str, str, str]] = set()
    for rec in recommendations:
        sensor_type = str(rec.get("sensor_type", ""))
        behavior = str(rec.get("behavior", ""))
        for seg in rec.get("recommended_segments") or []:
            coverage = seg.get("coverage") or {}
            segment_scores.append(coverage)
            unique_sensors.add(
                (
                    sensor_type,
                    str(seg.get("segment_id", "")),
                    str(seg.get("installation_location", "")),
                )
            )

    if not segment_scores:
        return {
            "sensor_count": 0,
            "coverage_percent": 0.0,
            "average_feasibility": 0.0,
            "average_occlusion_risk": 0.0,
            "constraint_violations": 0,
        }

    covered = [s for s in segment_scores if s.get("active_zone_covered")]
    feasibility = [float(s.get("feasibility_score") or 0) for s in segment_scores]
    occlusion = [float(s.get("occlusion_risk") or 0) for s in segment_scores]
    violations = [s for s in segment_scores if s.get("constraint_violation")]
    return {
        "sensor_count": len(unique_sensors),
        "coverage_percent": round(len(covered) / len(segment_scores) * 100, 1),
        "average_feasibility": round(mean(feasibility), 3),
        "average_occlusion_risk": round(mean(occlusion), 3),
        "constraint_violations": len(violations),
        "evaluated_recommendations": len(segment_scores),
    }
