"""
Sensor catalog utilities for deterministic grounding and validation.
"""

from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any

_SENSOR_SPEC_FILE = Path(__file__).resolve().parents[1] / "data" / "sensor_specs.json"


@lru_cache(maxsize=1)
def load_sensor_specs() -> dict[str, dict[str, Any]]:
    with open(_SENSOR_SPEC_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def canonical_sensor_type(sensor_type: str) -> str:
    needle = (sensor_type or "").strip().lower()
    specs = load_sensor_specs()
    if needle in specs:
        return needle
    for canonical, spec in specs.items():
        aliases = [a.lower() for a in spec.get("aliases", [])]
        if needle in aliases:
            return canonical
    return needle


def sensor_spec(sensor_type: str) -> dict[str, Any]:
    return load_sensor_specs().get(canonical_sensor_type(sensor_type), {})


def is_restricted(sensor_type: str, constraints: dict[str, Any] | None) -> bool:
    constraints = constraints or {}
    prefs = constraints.get("sensor_preferences") or {}
    restricted = prefs.get("restricted_types") or []
    canonical = canonical_sensor_type(sensor_type)
    restricted_canonical = {canonical_sensor_type(str(item)) for item in restricted}
    return canonical in restricted_canonical


def is_area_restricted(area: str, constraints: dict[str, Any] | None) -> bool:
    constraints = constraints or {}
    privacy = constraints.get("privacy") or {}
    installation = constraints.get("installation") or {}
    restricted = list(privacy.get("restricted_rooms") or [])
    restricted.extend(privacy.get("restricted_areas") or [])
    restricted.extend(installation.get("restricted_locations") or [])
    area_lower = (area or "").lower()
    return any(str(item).lower() in area_lower for item in restricted)


def enrich_behavior_sensor(item: dict[str, Any]) -> dict[str, Any]:
    out = dict(item)
    canonical = canonical_sensor_type(out.get("sensor_type", ""))
    spec = sensor_spec(canonical)
    if spec:
        out["sensor_type"] = canonical
        out["sensor_spec"] = {
            "range_m": spec.get("range_m"),
            "fov_deg": spec.get("fov_deg"),
            "mounting": spec.get("mounting", []),
            "recommended_height_m": spec.get("recommended_height_m"),
            "occlusion_sensitivity": spec.get("occlusion_sensitivity"),
            "privacy_level": spec.get("privacy_level"),
        }
    return out


def recommend_alternative(
    behavior: str,
    constraints: dict[str, Any] | None,
) -> str | None:
    text = (behavior or "").lower()
    candidates: list[str]
    if any(word in text for word in ("eat", "arm", "gesture", "seated")):
        candidates = ["mmwave radar", "pir motion sensor"]
    elif any(word in text for word in ("sit", "chair", "lie", "bed", "sleep")):
        candidates = ["mmwave radar", "pressure sensor", "pir motion sensor"]
    elif any(word in text for word in ("door", "cabinet", "drawer", "open", "close")):
        candidates = ["contact sensor", "pir motion sensor"]
    elif any(word in text for word in ("stove", "cook", "heat")):
        candidates = ["temperature sensor", "mmwave radar"]
    elif any(word in text for word in ("lamp", "light", "appliance", "power")):
        candidates = ["smart plug sensor", "contact sensor"]
    else:
        candidates = ["mmwave radar", "pir motion sensor", "contact sensor"]

    for candidate in candidates:
        if candidate in load_sensor_specs() and not is_restricted(candidate, constraints):
            return candidate
    return None


def apply_sensor_constraints(
    sensor_suggestions: list[dict[str, Any]],
    constraints: dict[str, Any] | None,
) -> list[dict[str, Any]]:
    filtered: list[dict[str, Any]] = []
    for suggestion in sensor_suggestions:
        kept: list[dict[str, Any]] = []
        for behavior_sensor in suggestion.get("behavior_sensors") or []:
            sensor_type = behavior_sensor.get("sensor_type", "")
            area = behavior_sensor.get("installation_area", "")
            if is_area_restricted(area, constraints):
                continue
            if is_restricted(sensor_type, constraints):
                alt = recommend_alternative(behavior_sensor.get("behavior", ""), constraints)
                if not alt:
                    continue
                behavior_sensor = dict(behavior_sensor)
                behavior_sensor["sensor_type"] = alt
                behavior_sensor["rationale"] = (
                    f"{behavior_sensor.get('rationale', '').strip()} "
                    f"Selected {alt} because the original sensor type is restricted."
                ).strip()
            kept.append(enrich_behavior_sensor(behavior_sensor))

        if kept:
            updated = dict(suggestion)
            updated["behavior_sensors"] = kept
            filtered.append(updated)
    return filtered
