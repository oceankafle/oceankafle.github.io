"""
Agent Utilities
JSON parsing utilities for VLM/LLM responses
Activity analysis data management
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


_ACTIVITY_ANALYSIS_FILE = Path(__file__).resolve().parents[1] / "data" / "activity_analysis.json"


def load_activity_analysis() -> dict[str, Any]:
    """
    Load activity_analysis.json data
    
    Returns:
        Dictionary containing activity analysis data
    """
    if not _ACTIVITY_ANALYSIS_FILE.exists():
        # Return default structure if file doesn't exist
        return {
            "environment_info": {},
            "activities": [],
            "constraints": {},
        }
    
    try:
        with open(_ACTIVITY_ANALYSIS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        raise ValueError(f"Failed to parse {_ACTIVITY_ANALYSIS_FILE}: {e}") from e


def save_activity_analysis(data: dict[str, Any]) -> None:
    """
    Save data to activity_analysis.json
    
    Args:
        data: Dictionary containing activity analysis data
    """
    # Ensure directory exists
    _ACTIVITY_ANALYSIS_FILE.parent.mkdir(parents=True, exist_ok=True)
    
    # Write to file with proper formatting
    with open(_ACTIVITY_ANALYSIS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def update_activity_analysis(key: str | None = None, value: Any = None, **kwargs: Any) -> None:
    data = load_activity_analysis()
    
    # If kwargs provided, use kwargs to update
    if kwargs:
        data.update(kwargs)
    # Otherwise use key/value
    elif key is not None:
        data[key] = value
    else:
        raise ValueError("Either provide key/value pair or use kwargs")
    
    save_activity_analysis(data)


def parse_json_response(response: str) -> dict[str, Any]:
    response = response.strip()
    
    # Remove markdown code blocks if present
    if response.startswith("```json"):
        response = response[7:]  # Remove ```json
    elif response.startswith("```"):
        response = response[3:]  # Remove ```
    
    if response.endswith("```"):
        response = response[:-3]  # Remove closing ```
    
    response = response.strip()

    # Remove trailing commas (LLMs often output invalid JSON with trailing commas)
    while True:
        new_response = re.sub(r",(\s*[}\]])", r"\1", response)
        if new_response == response:
            break
        response = new_response

    # Find the first JSON object and ignore trailing text if any
    start_idx = response.find("{")
    if start_idx == -1:
        raise ValueError(
            "Failed to parse JSON response: no JSON object found\n"
            f"Response preview: {response[:500]}"
        )
    start_idx = response.find("{")
    snippet = response[start_idx:]
    decoder = json.JSONDecoder()
    try:
        result = json.loads(snippet)
        if not isinstance(result, dict):
            raise ValueError("Response is not a JSON object (dictionary)")
        return result
    except json.JSONDecodeError:
        # Fallback: extract the largest valid JSON object in the response
        def iter_json_objects(text: str) -> list[str]:
            in_string = False
            escape = False
            depth = 0
            start = None
            found: list[str] = []
            for idx, ch in enumerate(text):
                if in_string:
                    if escape:
                        escape = False
                    elif ch == "\\":
                        escape = True
                    elif ch == "\"":
                        in_string = False
                    continue
                if ch == "\"":
                    in_string = True
                    continue
                if ch == "{":
                    if depth == 0:
                        start = idx
                    depth += 1
                elif ch == "}":
                    if depth > 0:
                        depth -= 1
                        if depth == 0 and start is not None:
                            found.append(text[start : idx + 1])
                            start = None
            return found

        candidates = iter_json_objects(response[start_idx:])
        for snippet in reversed(candidates):
            try:
                result = json.loads(snippet)
                if not isinstance(result, dict):
                    continue
                return result
            except json.JSONDecodeError:
                continue

        # Final fallback: try from first '{' to last '}'
        end_idx = response.rfind("}")
        if end_idx == -1 or end_idx <= start_idx:
            raise ValueError(
                "Failed to parse JSON response: no complete JSON object found\n"
                f"Response preview: {response[:500]}"
            )
        try:
            snippet = response[start_idx : end_idx + 1]
            result = json.loads(snippet)
            if not isinstance(result, dict):
                raise ValueError("Response is not a JSON object (dictionary)")
            return result
        except json.JSONDecodeError as e:
            raise ValueError(
                f"Failed to parse JSON response: {e}\n"
                f"Response preview: {response[:500]}"
            ) from e


def parse_json_response_with_schema(
    response: str,
    required_keys: list[str] | None = None,
    schema: dict[str, Any] | None = None,
) -> dict[str, Any]:
    result = parse_json_response(response)
    
    # Validate required keys
    if required_keys:
        missing_keys = [key for key in required_keys if key not in result]
        if missing_keys:
            raise ValueError(
                f"Response missing required keys: {missing_keys}\n"
                f"Required: {required_keys}\n"
                f"Found: {list(result.keys())}"
            )

    return result

