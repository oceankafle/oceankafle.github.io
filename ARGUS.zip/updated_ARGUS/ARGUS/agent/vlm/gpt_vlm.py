from __future__ import annotations

import os
import base64
from pathlib import Path
from typing import Optional, Sequence, List, Dict, Any

from openai import AzureOpenAI

from .base_vlm import VLM


class AzureOpenAIVLMClient(VLM):
    """Azure OpenAI VLM client (GPT-4o / vision models)"""

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
        endpoint: Optional[str] = None,
        api_version: Optional[str] = None,
    ) -> None:

        self.api_key = api_key or os.getenv("AZURE_OPENAI_VLM_API_KEY")
        self.endpoint = endpoint or os.getenv("AZURE_OPENAI_VLM_ENDPOINT")
        self.api_version = api_version or os.getenv(
            "AZURE_OPENAI_VLM_API_VERSION",
            "2024-02-15-preview"
        )

        self.model = model or os.getenv("AZURE_OPENAI_VLM_DEPLOYMENT_NAME")

        self._client = AzureOpenAI(
            api_key=self.api_key,
            azure_endpoint=self.endpoint,
            api_version=self.api_version,
        )

    def _encode_image(self, path: Path) -> str:
        data = Path(path).read_bytes()
        b64 = base64.b64encode(data).decode("utf-8")
        suffix = path.suffix.lower().lstrip(".")
        mime = f"image/{'jpeg' if suffix == 'jpg' else suffix}"
        return f"data:{mime};base64,{b64}"

    def _build_messages(
        self,
        prompt: Optional[str],
        messages: Optional[list[dict]],
        image_paths: Optional[Sequence[Path]],
    ) -> List[Dict[str, Any]]:

        msg_list = []

        # Convert chat history if provided
        if messages:
            for msg in messages:
                role = msg["role"]
                content = msg["content"]

                if isinstance(content, str):
                    msg_list.append({
                        "role": role,
                        "content": content
                    })

                elif isinstance(content, list):
                    parts = []
                    for item in content:
                        if item["type"] == "text":
                            parts.append({"type": "text", "text": item["text"]})

                        elif item["type"] == "image_url":
                            parts.append({
                                "type": "image_url",
                                "image_url": item["image_url"]
                            })

                    msg_list.append({
                        "role": role,
                        "content": parts
                    })

        # Current prompt + images
        content = []

        if prompt:
            content.append({"type": "text", "text": prompt})

        if image_paths:
            for p in image_paths:
                content.append({
                    "type": "image_url",
                    "image_url": {
                        "url": self._encode_image(p)
                    }
                })

        if content:
            msg_list.append({
                "role": "user",
                "content": content
            })

        return msg_list

    async def chat(
        self,
        *,
        prompt: Optional[str] = None,
        messages: Optional[list[dict]] = None,
        image_paths: Optional[Sequence[Path]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> str:

        messages = self._build_messages(prompt, messages, image_paths)

        resp = self._client.chat.completions.create(
            model=self.model,  # deployment name in Azure
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )

        return resp.choices[0].message.content or ""

    async def stream_chat(
        self,
        *,
        prompt: Optional[str] = None,
        messages: Optional[list[dict]] = None,
        image_paths: Optional[Sequence[Path]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ):
        messages = self._build_messages(prompt, messages, image_paths)

        stream = self._client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=True,
        )

        for chunk in stream:
            delta = chunk.choices[0].delta.content
            if delta:
                yield delta

    async def close(self) -> None:
        pass