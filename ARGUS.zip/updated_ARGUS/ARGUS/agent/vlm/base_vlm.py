"""
VLM base class.
Defines a unified interface for vision-language models.
"""

from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional, Sequence, Any

from dotenv import load_dotenv

# Load .env from project root
_REPO_ROOT = Path(__file__).resolve().parents[2]
load_dotenv(Path('.env'), override=True)


def image_to_data_url(image_path: Path) -> str:
    """Encode a local image file into a data: URL base64 string."""
    import base64

    if not image_path.exists():
        raise FileNotFoundError(f"Image file not found: {image_path}")

    image_data = image_path.read_bytes()
    base64_str = base64.b64encode(image_data).decode("utf-8")

    ext = image_path.suffix.lower()
    mime_type_map = {
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".png": "image/png",
        ".gif": "image/gif",
        ".webp": "image/webp",
    }
    mime_type = mime_type_map.get(ext, "image/jpeg")
    return f"data:{mime_type};base64,{base64_str}"


def build_openai_style_messages(prompt: str, image_paths: Optional[Sequence[Path]]) -> list[dict[str, Any]]:
    """Build OpenAI-style messages format from messages list and image paths."""
    content_list = [{"type": "text", "text": prompt}]
    if image_paths:
        for p in image_paths:
            content_list.append({"type": "image_url", "image_url": {"url": image_to_data_url(Path(p))}})
    return [{"role": "user", "content": content_list}]



class VLM(ABC):
    """VLM Base Class"""

    @abstractmethod
    async def chat(
        self,
        *,
        prompt: Optional[str] = None,
        messages: Optional[list[dict[str, str]]] = None,
        image_paths: Optional[Sequence[Path]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> str:
        raise NotImplementedError

    async def close(self) -> None:
        return None

