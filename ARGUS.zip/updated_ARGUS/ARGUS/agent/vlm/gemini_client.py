'''
Gemini VLM
'''

from __future__ import annotations

import os
import base64
from pathlib import Path
from typing import Optional, Sequence
from google import genai
from google.genai import types

from .base_vlm import VLM

class GeminiVLMClient(VLM):
    """Gemini VLM client"""

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
    ) -> None:
        api_key = api_key or os.getenv("GEMINI_API_KEY")
        self.model = model or os.getenv("GEMINI_MODEL", "gemini-3-flash-preview")
        self._client = genai.Client(api_key=api_key)

    def _build_contents(
        self,
        prompt: Optional[str],
        messages: Optional[list[dict]],
        image_paths: Optional[Sequence[Path]],
    ) -> list[types.Content]:
        parts = []

        if image_paths:
            for path in image_paths:
                data = Path(path).read_bytes()
                b64 = base64.b64encode(data).decode()
                suffix = Path(path).suffix.lower().lstrip(".")
                mime = f"image/{'jpeg' if suffix == 'jpg' else suffix}"
                parts.append(types.Part(inline_data=types.Blob(mime_type=mime, data=b64)))

        if prompt:
            parts.append(types.Part(text=prompt))

        if messages:
            # If OpenAI-style messages passed, convert them
            contents = []
            for msg in messages:
                role = "model" if msg["role"] == "assistant" else "user"
                content = msg["content"]
                if isinstance(content, str):
                    contents.append(types.Content(role=role, parts=[types.Part(text=content)]))
                elif isinstance(content, list):
                    msg_parts = []
                    for item in content:
                        if item.get("type") == "text":
                            msg_parts.append(types.Part(text=item["text"]))
                        elif item.get("type") == "image_url":
                            # handle base64 image_url
                            url = item["image_url"]["url"]
                            if url.startswith("data:"):
                                header, b64data = url.split(",", 1)
                                mime = header.split(":")[1].split(";")[0]
                                msg_parts.append(types.Part(
                                    inline_data=types.Blob(mime_type=mime, data=b64data)
                                ))
                    contents.append(types.Content(role=role, parts=msg_parts))
            return contents

        return [types.Content(role="user", parts=parts)]

    async def chat(
        self,
        *,
        prompt: Optional[str] = None,
        messages: Optional[list[dict]] = None,
        image_paths: Optional[Sequence[Path]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> str:
        contents = self._build_contents(prompt, messages, image_paths)
        config = types.GenerateContentConfig(
            temperature=temperature,
            max_output_tokens=max_tokens,
        )
        resp = await self._client.aio.models.generate_content(
            model=self.model,
            contents=contents,
            config=config,
        )
        return resp.text or ""

    async def stream_chat(
        self,
        *,
        prompt: Optional[str] = None,
        messages: Optional[list[dict]] = None,
        image_paths: Optional[Sequence[Path]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ):
        contents = self._build_contents(prompt, messages, image_paths)
        config = types.GenerateContentConfig(
            temperature=temperature,
            max_output_tokens=max_tokens,
        )
        async for chunk in await self._client.aio.models.generate_content_stream(
            model=self.model,
            contents=contents,
            config=config,
        ):
            if chunk.text:
                yield chunk.text

    async def close(self) -> None:
        pass  # no explicit close needed