"""
Qwen VLM client.
Uses DashScope API via OpenAI-compatible mode to call Qwen-VL.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional, Sequence
import openai
import httpx

from .base_vlm import VLM, build_openai_style_messages


class QwenClient(VLM):
    """DashScope Qwen-VL client via OpenAI-compatible mode"""

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        model: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> None:
        api_key = api_key or os.getenv("DASHSCOPE_API_KEY")
        base_url = base_url or os.getenv("DASHSCOPE_API_BASE", "https://dashscope.aliyuncs.com/compatible-mode/v1")
        model = model or os.getenv("DASHSCOPE_MODEL", "qwen-vl-plus")
        
        http_client = httpx.AsyncClient(
            headers={"X-DashScope-SSE": "enable"},
            timeout=60.0
        )
        self._client = openai.AsyncOpenAI(
            api_key=api_key,
            base_url=base_url,
            http_client=http_client
        )

        self.model = model

    async def chat(
        self,
        *,
        prompt: Optional[str] = None,
        messages: Optional[list[dict[str, str]]] = None,
        image_paths: Optional[Sequence[Path]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> str:
        try:
            if messages is None:
                messages = build_openai_style_messages(prompt, image_paths)
            resp = await self._client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
            )
            return resp.choices[0].message.content or ""
        except Exception as e:
            try:
                await self._client.close()
            except:
                pass
            raise

    async def close(self) -> None:
        await self._client.close()

