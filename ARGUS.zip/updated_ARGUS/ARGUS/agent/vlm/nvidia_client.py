'''
NVIDIA VLM
'''

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional, Sequence
import openai
import httpx

from .base_vlm import VLM, build_openai_style_messages


class NVIDIAClient(VLM):
    """NVIDIA client via OpenRouter"""

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
    ) -> None:
        api_key = api_key or os.getenv("NVIDIA_API_KEY")
        model = model or os.getenv(
            "NVIDIA_MODEL",
            "nvidia/nemotron-nano-12b-v2-vl:free",
        )

        http_client = httpx.AsyncClient(timeout=60.0)

        self._client = openai.AsyncOpenAI(
            api_key=api_key,
            base_url="https://openrouter.ai/api/v1",
            http_client=http_client,
            default_headers={
                "HTTP-Referer": "http://localhost",
                "X-OpenRouter-Title": "NVIDIA VLM",
            },
        )

        self.model = model

    async def chat(
        self,
        *,
        prompt: Optional[str] = None,
        messages: Optional[list[dict]] = None,
        image_paths: Optional[Sequence[Path]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> str:
        try:
            if messages is None:
                messages = build_openai_style_messages(prompt, image_paths)

            resp = await self._client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
            )

            return resp.choices[0].message.content or ""

        except Exception:
            await self._client.close()
            raise

    async def stream_chat(self, *, prompt=None, messages=None, image_paths=None,
                      temperature=0.7, max_tokens=None):
        if messages is None:
            messages = build_openai_style_messages(prompt, image_paths)

        stream = await self._client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=True,
        )
        async for chunk in stream:
            token = chunk.choices[0].delta.content
            if token:
                yield token


    async def close(self) -> None:
        await self._client.close()