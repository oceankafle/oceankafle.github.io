"""
LLaVA VLM client.
Connects to a remote LLaVA model via OpenAI-compatible API.
"""

from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import Any, Optional, Sequence

import openai
import requests

from .base_vlm import VLM, build_openai_style_messages


class CustomClient(VLM):
    """Custom/remote OpenAI-compatible VLM client"""

    def __init__(
        self,
        *,
        base_url: str,
        model: Optional[str] = None,
        timeout_s: int = 120,
    ) -> None:
        self.base_url = (base_url or os.getenv("REMOTE_VLM_API_BASE", "http://localhost:8000/v1")).rstrip("/")
        self.model = model or os.getenv("REMOTE_VLM_MODEL", "llava-hf/llama3-llava-next-8b-hf")
        self.timeout_s = timeout_s

    def _endpoint(self) -> str:
        if self.base_url.endswith("/v1"):
            return f"{self.base_url}/chat/completions"
        return f"{self.base_url}/v1/chat/completions"

    async def chat(
        self,
        *,
        prompt: str,
        image_paths: Optional[Sequence[Path]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> str:
        if self._sdk_client is None:
            return await asyncio.to_thread(
                self._chat_sync_http,
                prompt=prompt,
                image_paths=image_paths,
                temperature=temperature,
                max_tokens=max_tokens,
            )

        resp = await self._sdk_client.chat.completions.create(
            model=self.model,
            messages=build_openai_style_messages(prompt, image_paths),
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return resp.choices[0].message.content or ""


