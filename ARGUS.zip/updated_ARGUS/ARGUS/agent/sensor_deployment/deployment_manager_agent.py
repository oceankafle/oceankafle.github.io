"""
Deployment Manager Agent
Handles user interactions and responds to deployment-related instructions
"""

from __future__ import annotations

import json
from typing import Any, Optional

from ..llm.base_llm import LLM
from ..factory import get_llm
from ..utils import load_activity_analysis, parse_json_response
from prompt import manager as prompt_manager


class DeploymentManagerAgent:
    """
    Deployment Manager Agent for sensor deployment
    
    Handles user interactions and responds to deployment-related instructions
    """

    def __init__(
        self,
        *,
        llm_name: str = "gemini",
        llm_kwargs: Optional[dict[str, Any]] = None,
        template_name: str = "sensor_deployment/deployment_manager",
    ):
        self.llm_name = llm_name
        self.llm_kwargs = llm_kwargs or {}
        self.template_name = template_name
        self._llm_client: Optional[LLM] = None

    def _get_llm_client(self) -> LLM:
        """Get or create LLM client"""
        if self._llm_client is None:
            self._llm_client = get_llm(self.llm_name, **self.llm_kwargs)
        return self._llm_client

    async def respond(
        self,
        *,
        user_instruction: str,
        context: Optional[str] = None,
        sensor_suggestions: Optional[list[dict[str, Any]]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> dict[str, Any]:
        """
        Respond to user instruction
        
        Args:
            user_instruction: User's instruction or question
            context: Additional context information
            sensor_suggestions: Current sensor suggestions (if available)
            temperature: Temperature for LLM generation
            max_tokens: Maximum tokens for LLM response
        
        Returns:
            Dictionary containing response and action information
        """
        # Load current data for context
        data = load_activity_analysis()
        environment_info = data.get("environment_info", {})
        
        # Build context string
        if context is None:
            context_str = json.dumps(
                {"environment_info": environment_info}, indent=2, ensure_ascii=False
            )
        else:
            context_str = context

        # Render prompt template
        sensor_suggestions_str = (
            json.dumps(sensor_suggestions, indent=2, ensure_ascii=False)
            if sensor_suggestions
            else "[]"
        )
        
        prompt = prompt_manager.render(
            self.template_name,
            user_instruction=user_instruction,
            context=context_str,
            sensor_suggestions=sensor_suggestions_str,
        )

        # Get LLM client and respond
        llm = self._get_llm_client()
        response = await llm.chat(
            prompt=prompt,
            temperature=temperature,
            max_tokens=max_tokens,
        )

        # Parse JSON response
        result = parse_json_response(response)

        # Validate structure
        if not isinstance(result, dict):
            raise ValueError("Response must be a dictionary")

        required_fields = ["response", "action_required", "action_type"]
        for field in required_fields:
            if field not in result:
                raise ValueError(f"Response missing required field: {field}")

        if not isinstance(result["action_required"], bool):
            raise ValueError("action_required must be a boolean")

        valid_action_types = ["none", "modify", "clarify", "update"]
        if result["action_type"] not in valid_action_types:
            raise ValueError(
                f"action_type must be one of {valid_action_types}, got {result['action_type']}"
            )

        if result["action_type"] == "modify" and "modifications" not in result:
            raise ValueError("action_type is 'modify' but modifications field is missing")

        return result

    async def close(self) -> None:
        """Close LLM client"""
        if self._llm_client is not None:
            await self._llm_client.close()
            self._llm_client = None

