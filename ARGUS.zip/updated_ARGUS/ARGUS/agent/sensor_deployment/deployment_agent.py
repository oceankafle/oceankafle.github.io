"""
Deployment Agent
Analyzes segmented floor plans and recommends deployment regions
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

from ..vlm.base_vlm import VLM
from ..factory import get_vlm
from ..utils import load_activity_analysis, parse_json_response
from ..sensor_specs import load_sensor_specs
from prompt import manager as prompt_manager


class DeploymentAgent:
    """
    Deployment Agent for sensor deployment
    
    Analyzes segmented floor plans and recommends specific grid segments for sensor deployment
    """

    def __init__(
        self,
        *,
        vlm_name: str = "nvidia",
        vlm_kwargs: Optional[dict[str, Any]] = None,
        template_name: str = "sensor_deployment/deployment_analysis",
    ):
        self.vlm_name = vlm_name
        self.vlm_kwargs = vlm_kwargs or {}
        self.template_name = template_name
        self._vlm_client: Optional[VLM] = None

    def _get_vlm_client(self) -> VLM:
        """Get or create VLM client"""
        if self._vlm_client is None:
            self._vlm_client = get_vlm(self.vlm_name, **self.vlm_kwargs)
        return self._vlm_client

    async def analyze(
        self,
        *,
        sensor_suggestions: list[dict[str, Any]],
        grid_segments: dict[str, Any],
        constraints: Optional[dict[str, Any]] = None,
        image_path: Path,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        """
        Analyze segmented floor plan and recommend deployment regions
        
        Args:
            sensor_suggestions: Sensor suggestions from previous stages
            grid_segments: Grid segments from segment agent
            constraints: Deployment constraints (optional)
            image_path: Path to the floor plan image
            temperature: Temperature for VLM generation
            max_tokens: Maximum tokens for VLM response
        
        Returns:
            List of deployment recommendations with recommended segments
        """
        if not image_path.exists():
            raise FileNotFoundError(f"Image not found: {image_path}")

        # Load environment info
        data = load_activity_analysis()
        environment_info = data.get("environment_info", {})

        # Render prompt template
        constraints_str = (
            json.dumps(constraints, indent=2, ensure_ascii=False) if constraints else "{}"
        )
        
        prompt = prompt_manager.render(
            self.template_name,
            sensor_suggestions=json.dumps(sensor_suggestions, indent=2, ensure_ascii=False),
            grid_segments=json.dumps(grid_segments, indent=2, ensure_ascii=False),
            constraints=constraints_str,
            environment_info=json.dumps(environment_info, indent=2, ensure_ascii=False),
            sensor_catalog=json.dumps(load_sensor_specs(), indent=2, ensure_ascii=False),
        )

        # Get VLM client and analyze
        vlm = self._get_vlm_client()
        response = await vlm.chat(
            prompt=prompt,
            image_paths=[image_path],
            temperature=temperature,
            max_tokens=max_tokens,
        )

        # Parse JSON response
        result = parse_json_response(response)

        # Validate structure
        if not isinstance(result, dict):
            raise ValueError("Response must be a dictionary")

        if "deployment_recommendations" not in result:
            raise ValueError("Response missing required field: 'deployment_recommendations'")

        recommendations = result["deployment_recommendations"]
        if not isinstance(recommendations, list):
            raise ValueError("deployment_recommendations must be a list")

        # Validate each recommendation
        for i, recommendation in enumerate(recommendations):
            if not isinstance(recommendation, dict):
                raise ValueError(f"Recommendation at index {i} must be a dictionary")

            required_fields = [
                "activity_id",
                "sensor_type",
                "behavior",
                "recommended_segments",
            ]
            for field in required_fields:
                if field not in recommendation:
                    raise ValueError(
                        f"Recommendation at index {i} missing required field: {field}"
                    )

            recommended_segments = recommendation["recommended_segments"]
            if not isinstance(recommended_segments, list):
                raise ValueError(
                    f"Recommendation at index {i} recommended_segments must be a list"
                )

            if len(recommended_segments) == 0:
                raise ValueError(
                    f"Recommendation at index {i} recommended_segments cannot be empty"
                )

            # Validate each recommended segment
            for j, segment in enumerate(recommended_segments):
                if not isinstance(segment, dict):
                    raise ValueError(
                        f"Recommendation at index {i}, segment at index {j} must be a dictionary"
                    )

                required_segment_fields = [
                    "segment_id",
                    "priority",
                    "rationale",
                    "installation_location",
                ]
                for field in required_segment_fields:
                    if field not in segment:
                        raise ValueError(
                            f"Recommendation at index {i}, segment at index {j} missing required field: {field}"
                        )

                valid_priorities = ["high", "medium", "low"]
                if segment["priority"] not in valid_priorities:
                    raise ValueError(
                        f"Recommendation at index {i}, segment at index {j} priority must be one of {valid_priorities}"
                    )

            # Validate alternative_segments if present
            if "alternative_segments" in recommendation:
                if recommendation["alternative_segments"] is not None:
                    alternative_segments = recommendation["alternative_segments"]
                    if not isinstance(alternative_segments, list):
                        raise ValueError(
                            f"Recommendation at index {i} alternative_segments must be a list or null"
                        )

        return recommendations

    async def close(self) -> None:
        """Close VLM client"""
        if self._vlm_client is not None:
            await self._vlm_client.close()
            self._vlm_client = None
