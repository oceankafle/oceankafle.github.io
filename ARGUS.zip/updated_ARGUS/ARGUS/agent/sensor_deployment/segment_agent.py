"""
Segment Agent
Divides floor plan images into grids for region selection
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

from ..vlm.base_vlm import VLM
from ..factory import get_vlm
from ..utils import parse_json_response
from prompt import manager as prompt_manager


class SegmentAgent:
    """
    Segment Agent for sensor deployment
    
    Analyzes floor plan images and divides them into grids for region selection
    """

    def __init__(
        self,
        *,
        vlm_name: str = "nvidia",
        vlm_kwargs: Optional[dict[str, Any]] = None,
        template_name: str = "sensor_deployment/segment_image",
    ):
        self.vlm_name = vlm_name
        self.vlm_kwargs = vlm_kwargs or {}
        self.template_name = template_name
        self._vlm_client: Optional[VLM] = None

    def _get_vlm_client(self) -> VLM:
        """Get or create VLM client"""
        if self._vlm_client is None:
            self._vlm_client = get_vlm(self.vlm_name, **self.vlm_kwargs)
        return self._vlm_client

    async def segment(
        self,
        *,
        image_path: Path,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> dict[str, Any]:
        """
        Segment floor plan image into grid
        
        Args:
            image_path: Path to the floor plan image
            temperature: Temperature for VLM generation
            max_tokens: Maximum tokens for VLM response
        
        Returns:
            Dictionary containing grid structure with segments
        """
        if not image_path.exists():
            raise FileNotFoundError(f"Image not found: {image_path}")

        # Render prompt template
        prompt = prompt_manager.render(self.template_name)

        # Get VLM client and segment
        vlm = self._get_vlm_client()
        response = await vlm.chat(
            prompt=prompt,
            image_paths=[image_path],
            temperature=temperature,
            max_tokens=max_tokens,
        )

        # Parse JSON response
        result = parse_json_response(response)

        # Validate structure
        if not isinstance(result, dict):
            raise ValueError("Response must be a dictionary")

        if "grid" not in result:
            raise ValueError("Response missing required field: 'grid'")

        grid = result["grid"]
        if not isinstance(grid, dict):
            raise ValueError("grid must be a dictionary")

        required_grid_fields = ["rows", "columns", "segments"]
        for field in required_grid_fields:
            if field not in grid:
                raise ValueError(f"grid missing required field: {field}")

        if not isinstance(grid["rows"], int) or grid["rows"] < 1:
            raise ValueError("grid.rows must be a positive integer")

        if not isinstance(grid["columns"], int) or grid["columns"] < 1:
            raise ValueError("grid.columns must be a positive integer")

        segments = grid["segments"]
        if not isinstance(segments, list):
            raise ValueError("grid.segments must be a list")

        # Validate each segment
        for i, segment in enumerate(segments):
            if not isinstance(segment, dict):
                raise ValueError(f"Segment at index {i} must be a dictionary")

            required_segment_fields = ["id", "row", "column", "bounds", "description"]
            for field in required_segment_fields:
                if field not in segment:
                    raise ValueError(f"Segment at index {i} missing required field: {field}")

            if not isinstance(segment["bounds"], dict):
                raise ValueError(f"Segment at index {i} bounds must be a dictionary")

            required_bounds_fields = ["top", "bottom", "left", "right"]
            for field in required_bounds_fields:
                if field not in segment["bounds"]:
                    raise ValueError(
                        f"Segment at index {i} bounds missing required field: {field}"
                    )

        return result

    async def close(self) -> None:
        """Close VLM client"""
        if self._vlm_client is not None:
            await self._vlm_client.close()
            self._vlm_client = None

