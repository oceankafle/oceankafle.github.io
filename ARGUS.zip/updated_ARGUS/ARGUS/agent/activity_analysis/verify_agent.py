"""
Verify Agent
Verifies and adjusts activities including newly decomposed sequences
"""

from __future__ import annotations

from typing import Any, Optional

from ..llm.base_llm import LLM
from ..factory import get_llm
from ..utils import parse_json_response
from prompt import manager as prompt_manager


class VerifyAgent:
    """
    Verify Agent for activity analysis
    
    Verifies and adjusts activities including:
    - New activities with sequences from decompose agent
    - Activities to be updated
    """

    def __init__(
        self,
        *,
        llm_name: str = "gemini",
        llm_kwargs: Optional[dict[str, Any]] = None,
        template_name: str = "activity_analysis/verify_activities",
    ):
        self.llm_name = llm_name
        self.llm_kwargs = llm_kwargs or {}
        self.template_name = template_name
        self._llm_client: Optional[LLM] = None

    def _get_llm_client(self) -> LLM:
        """Get or create LLM client"""
        if self._llm_client is None:
            self._llm_client = get_llm(self.llm_name, **self.llm_kwargs)
        return self._llm_client

    async def verify(
        self,
        *,
        current_activities: list[dict[str, Any]],
        new_activities: list[dict[str, Any]],
        activities_to_update: list[dict[str, Any]],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        """
        Verify and adjust activities; returns only new and modified items.

        Args:
            current_activities: List of current activities (excluding ones being updated)
            new_activities: List of new activities with sequences from decompose agent
            activities_to_update: List of activities to update (with modifications)
            temperature: Temperature for LLM generation
            max_tokens: Maximum tokens for LLM response

        Returns:
            List of modified_activities: each item has "action" in ("create", "update", "delete"),
            and for create/update: "id" (optional for create), "description", "sequence";
            for delete: "id", "reason" (optional).
        """
        # Render prompt template
        import json
        prompt = prompt_manager.render(
            self.template_name,
            current_activities=json.dumps(current_activities, indent=2, ensure_ascii=False),
            new_activities=json.dumps(new_activities, indent=2, ensure_ascii=False),
            activities_to_update=json.dumps(activities_to_update, indent=2, ensure_ascii=False),
        )

        # Get LLM client and verify
        llm = self._get_llm_client()
        response = await llm.chat(
            prompt=prompt,
            temperature=temperature,
            max_tokens=max_tokens,
        )

        # Parse JSON response
        result = parse_json_response(response)

        # Validate structure (new schema: only new + modified activities)
        if not isinstance(result, dict):
            raise ValueError("Response must be a dictionary")

        if "modified_activities" not in result:
            raise ValueError("Response missing required field: 'modified_activities'")

        modified_activities = result["modified_activities"]
        if not isinstance(modified_activities, list):
            raise ValueError("modified_activities must be a list")

        # Validate each modified activity: action + id (or placeholder) + fields by action
        for i, item in enumerate(modified_activities):
            if not isinstance(item, dict):
                raise ValueError(f"Modified activity at index {i} must be a dictionary")

            action = item.get("action")
            if action not in ("create", "update", "delete"):
                raise ValueError(
                    f"Modified activity at index {i} must have 'action' in "
                    "'create', 'update', 'delete'"
                )

            if action == "delete":
                if "id" not in item:
                    raise ValueError(
                        f"Modified activity at index {i} (delete) missing 'id'"
                    )
                continue

            if "id" not in item and action == "update":
                raise ValueError(
                    f"Modified activity at index {i} (update) missing 'id'"
                )

            if "description" not in item:
                raise ValueError(
                    f"Modified activity at index {i} missing 'description' field"
                )

            if "sequence" not in item:
                item["sequence"] = []
            if not isinstance(item["sequence"], list):
                raise ValueError(
                    f"Modified activity at index {i} sequence must be a list"
                )

            # Validate sequence steps (string or structured step object)
            for j, step in enumerate(item["sequence"]):
                if isinstance(step, str):
                    continue
                if not isinstance(step, dict):
                    raise ValueError(
                        f"Modified activity at index {i}, sequence step {j} "
                        "must be a string or object"
                    )
                step_action = step.get("action")
                objects = step.get("objects")
                if objects is None and "object" in step:
                    objects = step.get("object")
                state_change = step.get("state_change")
                if (state_change is None or state_change == "") and "stage_change" in step:
                    state_change = step.get("stage_change")
                if not isinstance(step_action, str) or not step_action.strip():
                    raise ValueError(
                        f"Modified activity at index {i}, step {j} "
                        "missing valid 'action' string"
                    )
                if not isinstance(objects, list) or not all(
                    isinstance(obj, str) for obj in objects
                ):
                    raise ValueError(
                        f"Modified activity at index {i}, step {j} "
                        "must have 'objects' list of strings"
                    )
                if len(objects) == 0:
                    raise ValueError(
                        f"Modified activity at index {i}, step {j} "
                        "must have non-empty 'objects'"
                    )
                if not isinstance(state_change, str) or not state_change.strip():
                    raise ValueError(
                        f"Modified activity at index {i}, step {j} "
                        "missing valid 'state_change' string"
                    )

        return modified_activities

    async def close(self) -> None:
        """Close LLM client"""
        if self._llm_client is not None:
            await self._llm_client.close()
            self._llm_client = None

