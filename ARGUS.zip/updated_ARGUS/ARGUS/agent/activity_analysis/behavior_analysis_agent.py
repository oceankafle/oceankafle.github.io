"""
Behavior Analysis Agent
Generates a detailed behavior sequence based on a spatial report.
"""

from __future__ import annotations

import json
from typing import Any, Optional

from ..factory import get_llm
from ..llm.base_llm import LLM
from ..utils import parse_json_response
from prompt import manager as prompt_manager


class BehaviorAnalysisAgent:
    """
    Behavior Analysis Agent for activity analysis.

    Input: activity description + updated environment info + spatial report
    Output: step-by-step behavior sequence (list[str])
    """

    def __init__(
        self,
        *,
        llm_name: str = "gemini",
        llm_kwargs: Optional[dict[str, Any]] = None,
        template_name: str = "activity_analysis/behavior_analysis",
    ):
        self.llm_name = llm_name
        self.llm_kwargs = llm_kwargs or {}
        self.template_name = template_name
        self._llm_client: Optional[LLM] = None

    def _get_llm_client(self) -> LLM:
        if self._llm_client is None:
            self._llm_client = get_llm(self.llm_name, **self.llm_kwargs)
        return self._llm_client

    async def decompose(
        self,
        *,
        activity_description: str,
        environment_info: dict[str, Any],
        spatial_report: dict[str, Any],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> list[str]:
        prompt = prompt_manager.render(
            self.template_name,
            activity_description=activity_description,
            environment_info=json.dumps(environment_info, indent=2, ensure_ascii=False),
            spatial_report=json.dumps(spatial_report, indent=2, ensure_ascii=False),
        )

        llm = self._get_llm_client()
        response = await llm.chat(
            prompt=prompt,
            temperature=temperature,
            max_tokens=max_tokens,
        )

        result = parse_json_response(response)
        if not isinstance(result, dict):
            raise ValueError("Behavior analysis response must be a JSON object")
        if "sequence" not in result:
            raise ValueError("Response missing required field: 'sequence'")
        sequence = result["sequence"]
        if not isinstance(sequence, list):
            raise ValueError("sequence must be a list")
        for i, step in enumerate(sequence):
            if isinstance(step, str):
                continue
            if not isinstance(step, dict):
                raise ValueError(
                    f"Sequence step at index {i} must be a string or object"
                )
            # Validate structured step shape (action/objects/state_change)
            action = step.get("action")
            objects = step.get("objects")
            if objects is None and "object" in step:
                objects = step.get("object")
            state_change = step.get("state_change")
            if (state_change is None or state_change == "") and "stage_change" in step:
                state_change = step.get("stage_change")
            if not isinstance(action, str) or not action.strip():
                raise ValueError(
                    f"Sequence step at index {i} missing valid 'action' string"
                )
            if not isinstance(objects, list) or not all(
                isinstance(obj, str) for obj in objects
            ):
                raise ValueError(
                    f"Sequence step at index {i} must have 'objects' list of strings"
                )
            if len(objects) == 0:
                raise ValueError(
                    f"Sequence step at index {i} must have non-empty 'objects'"
                )
            if not isinstance(state_change, str) or not state_change.strip():
                raise ValueError(
                    f"Sequence step at index {i} missing valid 'state_change' string"
                )
        return sequence

    async def close(self) -> None:
        if self._llm_client is not None:
            await self._llm_client.close()
            self._llm_client = None

