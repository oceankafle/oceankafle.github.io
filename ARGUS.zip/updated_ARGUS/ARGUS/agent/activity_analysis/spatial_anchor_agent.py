"""
Spatial Anchor Agent
Uses VLM + floor plan image + environment_info to produce a spatial analysis report for an activity.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

from ..factory import get_vlm
from ..utils import load_activity_analysis, parse_json_response
from ..vlm.base_vlm import VLM
from prompt import manager as prompt_manager


class SpatialAnchorAgent:
    """
    Spatial Anchor Agent for activity analysis.

    Outputs a structured spatial report, including:
    - key zones / anchor areas (where user may stay, long/short)
    - paths / transitions between areas (doorway/corridor/room changes)
    - spatial targets (key objects and their likely location)
    - spatial constraints (occlusion/blocking/blind spots)
    """

    def __init__(
        self,
        *,
        vlm_name: str = "nvidia",
        vlm_kwargs: Optional[dict[str, Any]] = None,
        template_name: str = "activity_analysis/spatial_anchor",
    ):
        self.vlm_name = vlm_name
        self.vlm_kwargs = vlm_kwargs or {}
        self.template_name = template_name
        self._vlm_client: Optional[VLM] = None

    def _get_vlm_client(self) -> VLM:
        if self._vlm_client is None:
            self._vlm_client = get_vlm(self.vlm_name, **self.vlm_kwargs)
        return self._vlm_client

    async def analyze(
        self,
        *,
        activity_description: str,
        image_path: Path,
        environment_info: Optional[dict[str, Any]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> dict[str, Any]:
        if not image_path.exists():
            raise FileNotFoundError(f"Image not found: {image_path}")

        if environment_info is None:
            data = load_activity_analysis()
            environment_info = data.get("environment_info", {}) or {}

        prompt = prompt_manager.render(
            self.template_name,
            activity_description=activity_description,
            environment_info=json.dumps(environment_info, indent=2, ensure_ascii=False),
        )

        vlm = self._get_vlm_client()
        response = await vlm.chat(
            prompt=prompt,
            image_paths=[image_path],
            temperature=temperature,
            max_tokens=max_tokens,
        )

        result = parse_json_response(response)
        if not isinstance(result, dict):
            raise ValueError("Spatial anchor response must be a JSON object")

        # Minimal validation (keep it flexible for prompt iteration)
        if "anchor_zones" in result and not isinstance(result["anchor_zones"], list):
            raise ValueError("anchor_zones must be a list")
        if "paths" in result:
            if isinstance(result["paths"], list):
                pass
            elif isinstance(result["paths"], str):
                result["paths"] = [result["paths"]]
            elif result["paths"] is None:
                result["paths"] = []
            else:
                result["paths"] = [str(result["paths"])]
        if "spatial_targets" in result and not isinstance(result["spatial_targets"], list):
            raise ValueError("spatial_targets must be a list")
        if "spatial_constraints" in result and not isinstance(
            result["spatial_constraints"], list
        ):
            raise ValueError("spatial_constraints must be a list")

        return result

    async def close(self) -> None:
        if self._vlm_client is not None:
            await self._vlm_client.close()
            self._vlm_client = None

