"""
Manager Agent
Manages activity analysis by analyzing user input and generating action plans
"""

from __future__ import annotations

import json
from typing import Any, Optional

from pathlib import Path

from ..llm.base_llm import LLM
from ..factory import get_llm
from ..utils import (
    load_activity_analysis,
    update_activity_analysis,
    parse_json_response,
)
from prompt import manager as prompt_manager


class ManagerAgent:
    def __init__(
        self,
        *,
        llm_name: str = "gemini",
        llm_kwargs: Optional[dict[str, Any]] = None,
        template_name: str = "activity_analysis/manager_analysis",
    ):
        self.llm_name = llm_name
        self.llm_kwargs = llm_kwargs or {}
        self.template_name = template_name
        self._llm_client: Optional[LLM] = None

    def _get_llm_client(self) -> LLM:
        """Get or create LLM client"""
        if self._llm_client is None:
            self._llm_client = get_llm(self.llm_name, **self.llm_kwargs)
        return self._llm_client

    async def analyze(
        self,
        *,
        user_input: str,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        debug: bool = False,
    ) -> dict[str, Any]:
        # Load current activity analysis data
        data = load_activity_analysis()
        environment_info = data.get("environment_info", {})
        activities = data.get("activities", [])

        # Format existing activities for prompt
        if activities:
            existing_activities_str = json.dumps(activities, indent=2, ensure_ascii=False)
        else:
            existing_activities_str = "[]"

        # Render prompt template
        prompt = prompt_manager.render(
            self.template_name,
            environment_info=json.dumps(environment_info, indent=2, ensure_ascii=False),
            existing_activities=existing_activities_str,
            user_input=user_input,
        )

        # Get LLM client and analyze
        llm = self._get_llm_client()
        response = await llm.chat(
            prompt=prompt,
            temperature=temperature,
            max_tokens=max_tokens,
        )

        # Parse JSON response
        try:
            result = parse_json_response(response)
        except Exception as e:
            # Debug mode: return raw LLM output for inspection (do not swallow errors silently)
            if debug:
                return {
                    "error": f"{e}",
                    "__debug": {
                        "raw_response": response,
                        "prompt": prompt,
                    },
                }
            raise

        # Validate structure
        if not isinstance(result, dict):
            raise ValueError("Response must be a dictionary")

        # ===== Schema normalization (support both new prompt schema and legacy schema) =====
        # New prompt schema (current manager_analysis.md):
        # {
        #   "updated_environment_info": {...} or null,
        #   "actions": [...] or null,
        #   "response": "..."
        # }
        #
        # Legacy schema (older prompt + code):
        # {
        #   "needs_env_update": bool,
        #   "new_environment_info": {...} or null,
        #   "actions": [...],
        #   "response": "..."
        # }
        if "updated_environment_info" not in result:
            # Try to map legacy -> new
            if "needs_env_update" in result:
                needs_env_update = bool(result.get("needs_env_update"))
                if needs_env_update:
                    result["updated_environment_info"] = result.get("new_environment_info")
                else:
                    result["updated_environment_info"] = None
            elif "new_environment_info" in result:
                result["updated_environment_info"] = result.get("new_environment_info")

        # Validate required fields for new schema
        for field in ["updated_environment_info", "actions", "response"]:
            if field not in result:
                raise ValueError(f"Response missing required field: {field}")

        # updated_environment_info: dict or None
        if result["updated_environment_info"] is not None and not isinstance(
            result["updated_environment_info"], dict
        ):
            raise ValueError("updated_environment_info must be a dictionary or null")

        # actions: list or None (prompt may allow null)
        if result["actions"] is None:
            result["actions"] = []
        if not isinstance(result["actions"], list):
            raise ValueError("actions must be a list or null")

        # Validate action structure
        for i, action in enumerate(result["actions"]):
            if not isinstance(action, dict):
                raise ValueError(f"Action at index {i} must be a dictionary")
            
            if "action" not in action:
                raise ValueError(f"Action at index {i} missing 'action' field")
            
            if action["action"] not in ["create", "update"]:
                raise ValueError(
                    f"Action at index {i} has invalid 'action' value: {action['action']}"
                )
            
            if action["action"] == "update" and not action.get("activity_id"):
                raise ValueError(
                    f"Action at index {i} is 'update' but missing 'activity_id' field"
                )
            
            # New prompt uses "description"
            if "description" not in action or not isinstance(action["description"], str):
                # Try legacy field name
                if "activity_description" in action and isinstance(
                    action["activity_description"], str
                ):
                    action["description"] = action["activity_description"]
                else:
                    raise ValueError(f"Action at index {i} missing 'description' field")

        if debug:
            result["__debug"] = {
                "raw_response": response,
                "prompt": prompt,
            }
        return result

    async def process_and_update(
        self,
        *,
        user_input: str,
        image_path: Path,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        decompose_kwargs: Optional[dict[str, Any]] = None,
        behavior_kwargs: Optional[dict[str, Any]] = None,
        verify_kwargs: Optional[dict[str, Any]] = None,
        debug: bool = False,
        return_intermediates: bool = False,
        plan_override: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """
        Analyze user input and update activity_analysis.json accordingly
        
        This method:
        1. Calls analyze() to get the action plan
        2. Updates environment_info if needed
        3. For create actions, calls SpatialAnchorAgent (VLM) then BehaviorAnalysisAgent (LLM) to generate sequences
        4. Calls VerifyAgent to verify and adjust all activities
        5. Updates activity_analysis.json
        
        Args:
            user_input: User's input text
            image_path: Path to the floor plan image (required for spatial anchor agent)
            temperature: Temperature for LLM generation
            max_tokens: Maximum tokens for LLM response
            decompose_kwargs: Optional kwargs for SpatialAnchorAgent (kept name for backward compatibility)
            behavior_kwargs: Optional kwargs for BehaviorAnalysisAgent
            verify_kwargs: Optional kwargs for VerifyAgent
        
        Returns:
            Updated activity analysis data
        """
        from .spatial_anchor_agent import SpatialAnchorAgent
        from .behavior_analysis_agent import BehaviorAnalysisAgent
        from .verify_agent import VerifyAgent

        # Get action plan
        plan = plan_override or await self.analyze(
            user_input=user_input,
            temperature=temperature,
            max_tokens=max_tokens,
            debug=debug,
        )
        # If analyze failed but debug returned an error dict, don't proceed to update file.
        if plan.get("error"):
            return {"__debug": plan.get("__debug", {}), "error": plan["error"]}

        # Load current data
        data = load_activity_analysis()
        all_activities = data.get("activities", [])

        # Update environment_info if needed
        if plan.get("updated_environment_info"):
            update_activity_analysis(environment_info=plan["updated_environment_info"])

        # Separate create and update actions
        actions = plan.get("actions") or []
        create_actions = [a for a in actions if a.get("action") == "create"]
        update_actions = [a for a in actions if a.get("action") == "update"]

        # Process create actions with SpatialAnchorAgent -> BehaviorAnalysisAgent
        new_activities = []
        intermediates: list[dict[str, Any]] = []
        spatial_agent = SpatialAnchorAgent(**(decompose_kwargs or {}))
        behavior_agent = BehaviorAnalysisAgent(**(behavior_kwargs or {}))
        try:
            # Ensure agents see the latest environment_info (after manager updates it)
            latest_env = load_activity_analysis().get("environment_info", {}) or {}
            for action in create_actions:
                activity_description = action["description"]
                
                spatial_report = await spatial_agent.analyze(
                    activity_description=activity_description,
                    image_path=image_path,
                    environment_info=latest_env,
                    temperature=temperature,
                    max_tokens=max_tokens,
                )

                sequence = await behavior_agent.decompose(
                    activity_description=activity_description,
                    environment_info=latest_env,
                    spatial_report=spatial_report,
                    temperature=temperature,
                    max_tokens=max_tokens,
                )
                
                if return_intermediates:
                    intermediates.append(
                        {
                            "activity_description": activity_description,
                            "spatial_report": spatial_report,
                            "sequence": sequence,
                        }
                    )

                new_activities.append({
                    "id": None,  # Will be assigned by verify agent
                    "description": activity_description,
                    "sequence": sequence,
                })
        finally:
            await spatial_agent.close()
            await behavior_agent.close()

        # Prepare activities to update
        activities_to_update = []
        activities_not_being_updated = []
        update_ids = {a["activity_id"] for a in update_actions}
        
        for act in all_activities:
            act_id = act.get("id")
            if act_id in update_ids:
                # This activity is being updated
                update_action = next(a for a in update_actions if a["activity_id"] == act_id)
                updated_act = act.copy()
                
                # Apply modifications
                if "modifications" in update_action and update_action["modifications"]:
                    modifications = {
                        k: v
                        for k, v in update_action["modifications"].items()
                        if k != "description"
                    }
                    updated_act.update(modifications)
                
                # Update description if provided
                if "description" in update_action and update_action["description"]:
                    updated_act["description"] = update_action["description"]
                
                activities_to_update.append(updated_act)
            else:
                # This activity is not being updated
                activities_not_being_updated.append(act)

        # Call VerifyAgent: returns only new + modified activities (create/update/delete)
        verify_agent = VerifyAgent(**(verify_kwargs or {}))
        try:
            modified_activities = await verify_agent.verify(
                current_activities=activities_not_being_updated,
                new_activities=new_activities,
                activities_to_update=activities_to_update,
                temperature=temperature,
                max_tokens=max_tokens,
            )
        finally:
            await verify_agent.close()

        # Merge: unchanged activities + apply modified_activities (create/update/delete)
        all_existing = list(activities_not_being_updated) + list(activities_to_update)
        by_id = {str(a["id"]): dict(a) for a in all_existing}
        order_ids = [str(a["id"]) for a in all_existing]

        max_id = 0
        for act in all_existing:
            try:
                max_id = max(max_id, int(act.get("id", 0)))
            except (ValueError, TypeError):
                pass

        for m in modified_activities:
            action = m.get("action")
            if action == "create":
                max_id += 1
                new_id = str(max_id)
                by_id[new_id] = {
                    "id": new_id,
                    "description": m["description"],
                    "sequence": m.get("sequence", []),
                }
                order_ids.append(new_id)
            elif action == "update":
                aid = str(m["id"])
                by_id[aid] = {
                    "id": aid,
                    "description": m["description"],
                    "sequence": m.get("sequence", []),
                }
                if aid not in order_ids:
                    order_ids.append(aid)
            elif action == "delete":
                aid = str(m["id"])
                by_id.pop(aid, None)
                order_ids = [i for i in order_ids if i != aid]

        verified_activities = [by_id[i] for i in order_ids if i in by_id]

        # Save merged activities
        update_activity_analysis(activities=verified_activities)

        # Return updated data
        updated_data = load_activity_analysis()
        # Expose manager's natural-language reply to UI
        try:
            updated_data = dict(updated_data)
        except Exception:
            updated_data = load_activity_analysis()
            updated_data = dict(updated_data)
        updated_data["__manager_reply"] = (plan.get("response") or "").strip()
        if debug:
            updated_data["__debug"] = plan.get("__debug", {})
            updated_data["__plan"] = {k: v for k, v in plan.items() if k != "__debug"}
        if return_intermediates:
            updated_data["__intermediates"] = intermediates
        return updated_data

    async def close(self) -> None:
        """Close LLM client"""
        if self._llm_client is not None:
            await self._llm_client.close()
            self._llm_client = None

