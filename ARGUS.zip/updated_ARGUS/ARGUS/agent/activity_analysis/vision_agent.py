"""
Vision Analysis Agent
Analyzes floor plan images to identify rooms, devices, and objects
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

from ..vlm.base_vlm import VLM
from ..factory import get_vlm
from ..utils import parse_json_response, update_activity_analysis
from prompt import manager as prompt_manager


class VisionAgent:
    def __init__(
        self,
        *,
        vlm_name: str = "nvidia",
        vlm_kwargs: Optional[dict[str, Any]] = None,
        template_name: str = "activity_analysis/vision_analysis",
    ):
        self.vlm_name = vlm_name
        self.vlm_kwargs = vlm_kwargs or {}
        self.template_name = template_name
        self._vlm_client: Optional[VLM] = None
    
    def _get_vlm_client(self) -> VLM:
        """Get or create VLM client"""
        if self._vlm_client is None:
            self._vlm_client = get_vlm(self.vlm_name, **self.vlm_kwargs)
        return self._vlm_client
    
    async def analyze(
        self,
        *,
        image_path: Path,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> dict[str, Any]:

        if not image_path.exists():
            raise FileNotFoundError(f"Image not found: {image_path}")
        
        # Render prompt template
        prompt = prompt_manager.render(self.template_name)
        
        # Get VLM client and analyze
        vlm = self._get_vlm_client()
        response = await vlm.chat(
            prompt=prompt,
            image_paths=[image_path],
            temperature=temperature,
            max_tokens=max_tokens,
        )
        
        # Parse JSON response
        result = parse_json_response(response)
        
        # Validate structure: should be a dict with room names as keys and lists as values
        if not isinstance(result, dict):
            raise ValueError("Response must be a dictionary with room names as keys")
        
        # Validate that all values are lists
        for room_name, objects in result.items():
            if not isinstance(objects, list):
                raise ValueError(
                    f"Room '{room_name}' must have a list of objects, got {type(objects)}"
                )
            # Validate that list items are strings
            for obj in objects:
                if not isinstance(obj, str):
                    raise ValueError(
                        f"All objects must be strings, found {type(obj)} in room '{room_name}'"
                    )
        
        # Save result to activity_analysis.json
        update_activity_analysis(environment_info=result)
        
        return result
    
    async def close(self) -> None:
        """Close VLM client"""
        if self._vlm_client is not None:
            await self._vlm_client.close()
            self._vlm_client = None
    

