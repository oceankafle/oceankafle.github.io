"""
Offline evaluation helper for saved ARGUS deployment state.

Usage:
    python scripts/evaluate_argus.py
    python scripts/evaluate_argus.py --write
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT))

from agent.physical_planning import (  # noqa: E402
    enrich_deployment_recommendations,
    summarize_deployment_evaluation,
)
from agent.sensor_specs import apply_sensor_constraints  # noqa: E402
from agent.utils import load_activity_analysis, save_activity_analysis  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--write",
        action="store_true",
        help="Update data/activity_analysis.json with filtered suggestions and evaluation summary.",
    )
    args = parser.parse_args()

    data = load_activity_analysis()
    constraints = data.get("constraints", {}) or {}
    sensor_suggestions = apply_sensor_constraints(
        data.get("sensor_suggestions", []) or [],
        constraints,
    )
    recommendations = enrich_deployment_recommendations(
        sensor_suggestions=sensor_suggestions,
        grid=data.get("deployment_grid", {}) or {},
        recommendations=data.get("deployment_recommendations", []) or [],
        constraints=constraints,
        image_path=None,
    )
    summary = summarize_deployment_evaluation(recommendations)

    print(json.dumps(summary, indent=2))

    if args.write:
        data["sensor_suggestions"] = sensor_suggestions
        data["deployment_recommendations"] = recommendations
        data["evaluation_summary"] = summary
        save_activity_analysis(data)
        print("Updated data/activity_analysis.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
