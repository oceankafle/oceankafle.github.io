"""
Test script for Vision Agent
"""

import asyncio
import os
import sys
from pathlib import Path

# Add parent directory to path
repo_root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(repo_root))

from agent.activity_analysis.vision_agent import VisionAgent


async def test_vision_analysis():
    """Test vision analysis with a floor plan image"""
    print("=" * 80)
    print("Testing Vision Agent - Floor Plan Analysis")
    print("=" * 80)
    
    try:
        agent = VisionAgent(vlm_name="nvidia")
        
        # Try to find a test image
        test_image_path = Path("data/layouts/0.jpeg")
        
        if not test_image_path.exists():
            print(f"⚠ Test image not found: {test_image_path}")
            print("Please provide a floor plan image to test.\n")
            return
        
        print(f"Analyzing image: {test_image_path}\n")
        print("Analysis in progress...")
        print("-" * 80)
        
        result = await agent.analyze(
            image_path=test_image_path,
            temperature=0.7,
            max_tokens=2000
        )
        
        print("\nAnalysis Result:")
        print("=" * 80)
        import json
        print(json.dumps(result, indent=2, ensure_ascii=False))
        print("=" * 80)
        
        # Validate result structure
        assert isinstance(result, dict), "Result must be a dictionary"
        
        print(f"\n✓ Found {len(result)} rooms")
        for room_name, objects in result.items():
            print(f"  - {room_name}: {len(objects)} objects")
            if objects:
                print(f"    Objects: {', '.join(objects[:10])}")  # Show first 10
                if len(objects) > 10:
                    print(f"    ... and {len(objects) - 10} more")
        
        print("\n✓ Vision analysis test completed successfully\n")
        
        await agent.close()
        
    except Exception as e:
        print(f"✗ Vision analysis test failed: {e}\n")
        import traceback
        traceback.print_exc()


def test_vision_analysis_sync():
    """Test synchronous vision analysis (non-async function)"""
    print("=" * 80)
    print("Testing Vision Agent - Synchronous Analysis")
    print("=" * 80)
    
    try:
        agent = VisionAgent(vlm_name="nvidia")
        
        test_image_path = Path("data/layouts/1.png")
        
        if not test_image_path.exists():
            print(f"⚠ Test image not found: {test_image_path}\n")
            return
        
        print(f"Analyzing image: {test_image_path}\n")
        print("Analysis in progress...")
        
        result = agent.analyze_sync(
            image_path=test_image_path,
            temperature=0.7,
            max_tokens=2000
        )
        
        print(f"✓ Analysis completed. Found {len(result.get('rooms', []))} rooms\n")
        
        agent.close_sync()
        
    except Exception as e:
        print(f"✗ Synchronous analysis test failed: {e}\n")
        import traceback
        traceback.print_exc()


async def main():
    """Main test function"""
    print("\n" + "=" * 80)
    print("Vision Agent Test Suite")
    print("=" * 80 + "\n")
    
    # Check environment variables
    if not os.getenv("DASHSCOPE_API_KEY"):
        print("⚠ Warning: DASHSCOPE_API_KEY not set")
        print("Please set the required environment variables before running tests.\n")
        print("You can copy env.example to .env and fill in your credentials.\n")
        return
    
    print("✓ DASHSCOPE_API_KEY found\n")
    
    # Run tests
    await test_vision_analysis()
    
    # Run sync test separately (not in async context)
    print("\n")
    test_vision_analysis_sync()
    
    print("=" * 80)
    print("All Vision Agent tests completed")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    asyncio.run(main())

