"""
Test script for LLM clients (DeepSeek and GPT) with messages format
Tests both regular and streaming chat
"""

import asyncio
import os
import sys
from pathlib import Path

# Add parent directory to path to import agent module
repo_root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(repo_root))

from agent.llm.deepseek_client import DeepSeekClient
from agent.llm.gpt_client import GPTClient


async def test_deepseek_regular():
    """Test DeepSeek regular chat with messages"""
    print("=" * 80)
    print("Testing DeepSeek - Regular Chat (messages format)")
    print("=" * 80)
    
    try:
        llm = DeepSeekClient()
        
        messages = [
            {"role": "user", "content": "Introduce artificial intelligence in one sentence."}
        ]
        
        print(f"Messages: {messages}\n")
        print("Response:")
        print("-" * 80)
        
        response = await llm.chat(
            messages=messages,
            temperature=0.7,
            max_tokens=200
        )
        
        print(response)
        print("-" * 80)
        print("\n✓ DeepSeek regular chat test completed successfully\n")
        
        await llm.close()
        
    except Exception as e:
        print(f"✗ DeepSeek regular chat test failed: {e}\n")
        import traceback
        traceback.print_exc()


async def test_deepseek_streaming():
    """Test DeepSeek streaming chat with messages"""
    print("=" * 80)
    print("Testing DeepSeek - Streaming Chat (messages format)")
    print("=" * 80)
    
    try:
        llm = DeepSeekClient()
        
        messages = [
            {"role": "user", "content": "Introduce the basic concepts of machine learning in a short paragraph."}
        ]
        
        print(f"Messages: {messages}\n")
        print("Streaming Response:")
        print("-" * 80)
        
        full_response = ""
        async for token in llm.stream_chat(
            messages=messages,
            temperature=0.7,
            max_tokens=300
        ):
            print(token, end="", flush=True)
            full_response += token
        
        print("\n" + "-" * 80)
        print(f"\nTotal characters received: {len(full_response)}")
        print("✓ DeepSeek streaming chat test completed successfully\n")
        
        await llm.close()
        
    except Exception as e:
        print(f"✗ DeepSeek streaming chat test failed: {e}\n")
        import traceback
        traceback.print_exc()


async def test_gpt_regular():
    """Test GPT regular chat with messages"""
    print("=" * 80)
    print("Testing GPT - Regular Chat (messages format)")
    print("=" * 80)
    
    try:
        llm = GPTClient()
        
        messages = [
            {"role": "user", "content": "Introduce artificial intelligence in one sentence."}
        ]
        
        print(f"Messages: {messages}\n")
        print("Response:")
        print("-" * 80)
        
        response = await llm.chat(
            messages=messages,
            temperature=0.7,
            max_tokens=200
        )
        
        print(response)
        print("-" * 80)
        print("\n✓ GPT regular chat test completed successfully\n")
        
        await llm.close()
        
    except Exception as e:
        print(f"✗ GPT regular chat test failed: {e}\n")
        import traceback
        traceback.print_exc()


async def test_gpt_streaming():
    """Test GPT streaming chat with messages"""
    print("=" * 80)
    print("Testing GPT - Streaming Chat (messages format)")
    print("=" * 80)
    
    try:
        llm = GPTClient()
        
        messages = [
            {"role": "user", "content": "Introduce the basic concepts of machine learning in a short paragraph."}
        ]
        
        print(f"Messages: {messages}\n")
        print("Streaming Response:")
        print("-" * 80)
        
        full_response = ""
        async for token in llm.stream_chat(
            messages=messages,
            temperature=0.7,
            max_tokens=300
        ):
            print(token, end="", flush=True)
            full_response += token
        
        print("\n" + "-" * 80)
        print(f"\nTotal characters received: {len(full_response)}")
        print("✓ GPT streaming chat test completed successfully\n")
        
        await llm.close()
        
    except Exception as e:
        print(f"✗ GPT streaming chat test failed: {e}\n")
        import traceback
        traceback.print_exc()


async def test_multi_turn_conversation():
    """Test multi-turn conversation with messages"""
    print("=" * 80)
    print("Testing Multi-turn Conversation (messages format)")
    print("=" * 80)
    
    try:
        # Test with DeepSeek
        print("\n1. Testing with DeepSeek:")
        print("-" * 80)
        llm = DeepSeekClient()
        
        messages = [
            {"role": "user", "content": "My name is John."},
            {"role": "assistant", "content": "Hello, John! Nice to meet you."},
            {"role": "user", "content": "Remember my name and tell me what the weather is like today."}
        ]
        
        print(f"Messages: {messages}\n")
        print("Response:")
        print("-" * 80)
        
        response = await llm.chat(
            messages=messages,
            temperature=0.7,
            max_tokens=200
        )
        
        print(response)
        print("-" * 80)
        await llm.close()
        
        # Test with GPT
        print("\n2. Testing with GPT:")
        print("-" * 80)
        llm = GPTClient()
        
        messages = [
            {"role": "user", "content": "My name is Jane."},
            {"role": "assistant", "content": "Hello, Jane! Nice to meet you."},
            {"role": "user", "content": "Remember my name and tell me what the weather is like today."}
        ]
        
        print(f"Messages: {messages}\n")
        print("Response:")
        print("-" * 80)
        
        response = await llm.chat(
            messages=messages,
            temperature=0.7,
            max_tokens=200
        )
        
        print(response)
        print("-" * 80)
        await llm.close()
        
        print("\n✓ Multi-turn conversation test completed successfully\n")
        
    except Exception as e:
        print(f"✗ Multi-turn conversation test failed: {e}\n")
        import traceback
        traceback.print_exc()


async def main():
    """Main test function"""
    print("\n" + "=" * 80)
    print("LLM Messages Format Test Suite")
    print("=" * 80 + "\n")
    
    # Check environment variables
    has_deepseek = bool(os.getenv("DEEPSEEK_API_KEY"))
    has_gpt = bool(os.getenv("AZURE_OPENAI_API_KEY"))
    
    if not has_deepseek and not has_gpt:
        print("⚠ Warning: No API keys found")
        print("Please set DEEPSEEK_API_KEY or AZURE_OPENAI_API_KEY in your .env file\n")
    else:
        if has_deepseek:
            print("✓ DEEPSEEK_API_KEY found")
        if has_gpt:
            print("✓ AZURE_OPENAI_API_KEY found")
        print()
    
    # Run tests
    if has_deepseek:
        await test_deepseek_regular()
        await test_deepseek_streaming()
    else:
        print("⚠ Skipping DeepSeek tests (no API key)\n")
    
    if has_gpt:
        await test_gpt_regular()
        await test_gpt_streaming()
    else:
        print("⚠ Skipping GPT tests (no API key)\n")
    
    if has_deepseek or has_gpt:
        await test_multi_turn_conversation()
    
    print("=" * 80)
    print("All tests completed")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    asyncio.run(main())

