"""
Test script for activity analysis utilities
"""

import sys
from pathlib import Path

# Add parent directory to path
repo_root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(repo_root))

from agent.utils import (
    load_activity_analysis,
    save_activity_analysis,
    update_activity_analysis,
)


def test_load_activity_analysis():
    """Test loading activity_analysis.json"""
    print("=" * 80)
    print("Testing load_activity_analysis")
    print("=" * 80)
    
    try:
        data = load_activity_analysis()
        print("\nLoaded data:")
        import json
        print(json.dumps(data, indent=2, ensure_ascii=False))
        print("\n✓ Load test completed successfully\n")
        
    except Exception as e:
        print(f"✗ Load test failed: {e}\n")
        import traceback
        traceback.print_exc()


def test_save_and_load():
    """Test saving and loading"""
    print("=" * 80)
    print("Testing save and load")
    print("=" * 80)
    
    try:
        # Load original data
        original_data = load_activity_analysis()
        
        # Create test data
        test_data = {
            "analysis_sequence": [],
            "environment_info": {
                "Kitchen": ["Refrigerator", "Stove"],
                "Living Room": ["Sofa", "TV"]
            },
            "agents": {
                "vision": {
                    "enabled": True
                }
            }
        }
        
        # Save test data
        save_activity_analysis(test_data)
        print("✓ Saved test data\n")
        
        # Load and verify
        loaded_data = load_activity_analysis()
        assert loaded_data == test_data, "Loaded data doesn't match saved data"
        print("✓ Loaded data matches saved data\n")
        
        # Restore original data
        save_activity_analysis(original_data)
        print("✓ Restored original data\n")
        
    except Exception as e:
        print(f"✗ Save and load test failed: {e}\n")
        import traceback
        traceback.print_exc()


def test_update_activity_analysis():
    """Test updating activity_analysis"""
    print("=" * 80)
    print("Testing update_activity_analysis")
    print("=" * 80)
    
    try:
        # Load original data
        original_data = load_activity_analysis()
        
        # Update environment_info using kwargs
        new_env_info = {
            "Kitchen": ["Refrigerator", "Stove", "Microwave"],
            "Bedroom1": ["Bed", "Dresser"]
        }
        update_activity_analysis(environment_info=new_env_info)
        print("✓ Updated environment_info using kwargs\n")
        
        # Verify update
        data = load_activity_analysis()
        env_info = data.get("environment_info", {})
        assert env_info == new_env_info, "environment_info doesn't match"
        print(f"✓ Verified environment_info: {list(env_info.keys())}\n")
        
        # Test updating using key/value
        another_env_info = {
            "Living Room": ["Sofa", "TV"]
        }
        update_activity_analysis("environment_info", another_env_info)
        print("✓ Updated environment_info using key/value\n")
        
        # Verify update
        data = load_activity_analysis()
        env_info = data.get("environment_info", {})
        assert env_info == another_env_info, "environment_info doesn't match"
        print(f"✓ Verified environment_info: {list(env_info.keys())}\n")
        
        # Restore original data
        save_activity_analysis(original_data)
        print("✓ Restored original data\n")
        
    except Exception as e:
        print(f"✗ Update activity_analysis test failed: {e}\n")
        import traceback
        traceback.print_exc()


def main():
    """Main test function"""
    print("\n" + "=" * 80)
    print("Activity Analysis Utilities Test Suite")
    print("=" * 80 + "\n")
    
    test_load_activity_analysis()
    test_save_and_load()
    test_update_activity_analysis()
    
    print("=" * 80)
    print("All Activity Analysis Utilities tests completed")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    main()

