"""
Test script for DeepSeek client (both regular and streaming)
"""

import asyncio
import os
import sys
from pathlib import Path

# Add parent directory to path to import agent module
repo_root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(repo_root))

from agent.llm.deepseek_client import DeepSeekClient


async def test_regular_chat():
    """Test regular (non-streaming) chat"""
    print("=" * 80)
    print("Testing Regular Chat")
    print("=" * 80)
    
    try:
        llm = DeepSeekClient()
        
        # Test prompt
        messages = [
            {"role": "user", "content": "Introduce artificial intelligence in one sentence."}
        ]
        
        print(f"Prompt: {messages[0]['content']}\n")
        print("Response:")
        print("-" * 80)
        
        response = await llm.chat(
            messages=messages,
            temperature=0.7,
            max_tokens=200
        )
        
        print(response)
        print("-" * 80)
        print("\n✓ Regular chat test completed successfully\n")
        
        await llm.close()
        
    except Exception as e:
        print(f"✗ Regular chat test failed: {e}\n")
        import traceback
        traceback.print_exc()


async def test_streaming_chat():
    """Test streaming chat"""
    print("=" * 80)
    print("Testing Streaming Chat")
    print("=" * 80)
    
    try:
        llm = DeepSeekClient()
        
        # Test prompt
        messages = [
            {"role": "user", "content": "Introduce the basic concepts of machine learning in a short paragraph."}
        ]
        
        print(f"Prompt: {messages[0]['content']}\n")
        print("Streaming Response:")
        print("-" * 80)
        
        # Collect all tokens for comparison
        full_response = ""
        
        async for token in llm.stream_chat(
            messages=messages,
            temperature=0.7,
            max_tokens=300
        ):
            print(token, end="", flush=True)
            full_response += token
        
        print("\n" + "-" * 80)
        print(f"\nTotal tokens received: {len(full_response)} characters")
        print("✓ Streaming chat test completed successfully\n")
        
        await llm.close()
        
    except Exception as e:
        print(f"✗ Streaming chat test failed: {e}\n")
        import traceback
        traceback.print_exc()


async def test_comparison():
    """Compare regular and streaming chat results"""
    print("=" * 80)
    print("Comparing Regular vs Streaming Chat")
    print("=" * 80)
    
    try:
        llm = DeepSeekClient()
        
        messages = [
            {"role": "user", "content": "Explain what deep learning is in one sentence."}
        ]
        
        print(f"Prompt: {messages[0]['content']}\n")
        
        # Regular chat
        print("1. Regular Chat Result:")
        print("-" * 80)
        regular_response = await llm.chat(
            messages=messages,
            temperature=0.7,
            max_tokens=100
        )
        print(regular_response)
        print("-" * 80)
        
        # Streaming chat
        print("\n2. Streaming Chat Result:")
        print("-" * 80)
        streaming_response = ""
        async for token in llm.stream_chat(
            messages=messages,
            temperature=0.7,
            max_tokens=100
        ):
            print(token, end="", flush=True)
            streaming_response += token
        print("\n" + "-" * 80)
        
        # Compare lengths (they should be similar, might differ slightly due to randomness)
        print(f"\nRegular response length: {len(regular_response)} characters")
        print(f"Streaming response length: {len(streaming_response)} characters")
        print("✓ Comparison test completed\n")
        
        await llm.close()
        
    except Exception as e:
        print(f"✗ Comparison test failed: {e}\n")
        import traceback
        traceback.print_exc()


async def test_factory():
    """Test using factory function"""
    print("=" * 80)
    print("Testing Factory Function")
    print("=" * 80)
    
    try:
        from agent.factory import get_llm
        
        llm = get_llm("deepseek")
        
        messages = [
            {"role": "user", "content": "Introduce the Python programming language in one sentence."}
        ]
        
        print(f"Prompt: {messages[0]['content']}\n")
        print("Response:")
        print("-" * 80)
        
        response = await llm.chat(
            messages=messages,
            temperature=0.7,
            max_tokens=150
        )
        
        print(response)
        print("-" * 80)
        print("\n✓ Factory function test completed successfully\n")
        
        await llm.close()
        
    except Exception as e:
        print(f"✗ Factory function test failed: {e}\n")
        import traceback
        traceback.print_exc()


async def main():
    """Main test function"""
    print("\n" + "=" * 80)
    print("DeepSeek Client Test Suite")
    print("=" * 80 + "\n")
    
    # Check if environment variables are set
    if not os.getenv("DEEPSEEK_API_KEY"):
        print("⚠ Warning: DEEPSEEK_API_KEY not set")
        print("Please set the required environment variables before running tests.\n")
        print("You can copy env.example to .env and fill in your credentials.\n")
    
    # Run tests
    await test_regular_chat()
    await test_streaming_chat()
    await test_comparison()
    await test_factory()
    
    print("=" * 80)
    print("All tests completed")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    asyncio.run(main())

