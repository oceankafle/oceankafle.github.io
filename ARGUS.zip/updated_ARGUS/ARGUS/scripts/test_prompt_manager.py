"""
Test script for PromptManager
"""

import sys
from pathlib import Path

# Add parent directory to path
repo_root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(repo_root))

from prompt import PromptManager, manager


def test_basic_render():
    """Test basic template rendering"""
    print("=" * 80)
    print("Testing Basic Template Rendering")
    print("=" * 80)
    
    try:
        # Test with default manager
        result = manager.render(
            "example",
            name="Alice",
            age=30,
            items=["apple", "banana", "orange"]
        )
        print("\nRendered template:")
        print("-" * 80)
        print(result)
        print("-" * 80)
        print("\n✓ Basic render test completed successfully\n")
        
    except Exception as e:
        print(f"✗ Basic render test failed: {e}\n")
        import traceback
        traceback.print_exc()


def test_custom_manager():
    """Test creating a custom PromptManager"""
    print("=" * 80)
    print("Testing Custom PromptManager")
    print("=" * 80)
    
    try:
        custom_manager = PromptManager(template_dir="prompt/templates")
        result = custom_manager.render(
            "example",
            name="Bob",
            age=25,
            items=["test"]
        )
        print("\nRendered template with custom manager:")
        print("-" * 80)
        print(result)
        print("-" * 80)
        print("\n✓ Custom manager test completed successfully\n")
        
    except Exception as e:
        print(f"✗ Custom manager test failed: {e}\n")
        import traceback
        traceback.print_exc()


def test_template_operations():
    """Test template operations"""
    print("=" * 80)
    print("Testing Template Operations")
    print("=" * 80)
    
    try:
        # List templates
        templates = manager.list_templates()
        print(f"\nAvailable templates: {templates}")
        
        # Check if template exists
        exists = manager.template_exists("example")
        print(f"\nTemplate 'example' exists: {exists}")
        
        # Get template content
        if exists:
            content = manager.get_template_content("example")
            print(f"\nTemplate content (first 200 chars):")
            print("-" * 80)
            print(content[:200])
            print("-" * 80)
        
        # Get template path
        template_path = manager.get_template_path("example")
        print(f"\nTemplate path: {template_path}")
        
        print("\n✓ Template operations test completed successfully\n")
        
    except Exception as e:
        print(f"✗ Template operations test failed: {e}\n")
        import traceback
        traceback.print_exc()


def test_conditional_rendering():
    """Test conditional rendering"""
    print("=" * 80)
    print("Testing Conditional Rendering")
    print("=" * 80)
    
    try:
        # Test with age and items
        result1 = manager.render(
            "example",
            name="Charlie",
            age=35,
            items=["item1", "item2"]
        )
        print("\nWith age and items:")
        print("-" * 80)
        print(result1)
        print("-" * 80)
        
        # Test without age and items (using optional_variables)
        result2 = manager.render(
            "example",
            name="David",
            optional_variables={"age", "items"}
        )
        print("\nWithout age and items (optional):")
        print("-" * 80)
        print(result2)
        print("-" * 80)
        
        # Test with only name (using validate=False to skip validation)
        result3 = manager.render(
            "example",
            name="Eve",
            validate=False
        )
        print("\nWith only name (validate=False):")
        print("-" * 80)
        print(result3)
        print("-" * 80)
        
        print("\n✓ Conditional rendering test completed successfully\n")
        
    except Exception as e:
        print(f"✗ Conditional rendering test failed: {e}\n")
        import traceback
        traceback.print_exc()


def test_template_validation():
    """Test template validation"""
    print("=" * 80)
    print("Testing Template Validation")
    print("=" * 80)
    
    try:
        # Valid template
        result = manager.validate_template("example", name="Eve", age=28)
        print(f"\nValidation result: {result}")
        
        if result["valid"]:
            print("✓ Template validation passed\n")
        else:
            print(f"✗ Template validation failed: {result['errors']}\n")
        
    except Exception as e:
        print(f"✗ Template validation test failed: {e}\n")
        import traceback
        traceback.print_exc()


def main():
    """Main test function"""
    print("\n" + "=" * 80)
    print("PromptManager Test Suite")
    print("=" * 80 + "\n")
    
    test_basic_render()
    test_custom_manager()
    test_template_operations()
    test_conditional_rendering()
    test_template_validation()
    
    print("=" * 80)
    print("All PromptManager tests completed")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    main()

