"""
Test script for Agent class (both LLM and VLM)
"""

import asyncio
import os
import sys
from pathlib import Path

# Add parent directory to path to import agent module
repo_root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(repo_root))

from agent import Agent


async def test_llm_agent():
    """Test Agent with LLM (DeepSeek)"""
    print("=" * 80)
    print("Testing Agent with LLM (DeepSeek)")
    print("=" * 80)
    
    try:
        agent = Agent(client_type="llm", client_name="deepseek")
        
        # Test with messages
        messages = [
            {"role": "user", "content": "Introduce artificial intelligence in one sentence."}
        ]
        
        print(f"Messages: {messages}\n")
        print("Response:")
        print("-" * 80)
        
        response = await agent.chat(messages=messages, temperature=0.7, max_tokens=200)
        print(response)
        print("-" * 80)
        print("\n✓ LLM Agent test completed successfully\n")
        
        await agent.close()
        
    except Exception as e:
        print(f"✗ LLM Agent test failed: {e}\n")
        import traceback
        traceback.print_exc()


async def test_llm_agent_streaming():
    """Test Agent with LLM streaming"""
    print("=" * 80)
    print("Testing Agent with LLM (Streaming)")
    print("=" * 80)
    
    try:
        agent = Agent(client_type="llm", client_name="deepseek")
        
        prompt = "Introduce machine learning in a short paragraph."
        print(f"Prompt: {prompt}\n")
        print("Streaming Response:")
        print("-" * 80)
        
        full_response = ""
        async for token in agent.stream_chat(prompt=prompt, temperature=0.7, max_tokens=300):
            print(token, end="", flush=True)
            full_response += token
        
        print("\n" + "-" * 80)
        print(f"\nTotal characters: {len(full_response)}")
        print("✓ LLM Agent streaming test completed successfully\n")
        
        await agent.close()
        
    except Exception as e:
        print(f"✗ LLM Agent streaming test failed: {e}\n")
        import traceback
        traceback.print_exc()


async def test_vlm_agent():
    """Test Agent with VLM (Qwen)"""
    print("=" * 80)
    print("Testing Agent with VLM (Qwen)")
    print("=" * 80)
    
    try:
        agent = Agent(client_type="vlm", client_name="qwen")
        
        prompt = "Describe this image."
        test_image_path = Path("data/layouts/1.png")
        
        image_paths = None
        if test_image_path.exists():
            image_paths = [test_image_path]
            print(f"Using image: {test_image_path}\n")
        else:
            print("⚠ No test image found. Testing without image.\n")
        
        print(f"Prompt: {prompt}\n")
        print("Response:")
        print("-" * 80)
        
        response = await agent.chat(
            prompt=prompt,
            image_paths=image_paths,
            temperature=0.7,
            max_tokens=500
        )
        print(response)
        print("-" * 80)
        print("\n✓ VLM Agent test completed successfully\n")
        
        await agent.close()
        
    except Exception as e:
        print(f"✗ VLM Agent test failed: {e}\n")
        import traceback
        traceback.print_exc()


async def test_agent_sync():
    """Test Agent with synchronous interface"""
    print("=" * 80)
    print("Testing Agent Synchronous Interface")
    print("=" * 80)
    
    try:
        # Test LLM sync
        print("\n1. LLM Sync Test:")
        print("-" * 80)
        agent = Agent(client_type="llm", client_name="deepseek")
        response = agent.chat_sync(prompt="Explain deep learning in one sentence.", max_tokens=100)
        print(response)
        print("-" * 80)
        agent.close_sync()
        
        # Test VLM sync
        print("\n2. VLM Sync Test:")
        print("-" * 80)
        agent = Agent(client_type="vlm", client_name="qwen")
        test_image_path = Path("data/layouts/1.png")
        image_paths = [test_image_path] if test_image_path.exists() else None
        response = agent.chat_sync(
            prompt="Describe this image.",
            image_paths=image_paths,
            max_tokens=300
        )
        print(response)
        print("-" * 80)
        agent.close_sync()
        
        print("\n✓ Agent sync test completed successfully\n")
        
    except Exception as e:
        print(f"✗ Agent sync test failed: {e}\n")
        import traceback
        traceback.print_exc()


async def main():
    """Main test function"""
    print("\n" + "=" * 80)
    print("Agent Test Suite")
    print("=" * 80 + "\n")
    
    # Check environment variables
    has_deepseek = bool(os.getenv("DEEPSEEK_API_KEY"))
    has_qwen = bool(os.getenv("DASHSCOPE_API_KEY"))
    
    if not has_deepseek and not has_qwen:
        print("⚠ Warning: No API keys found")
        print("Please set DEEPSEEK_API_KEY or DASHSCOPE_API_KEY in your .env file\n")
    else:
        if has_deepseek:
            print("✓ DEEPSEEK_API_KEY found")
        if has_qwen:
            print("✓ DASHSCOPE_API_KEY found")
        print()
    
    # Run tests
    if has_deepseek:
        await test_llm_agent()
        await test_llm_agent_streaming()
    else:
        print("⚠ Skipping LLM tests (no DEEPSEEK_API_KEY)\n")
    
    if has_qwen:
        await test_vlm_agent()
    else:
        print("⚠ Skipping VLM tests (no DASHSCOPE_API_KEY)\n")
    
    if has_deepseek or has_qwen:
        await test_agent_sync()
    
    print("=" * 80)
    print("All Agent tests completed")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    asyncio.run(main())

