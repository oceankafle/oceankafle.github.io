"""
Test script for Gemini VLM client (both regular and streaming)
"""

import asyncio
import os
import sys
from pathlib import Path

# Add parent directory to path to import agent module
repo_root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(repo_root))

from agent.vlm.gemini_client import GeminiVLMClient
from agent.factory import get_vlm


async def test_regular_chat():
    """Test regular (non-streaming) chat with image"""
    print("=" * 80)
    print("Testing Gemini VLM - Regular Chat")
    print("=" * 80)
    
    try:
        vlm = GeminiVLMClient()
        
        # Test prompt
        prompt = "Describe the content of this image in detail."
        
        # Try to find a test image, or use a placeholder path
        # You can modify this path to point to an actual image
        test_image_path = Path("/Users/sachikataria/Desktop/GeorgiaTech/MUC/ARGUS/scripts/1.png") # Modify this path as needed
        
        image_paths = None
        if test_image_path.exists():
            image_paths = [test_image_path]
            print(f"Using image: {test_image_path}\n")
        else:
            print("⚠ No test image found. Testing without image.\n")
        
        print(f"Prompt: {prompt}\n")
        print("Response:")
        print("-" * 80)
        
        response = await vlm.chat(
            prompt=prompt,
            image_paths=image_paths,
            temperature=0.7,
            max_tokens=500
        )
        
        print(response)
        print("-" * 80)
        print("\n✓ Regular chat test completed successfully\n")
        
        await vlm.close()
        
    except Exception as e:
        print(f"✗ Regular chat test failed: {e}\n")
        import traceback
        traceback.print_exc()


async def test_streaming_chat():
    """Test streaming chat with image"""
    print("=" * 80)
    print("Testing Gemini VLM - Streaming Chat")
    print("=" * 80)
    
    try:
        vlm = GeminiVLMClient()
        
        prompt = "Describe this image in a short paragraph."
        
        # Try to find a test image
        test_image_path = Path("/Users/sachikataria/Desktop/GeorgiaTech/MUC/ARGUS/scripts/1.png")
        
        image_paths = None
        if test_image_path.exists():
            image_paths = [test_image_path]
            print(f"Using image: {test_image_path}\n")
        else:
            print("⚠ No test image found. Testing without image.\n")
        
        print(f"Prompt: {prompt}\n")
        print("Streaming Response:")
        print("-" * 80)
        
        full_response = ""
        async for token in vlm.stream_chat(
            prompt=prompt,
            image_paths=image_paths,
            temperature=0.7,
            max_tokens=500
        ):
            print(token, end="", flush=True)
            full_response += token
        
        print("\n" + "-" * 80)
        print(f"\nTotal characters received: {len(full_response)}")
        print("✓ Streaming chat test completed successfully\n")
        
        await vlm.close()
        
    except Exception as e:
        print(f"✗ Streaming chat test failed: {e}\n")
        import traceback
        traceback.print_exc()


async def test_factory():
    """Test using factory function"""
    print("=" * 80)
    print("Testing Gemini VLM - Factory Function")
    print("=" * 80)
    
    try:
        vlm = get_vlm("gemini")
        
        prompt = "What is in this image?"
        
        # Try to find a test image
        test_image_path = Path("/Users/sachikataria/Desktop/GeorgiaTech/MUC/ARGUS/scripts/1.png")
        
        image_paths = None
        if test_image_path.exists():
            image_paths = [test_image_path]
            print(f"Using image: {test_image_path}\n")
        else:
            print("⚠ No test image found. Testing without image.\n")
        
        print(f"Prompt: {prompt}\n")
        print("Response:")
        print("-" * 80)
        
        response = await vlm.chat(
            prompt=prompt,
            image_paths=image_paths,
            temperature=0.7,
            max_tokens=300
        )
        
        print(response)
        print("-" * 80)
        print("\n✓ Factory function test completed successfully\n")
        
        await vlm.close()
        
    except Exception as e:
        print(f"✗ Factory function test failed: {e}\n")
        import traceback
        traceback.print_exc()


async def test_multiple_images():
    """Test with multiple images"""
    print("=" * 80)
    print("Testing Gemini VLM - Multiple Images")
    print("=" * 80)
    
    try:
        vlm = GeminiVLMClient()
        
        prompt = "Compare the similarities and differences between these two images."
        
        # Try to find test images
        test_image1 = Path("/Users/sachikataria/Desktop/GeorgiaTech/MUC/ARGUS/scripts/1-1-Dogwood-Pine-one-bedroom-one-bath-standard.jpeg")
        test_image2 = Path("/Users/sachikataria/Desktop/GeorgiaTech/MUC/ARGUS/scripts/1-1-Wisteria-one-bedroom-one-bath-renovated.jpeg")
        
        image_paths = []
        if test_image1.exists():
            image_paths.append(test_image1)
        if test_image2.exists():
            image_paths.append(test_image2)
        
        if not image_paths:
            print("⚠ No test images found. Skipping multiple images test.\n")
            await vlm.close()
            return
        
        print(f"Using {len(image_paths)} image(s): {[str(p) for p in image_paths]}\n")
        print(f"Prompt: {prompt}\n")
        print("Response:")
        print("-" * 80)
        
        response = await vlm.chat(
            prompt=prompt,
            image_paths=image_paths,
            temperature=0.7,
            max_tokens=500
        )
        
        print(response)
        print("-" * 80)
        print("\n✓ Multiple images test completed successfully\n")
        
        await vlm.close()
        
    except Exception as e:
        print(f"✗ Multiple images test failed: {e}\n")
        import traceback
        traceback.print_exc()


async def test_with_custom_image_path():
    """Test with custom image path provided as argument"""
    print("=" * 80)
    print("Testing Gemini VLM - Custom Image Path")
    print("=" * 80)
    print("\nUsage: python test_gemini_vlm.py <image_path>")
    print("Example: python test_gemini_vlm.py /path/to/image.jpg\n")
    
    if len(sys.argv) > 1:
        image_path = Path(sys.argv[1])
        if not image_path.exists():
            print(f"✗ Image not found: {image_path}\n")
            return
        
        try:
            vlm = GeminiVLMClient()
            
            prompt = "Describe this image in detail."
            
            print(f"Using image: {image_path}\n")
            print(f"Prompt: {prompt}\n")
            print("Response:")
            print("-" * 80)
            
            response = await vlm.chat(
                prompt=prompt,
                image_paths=[image_path],
                temperature=0.7,
                max_tokens=500
            )
            
            print(response)
            print("-" * 80)
            print("\n✓ Custom image path test completed successfully\n")
            
            await vlm.close()
            
        except Exception as e:
            print(f"✗ Custom image path test failed: {e}\n")
            import traceback
            traceback.print_exc()
    else:
        print("No image path provided. Skipping custom image test.\n")


async def main():
    """Main test function"""
    print("\n" + "=" * 80)
    print("Gemini VLM Client Test Suite")
    print("=" * 80 + "\n")
    
    # Check if environment variables are set
    if not os.getenv("GEMINI_API_KEY"):
        print("⚠ Warning: GEMINI_API_KEY not set")
        print("Please set the required environment variables before running tests.\n")
        print("You can copy env.example to .env and fill in your credentials.\n")
    else:
        print("✓ GEMINI_API_KEY found\n")
    
    # Run tests
    await test_regular_chat()
    await test_streaming_chat()
    await test_factory()
    await test_multiple_images()
    await test_with_custom_image_path()
    
    print("=" * 80)
    print("All tests completed")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    asyncio.run(main())

