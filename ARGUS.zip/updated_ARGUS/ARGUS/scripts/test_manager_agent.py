"""
Test script for Manager Agent
"""

import asyncio
import os
import sys
from pathlib import Path

repo_root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(repo_root))

from agent.activity_analysis.manager_agent import ManagerAgent
from agent.utils import load_activity_analysis, update_activity_analysis
import json


async def test_manager_analysis():
    """Test manager agent analysis"""
    print("=" * 80)
    print("Testing Manager Agent - Analysis")
    print("=" * 80)

    try:
        # Initialize with some test data
        update_activity_analysis(
            environment_info={
                "Kitchen": ["Refrigerator", "Stove", "Microwave"],
                "Living Room": ["Sofa", "TV"],
            },
            activities=[
                {"id": "1", "description": "preparing a cup of tea"},
                {"id": "2", "description": "watching television"},
            ],
        )

        agent = ManagerAgent(llm_name="gemini")

        user_input = "I want to detect when someone is cooking food in the kitchen"

        print(f"\nUser Input: {user_input}\n")
        print("Analysis in progress...")
        print("-" * 80)

        result = await agent.analyze(
            user_input=user_input,
            temperature=0.7,
            max_tokens=2000,
        )

        print("\nAnalysis Result:")
        print("=" * 80)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        print("=" * 80)

        # Validate result structure
        assert isinstance(result, dict), "Result must be a dictionary"
        assert "needs_env_update" in result, "Result must contain 'needs_env_update'"
        assert "actions" in result, "Result must contain 'actions'"
        assert isinstance(result["actions"], list), "Actions must be a list"

        print("\n✓ Manager analysis test completed successfully\n")

        await agent.close()

    except Exception as e:
        print(f"✗ Manager analysis test failed: {e}\n")
        import traceback

        traceback.print_exc()


async def test_manager_process_and_update():
    """Test manager agent process and update"""
    print("=" * 80)
    print("Testing Manager Agent - Process and Update")
    print("=" * 80)

    try:
        # Initialize with some test data
        update_activity_analysis(
            environment_info={
                "Kitchen": ["Refrigerator", "Stove"],
                "Bedroom": ["Bed", "Desk"],
            },
            activities=[
                {"id": "1", "description": "preparing a cup of tea"},
            ],
        )

        agent = ManagerAgent(llm_name="gemini")

        user_input = "I want to detect when someone is eating a meal"

        print(f"\nUser Input: {user_input}\n")
        print("Processing in progress...")
        print("-" * 80)

        updated_data = await agent.process_and_update(
            user_input=user_input,
            temperature=0.7,
            max_tokens=2000,
        )

        print("\nUpdated Data:")
        print("=" * 80)
        print(json.dumps(updated_data, indent=2, ensure_ascii=False))
        print("=" * 80)

        # Verify activities were updated
        assert "activities" in updated_data, "Updated data must contain 'activities'"
        activities = updated_data["activities"]
        assert isinstance(activities, list), "Activities must be a list"

        print(f"\n✓ Found {len(activities)} activities")
        for act in activities:
            print(f"  - ID {act.get('id')}: {act.get('description')}")

        print("\n✓ Manager process and update test completed successfully\n")

        await agent.close()

    except Exception as e:
        print(f"✗ Manager process and update test failed: {e}\n")
        import traceback

        traceback.print_exc()


async def test_manager_duplicate_detection():
    """Test manager agent duplicate detection"""
    print("=" * 80)
    print("Testing Manager Agent - Duplicate Detection")
    print("=" * 80)

    try:
        # Initialize with existing activity
        update_activity_analysis(
            environment_info={"Kitchen": ["Refrigerator"]},
            activities=[
                {"id": "1", "description": "preparing a cup of tea"},
            ],
        )

        agent = ManagerAgent(llm_name="gemini")

        # Try to add a duplicate activity
        user_input = "I want to detect when someone is making tea"

        print(f"\nUser Input: {user_input}\n")
        print("Analysis in progress...")
        print("-" * 80)

        result = await agent.analyze(
            user_input=user_input,
            temperature=0.7,
            max_tokens=2000,
        )

        print("\nAnalysis Result:")
        print("=" * 80)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        print("=" * 80)

        # Check if duplicate was detected (should have no create actions for duplicate)
        actions = result.get("actions", [])
        create_actions = [a for a in actions if a.get("action") == "create"]
        
        print(f"\n✓ Found {len(create_actions)} create actions")
        print("✓ Duplicate detection test completed\n")

        await agent.close()

    except Exception as e:
        print(f"✗ Duplicate detection test failed: {e}\n")
        import traceback

        traceback.print_exc()


async def main():
    """Main test function"""
    print("\n" + "=" * 80)
    print("Manager Agent Test Suite")
    print("=" * 80 + "\n")

    # Check if environment variables are set
    if not os.getenv("DEEPSEEK_API_KEY"):
        print("⚠ Warning: DEEPSEEK_API_KEY not set")
        print("Please set the required environment variables before running tests.\n")
        print("You can copy env.example to .env and fill in your credentials.\n")
        return  # Exit if API key is not set

    await test_manager_analysis()
    await test_manager_process_and_update()
    await test_manager_duplicate_detection()

    print("=" * 80)
    print("All Manager Agent tests completed")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    asyncio.run(main())

