"""
Test script for JSON Parser utilities
"""

import sys
from pathlib import Path

# Add parent directory to path
repo_root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(repo_root))

from agent.utils import parse_json_response, parse_json_response_with_schema


def test_parse_basic_json():
    """Test parsing basic JSON"""
    print("=" * 80)
    print("Testing Basic JSON Parsing")
    print("=" * 80)
    
    try:
        response = '{"rooms": [{"room_name": "Living Room"}]}'
        result = parse_json_response(response)
        print(f"Input: {response}")
        print(f"Result: {result}")
        print("✓ Basic JSON parsing test passed\n")
        
    except Exception as e:
        print(f"✗ Basic JSON parsing test failed: {e}\n")
        import traceback
        traceback.print_exc()


def test_parse_json_with_markdown():
    """Test parsing JSON with markdown code blocks"""
    print("=" * 80)
    print("Testing JSON Parsing with Markdown")
    print("=" * 80)
    
    try:
        # Test with ```json
        response1 = '```json\n{"rooms": [{"room_name": "Kitchen"}]}\n```'
        result1 = parse_json_response(response1)
        print(f"Input (```json): {response1}")
        print(f"Result: {result1}")
        print("✓ JSON with ```json test passed\n")
        
        # Test with ```
        response2 = '```\n{"rooms": [{"room_name": "Bedroom"}]}\n```'
        result2 = parse_json_response(response2)
        print(f"Input (```): {response2}")
        print(f"Result: {result2}")
        print("✓ JSON with ``` test passed\n")
        
    except Exception as e:
        print(f"✗ JSON with markdown test failed: {e}\n")
        import traceback
        traceback.print_exc()


def test_parse_json_with_validation():
    """Test parsing JSON with schema validation"""
    print("=" * 80)
    print("Testing JSON Parsing with Validation")
    print("=" * 80)
    
    try:
        # Valid response
        response = '{"rooms": [{"room_name": "Living Room"}], "metadata": {}}'
        result = parse_json_response_with_schema(response, required_keys=["rooms"])
        print(f"Input: {response}")
        print(f"Result: {result}")
        print("✓ JSON with validation test passed\n")
        
        # Invalid response (missing required key)
        try:
            invalid_response = '{"metadata": {}}'
            parse_json_response_with_schema(invalid_response, required_keys=["rooms"])
            print("✗ Should have raised ValueError for missing key\n")
        except ValueError as e:
            print(f"✓ Correctly raised ValueError for missing key: {e}\n")
        
    except Exception as e:
        print(f"✗ JSON with validation test failed: {e}\n")
        import traceback
        traceback.print_exc()


def test_parse_complex_json():
    """Test parsing complex JSON structure"""
    print("=" * 80)
    print("Testing Complex JSON Parsing")
    print("=" * 80)
    
    try:
        complex_json = """```json
{
  "rooms": [
    {
      "room_name": "Living Room",
      "room_type": "living_room",
      "devices": ["TV", "Air Conditioner"],
      "objects": ["Sofa", "Coffee Table"],
      "features": ["Large window"]
    },
    {
      "room_name": "Kitchen",
      "room_type": "kitchen",
      "devices": ["Refrigerator", "Oven"],
      "objects": ["Dining Table"],
      "features": []
    }
  ]
}
```"""
        result = parse_json_response(complex_json)
        print(f"Parsed {len(result.get('rooms', []))} rooms")
        print("✓ Complex JSON parsing test passed\n")
        
    except Exception as e:
        print(f"✗ Complex JSON parsing test failed: {e}\n")
        import traceback
        traceback.print_exc()


def main():
    """Main test function"""
    print("\n" + "=" * 80)
    print("JSON Parser Test Suite")
    print("=" * 80 + "\n")
    
    test_parse_basic_json()
    test_parse_json_with_markdown()
    test_parse_json_with_validation()
    test_parse_complex_json()
    
    print("=" * 80)
    print("All JSON Parser tests completed")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    main()

