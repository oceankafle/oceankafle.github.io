from __future__ import annotations

import streamlit as st


def configure_page() -> None:
    st.set_page_config(
        page_title="ARGUS - Environment Information Management",
        page_icon="🏠",
        layout="wide",
        initial_sidebar_state="expanded",
    )


def inject_css() -> None:
    st.markdown(
        """
<style>
    /* Tag styles */
    .room-tag {
        display: inline-block;
        padding: 4px 8px;
        margin: 2px;
        background-color: #e0e0e0;
        border-radius: 4px;
        font-size: 0.9rem;
    }
    /* Room row styles */
    .room-row {
        margin-bottom: 15px;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 6px;
        background-color: #f9f9f9;
    }
    /* Input field styles */
    .stTextInput > div > div > input {
        font-size: 0.9rem !important;
    }
    /* Center image display */
    .stImage {
        display: flex !important;
        justify-content: center !important;
        align-items: center !important;
    }
    .stImage > div {
        display: flex !important;
        justify-content: center !important;
        width: 100% !important;
    }
    .stImage img {
        margin: 0 auto !important;
    }
    /* Disabled button styles */
    button[kind="primary"]:disabled {
        background-color: #cccccc !important;
        color: #666666 !important;
        cursor: not-allowed !important;
        opacity: 0.6 !important;
    }
    /* Make object text input more compact */
    .stTextInput > div > div > input[aria-label="Object List"] {
        font-size: 0.9rem !important;
    }
    /* Make "Add New Room" section more compact */
    h4 {
        font-size: 1rem !important;
        margin-top: 0.5rem !important;
        margin-bottom: 0.5rem !important;
    }
    /* Compact form inputs in "Add New Room" section */
    form:has(button[data-testid*="add_room"]) .stTextInput > div > div > input {
        font-size: 0.85rem !important;
        padding: 0.4rem 0.6rem !important;
    }
    form:has(button[data-testid*="add_room"]) .stButton > button {
        font-size: 0.85rem !important;
        padding: 0.4rem 0.8rem !important;
    }

    /* Object tag display (display only, not clickable) */
    .obj-tags {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
        align-items: center;
    }
    .obj-tag-pill {
        display: inline-block;
        background-color: #4CAF50;
        color: white;
        padding: 4px 10px;
        border-radius: 12px;
        font-size: 0.85rem;
        line-height: 1.2;
        white-space: nowrap;
        max-width: 100%;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    /* Button area vertical centering and offset - for right column (button column) */
    /* In col_right area, the second column (button column) styles */
    div[data-testid="column"]:nth-of-type(2) {
        display: flex !important;
        flex-direction: column !important;
        justify-content: center !important;
        align-items: stretch !important;
        padding-top: 50px !important;
    }
    /* Ensure button column content is vertically centered */
    div[data-testid="column"]:nth-of-type(2) > div {
        display: flex !important;
        flex-direction: column !important;
        justify-content: center !important;
        min-height: 100% !important;
    }

    /* (Chat UI reverted to Streamlit native components: st.chat_input + st.chat_message) */
</style>
""",
        unsafe_allow_html=True,
    )

