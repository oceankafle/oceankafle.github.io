from __future__ import annotations

import streamlit as st

from interface.services.storage import save_environment_info as persist_environment_info
from interface.utils.normalize import dedupe_preserve_order


def render_room_editor() -> None:
    """Render room editor - clean single-line display."""
    # Initialize editing state (only one room can be edited at a time)
    if "editing_room" not in st.session_state:
        st.session_state.editing_room = None

    # Display existing rooms
    if st.session_state.environment_info:
        # Use list to avoid modifying dictionary during iteration
        rooms_to_process = list(st.session_state.environment_info.items())

        for room_name, objects in rooms_to_process:
            # Check if room still exists (may have been deleted)
            if room_name not in st.session_state.environment_info:
                continue

            # Each row displays: Room name | Object list | Edit button | Delete button
            col_room, col_objects, col_add, col_delete = st.columns([2, 6, 1, 1])

            with col_room:
                # Room name (editable)
                new_room_name = st.text_input(
                    "Room Name",
                    value=room_name,
                    key=f"room_name_{room_name}",
                    label_visibility="collapsed",
                )

                # If room name changes, update dictionary
                if new_room_name != room_name and new_room_name.strip():
                    new_key = new_room_name.strip()
                    if (
                        new_key in st.session_state.environment_info
                        and new_key != room_name
                    ):
                        st.warning(
                            f"Room '{new_key}' already exists, cannot rename to duplicate name."
                        )
                    elif room_name in st.session_state.environment_info:
                        # Preserve original order: replace key at original position (not pop then append to end)
                        old_dict = st.session_state.environment_info
                        new_dict = {}
                        for k, v in old_dict.items():
                            if k == room_name:
                                new_dict[new_key] = v
                            else:
                                new_dict[k] = v
                        st.session_state.environment_info = new_dict
                        # If currently editing this room, update editing target accordingly
                        if st.session_state.editing_room == room_name:
                            st.session_state.editing_room = new_key
                        persist_environment_info(st.session_state.environment_info)
                        st.rerun()

            with col_objects:
                # Display object list: default tag display; switch to text input when editing
                current_room = (
                    new_room_name.strip()
                    if new_room_name.strip() and new_room_name != room_name
                    else room_name
                )
                if current_room in st.session_state.environment_info:
                    current_objects = st.session_state.environment_info[current_room]
                    is_editing = st.session_state.editing_room == current_room
                    if is_editing:
                        text_key = f"objects_text_{current_room}"
                        objects_str = ", ".join(current_objects) if current_objects else ""
                        # Only pre-fill when first entering edit mode to avoid conflicts with widget state
                        st.session_state.setdefault(text_key, objects_str)
                        st.text_input(
                            "Object List",
                            key=text_key,
                            placeholder="Separate with commas, e.g.: Washing Machine, Toilet, Sink",
                            label_visibility="collapsed",
                        )
                        st.caption(
                            "Edit mode: Separate objects with English commas `,`, click 'Save' on the right to apply."
                        )
                    else:
                        if current_objects:
                            tags_html = ['<div class="obj-tags">']
                            for obj in current_objects:
                                obj_escaped = (
                                    obj.replace("&", "&amp;")
                                    .replace("<", "&lt;")
                                    .replace(">", "&gt;")
                                    .replace('"', "&quot;")
                                )
                                tags_html.append(
                                    f'<span class="obj-tag-pill">{obj_escaped}</span>'
                                )
                            tags_html.append("</div>")
                            st.markdown("".join(tags_html), unsafe_allow_html=True)
                        else:
                            st.text("(No objects)")

            with col_add:
                current_room = (
                    new_room_name.strip()
                    if new_room_name.strip() and new_room_name != room_name
                    else room_name
                )
                is_editing = st.session_state.editing_room == current_room
                if not is_editing:
                    # Edit button
                    if st.button(
                        "✎",
                        key=f"edit_room_{room_name}",
                        help="Edit objects",
                        width='stretch',
                    ):
                        st.session_state.editing_room = current_room
                        st.rerun()
                else:
                    # Save button
                    if st.button(
                        "💾",
                        key=f"save_room_{room_name}",
                        help="Save objects",
                        width='stretch',
                    ):
                        text_key = f"objects_text_{current_room}"
                        raw = st.session_state.get(text_key, "")
                        st.session_state.environment_info[current_room] = (
                            dedupe_preserve_order(raw.split(",") if raw else [])
                        )
                        persist_environment_info(st.session_state.environment_info)
                        st.session_state.editing_room = None
                        # Clear edit draft to avoid reusing old values/triggering conflicts next time entering edit mode
                        if text_key in st.session_state:
                            del st.session_state[text_key]
                        st.rerun()

            with col_delete:
                # Delete button - delete room
                if st.button(
                    "✕",
                    key=f"delete_room_{room_name}",
                    help="Delete room",
                    width='stretch',
                ):
                    if room_name in st.session_state.environment_info:
                        st.session_state.environment_info.pop(room_name)
                        persist_environment_info(st.session_state.environment_info)
                        st.rerun()

            st.markdown("---")

