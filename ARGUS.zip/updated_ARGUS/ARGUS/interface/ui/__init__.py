"""
UI components for ARGUS Streamlit interface.
"""

