from __future__ import annotations

from typing import Any

import streamlit as st

from interface.services.storage import load_activities, save_activities
from interface.ui.sidebar import PAGE_SENSOR_GROUNDING


def _render_sequence_list(sequence: list[Any]) -> None:
    for i, step in enumerate(sequence, start=1):
        if isinstance(step, str):
            st.markdown(f"{i}. {step}")
            continue
        if isinstance(step, dict):
            action = (step.get("action") or "").strip()
            objects = step.get("object") or []
            state_change = (step.get("state_change") or step.get("stage_change") or "").strip()
            necessity = step.get("necessity")
            objects_text = ", ".join([obj for obj in objects if isinstance(obj, str)])
            necessity_text = (
                " (necessary)" if necessity is True else " (optional)" if necessity is False else ""
            )
            st.markdown(
                f"{i}. **Action**: {action} | **Objects**: {objects_text} | "
                f"**State change**: {state_change}{necessity_text}"
            )
            continue
        st.markdown(f"{i}. {step}")


def _sequence_to_rows(sequence: list[Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for step in sequence:
        if isinstance(step, str):
            rows.append(
                {
                    "action": step,
                    "objects": "",
                    "state_change": "",
                    "necessity": False,
                }
            )
            continue
        if isinstance(step, dict):
            objects = step.get("objects") or step.get("object") or []
            objects_text = ", ".join([obj for obj in objects if isinstance(obj, str)])
            rows.append(
                {
                    "action": (step.get("action") or "").strip(),
                    "object": objects_text,
                    "stage_change": (step.get("state_change") or step.get("stage_change") or "").strip(),
                    "necessity": bool(step.get("necessity")) if step.get("necessity") is not None else False,
                }
            )
    return rows


def _rows_to_sequence(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    sequence: list[dict[str, Any]] = []
    for row in rows:
        action = (row.get("action") or "").strip()
        if not action:
            continue
        objects_value = row.get("object") or ""
        if isinstance(objects_value, list):
            objects = [obj for obj in objects_value if isinstance(obj, str) and obj.strip()]
        else:
            objects = [obj.strip() for obj in str(objects_value).split(",") if obj.strip()]
        state_change = (row.get("stage_change") or "").strip()
        necessity = row.get("necessity")
        step = {
            "action": action,
            "objects": objects,
            "state_change": state_change,
        }
        if necessity is not None:
            step["necessity"] = bool(necessity)
        sequence.append(step)
    return sequence


def _render_next_step_button(activities: list[dict[str, Any]]) -> None:
    if not activities:
        return
    if st.button("➡️ Continue to Sensor Grounding", type="primary", width='stretch'):
        st.session_state.sidebar_page = PAGE_SENSOR_GROUNDING
        st.rerun()


def _render_persisted_activities(
    activities: list[dict[str, Any]],
    *,
    updated_data: dict[str, Any] | None,
) -> None:
    st.markdown("**ARGUS interpreted your request as the following grounded activities.**")
    if not activities:
        st.info("No activities are available yet.")
        return

    for act in activities:
        act_id = act.get("id")
        desc = act.get("description") or "(no description)"
        seq = act.get("sequence") or []

        with st.expander(f"Activity {act_id}: {desc}", expanded=False):
            if seq:
                st.markdown("**Behavior sequence**")
                rows = _sequence_to_rows(seq)
                edited_rows = st.data_editor(
                    rows,
                    num_rows="dynamic",
                    width="stretch",
                    column_config={
                        "action": st.column_config.TextColumn("Action"),
                        "object": st.column_config.TextColumn("Objects"),
                        "stage_change": st.column_config.TextColumn("State change"),
                        "necessity": st.column_config.CheckboxColumn("Necessary"),
                    },
                    key=f"seq_editor_{act_id}",
                )
                if st.button("Save sequence", key=f"save_seq_{act_id}"):
                    act["sequence"] = _rows_to_sequence(edited_rows)
                    save_activities(activities)
                    if updated_data is None:
                        updated_data = {"activities": activities}
                    else:
                        updated_data["activities"] = activities
                    st.session_state.last_activity_result = {
                        "type": "updated",
                        "updated_data": updated_data,
                    }
                    st.success("Saved")
            else:
                st.caption("No behavior sequence available.")


def render_activity_results() -> None:


    last = st.session_state.get("last_activity_result")
    if not last:
        activities = load_activities()
        if not activities:
            st.info(
                "No results yet. Define an activity goal above to see how ARGUS interprets it."
            )
            return
        _render_persisted_activities(activities, updated_data=None)
        _render_next_step_button(activities)
        return

    if last.get("type") == "updated":
        updated_data: dict[str, Any] = last.get("updated_data") or {}
        inter = updated_data.get("__intermediates") or []
        activities = updated_data.get("activities") or []

        if inter:
            st.markdown("**New activity understanding from this run**")
            for idx, item in enumerate(inter, start=1):
                desc = item.get("activity_description") or f"Activity {idx}"
                with st.expander(f"Activity {idx}: {desc}", expanded=True):
                    spatial = item.get("spatial_report") or {}
                    summary = (spatial.get("summary") or "").strip()
                    if summary:
                        st.markdown(f"**Spatial context**: {summary}")

                    seq = item.get("sequence") or []
                    if seq:
                        st.markdown("**Behavior sequence**")
                        _render_sequence_list(seq)
                    else:
                        st.warning("No behavior sequence was generated for this activity.")
        else:
            st.markdown("**No new activity understanding was generated in this run.**")

        st.markdown("---")
        _render_persisted_activities(activities, updated_data=updated_data)
        _render_next_step_button(activities)

        if st.session_state.get("chat_debug"):
            st.markdown("---")
            st.subheader("🧪 Debug (LLM raw output)")
            dbg = updated_data.get("__debug") or {}
            raw = dbg.get("raw_response")
            prompt = dbg.get("prompt")
            if raw:
                st.markdown("**raw_response**")
                st.code(raw)
            if prompt:
                st.markdown("**prompt**")
                st.code(prompt)

    elif last.get("type") == "plan":
        plan: dict[str, Any] = last.get("plan") or {}
        st.markdown("**Text-only activity understanding**")
        actions = plan.get("actions") or []
        updated_env = plan.get("updated_environment_info")

        if updated_env:
            st.markdown("**Suggested environment updates**")
            st.json(updated_env)

        st.markdown("**Extracted actions**")
        st.json(actions)

        if st.session_state.get("chat_debug"):
            st.markdown("---")
            st.subheader("🧪 Debug (LLM raw output)")
            dbg = plan.get("__debug") or {}
            raw = dbg.get("raw_response")
            prompt = dbg.get("prompt")
            if raw:
                st.markdown("**raw_response**")
                st.code(raw)
            if prompt:
                st.markdown("**prompt**")
                st.code(prompt)
    else:
        st.json(last)