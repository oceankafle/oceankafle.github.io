from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Optional

import streamlit as st

from agent.activity_analysis.manager_agent import ManagerAgent
from interface.services.storage import save_environment_info as persist_environment_info
from interface.utils.normalize import normalize_environment_info


def _run(coro):
    return asyncio.run(coro)


def _init_chat_state() -> None:
    if "chat_messages" not in st.session_state:
        st.session_state.chat_messages = []
    if "chat_llm_name" not in st.session_state:
        st.session_state.chat_llm_name = "gemini"
    if "chat_debug" not in st.session_state:
        st.session_state.chat_debug = False
    if "last_activity_result" not in st.session_state:
        st.session_state.last_activity_result = None
    if "pending_user_text" not in st.session_state:
        st.session_state.pending_user_text = None
    if "pending_stage" not in st.session_state:
        # None | "manager_reply" | "update_pipeline"
        st.session_state.pending_stage = None
    if "pending_plan" not in st.session_state:
        st.session_state.pending_plan = None
    # if "activity_input_text" not in st.session_state:
    #     st.session_state.activity_input_text = ""
    if st.session_state.get("clear_input_flag"):
        st.session_state.activity_input_text = ""
        st.session_state.clear_input_flag = False


def render_activity_analysis_chat(*, image_path: Optional[Path]) -> None:
    _init_chat_state()

    st.markdown("#### What activity should ARGUS understand?")
    st.caption(
        "Describe the behavior, the room, and any important objects or people involved."
    )

    with st.container(border=True):
        user_text = st.text_area(
            "Activity description",
            key="activity_input_text",
            placeholder=(
                "Example: Detect when a person is cooking in the kitchen, "
                "including preparing ingredients, using the stove, and moving "
                "between the counter and sink."
            ),
            height=140,
            label_visibility="collapsed",
        )

        col_btn_left, col_btn_right = st.columns([1, 5])
        with col_btn_left:
            generate_clicked = st.button(
                "Analyze Activity",
                type="primary",
                width='stretch',
            )

        with col_btn_right:
            if image_path and image_path.exists():
                st.caption("Floor plan detected. ARGUS can use it during analysis.")
            else:
                st.caption("No floor plan uploaded. ARGUS will use text-only analysis.")

    pending = st.session_state.get("pending_user_text")
    stage = st.session_state.get("pending_stage")

    if pending and stage:
        agent = ManagerAgent(llm_name=st.session_state.chat_llm_name)
        try:
            if stage == "manager_reply":
                with st.spinner("Generating activity analysis..."):
                    plan = _run(
                        agent.analyze(
                            user_input=pending,
                            temperature=0.7,
                            max_tokens=8000,
                            debug=bool(st.session_state.chat_debug),
                        )
                    )

                if plan.get("error"):
                    st.error(f"Chat processing failed: {plan.get('error')}")
                    st.session_state.chat_messages.append(
                        {
                            "role": "assistant",
                            "content": f"Chat processing failed: {plan.get('error')}",
                        }
                    )
                    st.session_state.last_activity_result = {"type": "plan", "plan": plan}
                    st.session_state.pending_user_text = None
                    st.session_state.pending_stage = None
                    st.session_state.pending_plan = None
                    st.rerun()

                reply = (plan.get("response") or "").strip() or "Analysis complete."
                st.session_state.chat_messages.append({"role": "user", "content": pending})
                st.session_state.chat_messages.append({"role": "assistant", "content": reply})
                st.session_state.pending_plan = plan

                if not (image_path and image_path.exists()):
                    updated_env = plan.get("updated_environment_info")
                    if isinstance(updated_env, dict) and updated_env:
                        normalized = normalize_environment_info(updated_env)
                        st.session_state.environment_info = normalized
                        persist_environment_info(normalized)

                    st.session_state.last_activity_result = {"type": "plan", "plan": plan}
                    st.session_state.pending_user_text = None
                    st.session_state.pending_stage = None
                    st.session_state.pending_plan = None
                    st.session_state.clear_input_flag = True
                    st.rerun()

                st.session_state.pending_stage = "update_pipeline"
                st.rerun()

            if stage == "update_pipeline":
                plan = st.session_state.get("pending_plan") or {}
                with st.spinner("Analyzing floor plan and updating the activity sequence..."):
                    updated_data = _run(
                        agent.process_and_update(
                            user_input=pending,
                            image_path=image_path,
                            temperature=0.7,
                            max_tokens=8000,
                            debug=bool(st.session_state.chat_debug),
                            return_intermediates=True,
                            plan_override=plan,
                        )
                    )

                if updated_data.get("error"):
                    st.error(f"Update failed: {updated_data.get('error')}")
                else:
                    if isinstance(updated_data.get("environment_info"), dict):
                        normalized = normalize_environment_info(updated_data["environment_info"])
                        st.session_state.environment_info = normalized
                        persist_environment_info(normalized)

                st.session_state.last_activity_result = {
                    "type": "updated",
                    "updated_data": updated_data,
                }
                st.session_state.pending_user_text = None
                st.session_state.pending_stage = None
                st.session_state.pending_plan = None
                st.session_state.clear_input_flag = True
                st.rerun()
        finally:
            try:
                _run(agent.close())
            except Exception:
                pass

    if generate_clicked:
        cleaned_text = (user_text or "").strip()
        if not cleaned_text:
            st.warning("Please describe an activity before generating.")
            return

        st.session_state.pending_user_text = cleaned_text
        st.session_state.pending_stage = "manager_reply"
        st.session_state.pending_plan = None
        st.rerun()

    if st.session_state.chat_messages:
        st.markdown("##### Latest analysis")
        latest_messages = st.session_state.chat_messages[-2:]

        for message in latest_messages:
            if message.get("role") == "user":
                st.markdown(f"**You:** {message.get('content', '')}")
            else:
                st.markdown(f"**ARGUS:** {message.get('content', '')}")