from __future__ import annotations

import streamlit as st

from interface.services.storage import save_environment_info as persist_environment_info


PAGE_ACTIVITY_ANALYSIS = "Activity Analysis"
PAGE_SENSOR_GROUNDING = "Sensor Grounding"
PAGE_SENSOR_DEPLOYMENT = "Sensor Deployment"


def _init_page_state() -> None:
    if "sidebar_page" not in st.session_state:
        st.session_state.sidebar_page = PAGE_ACTIVITY_ANALYSIS


def _page_index() -> int:
    page = st.session_state.sidebar_page
    if page == PAGE_ACTIVITY_ANALYSIS:
        return 0
    if page == PAGE_SENSOR_GROUNDING:
        return 1
    if page == PAGE_SENSOR_DEPLOYMENT:
        return 2
    return 0


def render_sidebar_summary() -> str:
    """
    Sidebar: Page selector + context-specific content.
    Returns the selected page key.
    """
    _init_page_state()

    with st.sidebar:
        st.markdown("### 📑 Page")
        page = st.radio(
            "Section",
            options=[PAGE_ACTIVITY_ANALYSIS, PAGE_SENSOR_GROUNDING, PAGE_SENSOR_DEPLOYMENT],
            index=_page_index(),
            label_visibility="collapsed",
        )
        st.session_state.sidebar_page = page
        st.markdown("---")

        if page == PAGE_ACTIVITY_ANALYSIS:
            _render_activity_analysis_sidebar()
        elif page == PAGE_SENSOR_GROUNDING:
            _render_grounding_sidebar()
        else:
            _render_deployment_sidebar()

    return st.session_state.sidebar_page


def _render_activity_analysis_sidebar() -> None:
    """Sidebar content for Activity Analysis page."""
    with st.expander("⚙️ Chat Settings", expanded=True):
        st.session_state.chat_llm_name = st.selectbox(
            "LLM",
            options=["gpt", "deepseek", "openrouter", "gemini"],
            index=["gpt", "deepseek", "openrouter", "gemini"].index(
                st.session_state.get("chat_llm_name", "gemini")
            )
            if st.session_state.get("chat_llm_name", "gemini") in ["gpt", "deepseek", "openrouter", "gemini"]
            else 3,
            help="Each provider requires its matching API key in .env",
        )
        st.session_state.vlm_name = st.selectbox(
            "VLM",
            options=["qwen", "llava", "gemini", "nvidia", "gpt"],
            index=["qwen", "llava", "gemini", "nvidia", "gpt"].index(
                st.session_state.get("vlm_name", "nvidia")
            )
            if st.session_state.get("vlm_name", "nvidia") in ["qwen", "llava", "gemini", "nvidia", "gpt"]
            else 3,
            help="Used for floor-plan and deployment image reasoning",
        )
        st.session_state.chat_debug = st.checkbox(
            "Debug: show LLM raw output",
            value=bool(st.session_state.get("chat_debug", False)),
        )
        if st.button("🧹 Clear Chat", width='stretch'):
            st.session_state.chat_messages = []
            st.session_state.last_activity_result = None
            st.rerun()

    st.header("📊 Environment Information Summary")

    if st.session_state.environment_info:
        total_rooms = len(st.session_state.environment_info)
        total_objects = sum(
            len(objects) for objects in st.session_state.environment_info.values()
        )

        st.metric("Number of Rooms", total_rooms)
        st.metric("Total Objects", total_objects)

        st.markdown("---")
        st.markdown("### Room List")
        for room_name, objects in st.session_state.environment_info.items():
            with st.expander(f"🏠 {room_name} ({len(objects)} objects)"):
                for obj in objects:
                    st.markdown(f"- {obj}")
    else:
        st.info(
            "No environment information available. Please upload an image and analyze it."
        )

    st.markdown("---")
    if st.button("🔄 Reset Environment Information", width='stretch'):
        st.session_state.environment_info = {}
        persist_environment_info(st.session_state.environment_info)
        st.rerun()


def _render_grounding_sidebar() -> None:
    """Sidebar content for Sensor Grounding page."""
    from agent.utils import load_activity_analysis

    st.header("🎯 Sensor Grounding")
    st.caption("Determine sensor deployment constraints from activities and environment.")
    if st.session_state.get("environment_info"):
        st.metric("Rooms", len(st.session_state.environment_info))
        try:
            data = load_activity_analysis()
            activities = data.get("activities") or []
            st.metric("Activities", len(activities))
        except Exception:
            st.metric("Activities", "—")
    else:
        st.info("Complete **Activity Analysis** first to use grounding.")


def _render_deployment_sidebar() -> None:
    """Sidebar content for Sensor Deployment page."""
    from interface.services.storage import load_sensor_suggestions, load_deployment_recommendations

    st.header("📍 Sensor Deployment")
    st.caption("Segment floor plan and recommend deployment regions per sensor.")
    if st.session_state.get("environment_info"):
        st.metric("Rooms", len(st.session_state.environment_info))
        try:
            suggestions = load_sensor_suggestions()
            recs = load_deployment_recommendations()
            st.metric("Sensor suggestions", len(suggestions))
            st.metric("Deployment recs", len(recs))
        except Exception:
            st.metric("Sensor suggestions", "—")
            st.metric("Deployment recs", "—")
    else:
        st.info("Complete **Activity Analysis** and **Sensor Grounding** first.")
