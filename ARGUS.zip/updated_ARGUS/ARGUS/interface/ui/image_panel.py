from __future__ import annotations

import asyncio
import os
import tempfile
from pathlib import Path

import streamlit as st

from interface.services.storage import save_environment_info as persist_environment_info
from interface.services.vision import analyze_image
from interface.utils.image import get_display_width
from interface.utils.normalize import dedupe_preserve_order, normalize_environment_info


def _run(coro):
    return asyncio.run(coro)


def _render_add_room_form(*, form_key: str, room_key: str, objects_key: str) -> None:
    st.markdown("#### ➕ Add New Room")
    with st.form(form_key):
        new_room = st.text_input(
            "Room Name",
            placeholder="e.g.: Kitchen...",
            key=room_key,
        )
        new_objects_str = st.text_input(
            "Object List (comma-separated)",
            placeholder="e.g.: Refrigerator, Stove",
            key=objects_key,
        )
        submitted = st.form_submit_button("Add Room", width='stretch')

        if submitted:
            if new_room.strip():
                if new_room.strip() not in st.session_state.environment_info:
                    objects_list = (
                        dedupe_preserve_order(new_objects_str.split(","))
                        if new_objects_str
                        else []
                    )
                    st.session_state.environment_info[new_room.strip()] = objects_list
                    persist_environment_info(st.session_state.environment_info)
                    st.rerun()
                else:
                    st.warning(f"Room '{new_room.strip()}' already exists!")


def render_image_panel() -> None:
    """Right panel: image upload / display / analyze + add room form."""
    uploaded_file = st.file_uploader(
        "Upload Room Layout Image",
        type=["png", "jpg", "jpeg", "gif", "webp"],
        help="Supported formats: PNG, JPG, JPEG, GIF, WebP (single image only)",
        accept_multiple_files=False,
    )

    def _analyze_button(*, label: str, image_path: Path) -> None:
        if st.button(label, width='stretch', type="primary"):
            with st.spinner("Analyzing image, extracting room and object information..."):
                try:
                    result = _run(
                        analyze_image(
                            image_path,
                            vlm_name=st.session_state.get("vlm_name", "qwen"),
                        )
                    )
                    st.session_state.analysis_result = result
                    st.session_state.environment_info = normalize_environment_info(result)
                    persist_environment_info(st.session_state.environment_info)
                    st.success("✅ Analysis complete!")
                    st.rerun()
                except Exception as e:
                    st.error(f"❌ Analysis failed: {str(e)}")
                    import traceback

                    st.code(traceback.format_exc())

    if uploaded_file is not None:
        # Save uploaded image to temporary file (if image already exists, delete old one first)
        if st.session_state.uploaded_image_path and Path(
            st.session_state.uploaded_image_path
        ).exists():
            try:
                os.unlink(st.session_state.uploaded_image_path)
            except Exception:
                pass

        with tempfile.NamedTemporaryFile(
            delete=False, suffix=Path(uploaded_file.name).suffix
        ) as tmp_file:
            tmp_file.write(uploaded_file.getvalue())
            tmp_path = tmp_file.name
            st.session_state.uploaded_image_path = tmp_path

        img_col, btn_col = st.columns([2, 1])
        with img_col:
            display_width = get_display_width(uploaded_file)
            st.image(uploaded_file, width=display_width, caption="Uploaded Layout Image")

        with btn_col:
            _analyze_button(label="🔍 Analyze Image", image_path=Path(tmp_path))
            st.markdown("<br>", unsafe_allow_html=True)
            _render_add_room_form(
                form_key="add_room_form",
                room_key="new_room_input",
                objects_key="new_objects_input",
            )

    elif st.session_state.uploaded_image_path and Path(
        st.session_state.uploaded_image_path
    ).exists():
        img_col, btn_col = st.columns([2, 1])
        with img_col:
            display_width = get_display_width(st.session_state.uploaded_image_path)
            st.image(
                st.session_state.uploaded_image_path,
                width=display_width,
                caption="Current Layout Image",
            )

        with btn_col:
            _analyze_button(
                label="🔍 Re-analyze Image",
                image_path=Path(st.session_state.uploaded_image_path),
            )
            st.markdown("<br>", unsafe_allow_html=True)
            _render_add_room_form(
                form_key="add_room_form_existing",
                room_key="new_room_input_existing",
                objects_key="new_objects_input_existing",
            )

    else:
        img_col, btn_col = st.columns([2, 1])
        with img_col:
            st.empty()

        with btn_col:
            st.button(
                "🔍 Analyze Image",
                width='stretch',
                type="primary",
                disabled=True,
            )
            st.markdown("<br>", unsafe_allow_html=True)
            _render_add_room_form(
                form_key="add_room_form_no_image",
                room_key="new_room_input_no_image",
                objects_key="new_objects_input_no_image",
            )
