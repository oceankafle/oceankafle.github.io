"""
Sensor Deployment page: Segment floor plan into grid, then recommend deployment regions per sensor.
Left: Deployment Manager chat + deployment results.
Right: Grid summary + constraints.
First entry or "Run deployment": SegmentAgent then DeploymentAgent, save grid and recommendations.
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

import streamlit as st

from interface.services.storage import (
    load_constraints,
    load_deployment_grid,
    load_deployment_recommendations,
    load_evaluation_summary,
    load_sensor_suggestions,
    save_deployment_grid,
    save_deployment_recommendations,
    save_evaluation_summary,
)


def _run(coro):
    return asyncio.run(coro)


async def _run_deployment_pipeline_async(
    *,
    image_path: Path,
    sensor_suggestions: list[dict[str, Any]],
    constraints: dict[str, Any],
    vlm_name: str,
) -> tuple[dict[str, Any], list[dict[str, Any]], dict[str, Any]]:
    """Run SegmentAgent then DeploymentAgent in one event loop."""
    from agent.sensor_deployment.segment_agent import SegmentAgent
    from agent.sensor_deployment.deployment_agent import DeploymentAgent
    from agent.physical_planning import (
        enrich_deployment_recommendations,
        summarize_deployment_evaluation,
    )

    segment_agent = SegmentAgent(vlm_name=vlm_name)
    try:
        grid_result = await segment_agent.segment(
            image_path=image_path,
            temperature=0.7,
            max_tokens=8000,
        )
    finally:
        await segment_agent.close()

    grid = grid_result.get("grid", {})
    if not grid or not grid.get("segments"):
        return grid_result, [], {}

    deployment_agent = DeploymentAgent(vlm_name=vlm_name)
    try:
        recommendations = await deployment_agent.analyze(
            sensor_suggestions=sensor_suggestions,
            grid_segments=grid,
            constraints=constraints,
            image_path=image_path,
            temperature=0.7,
            max_tokens=8000,
        )
    finally:
        await deployment_agent.close()

    enriched = enrich_deployment_recommendations(
        sensor_suggestions=sensor_suggestions,
        grid=grid_result,
        recommendations=recommendations,
        constraints=constraints,
        image_path=image_path,
    )
    summary = summarize_deployment_evaluation(enriched)
    return grid_result, enriched, summary


def _run_deployment_pipeline(
    *,
    image_path: Path,
    sensor_suggestions: list[dict[str, Any]],
    constraints: dict[str, Any],
) -> tuple[dict[str, Any], list[dict[str, Any]], dict[str, Any]]:
    """Run segment then deployment; return (grid, recommendations, summary)."""
    return _run(
        _run_deployment_pipeline_async(
            image_path=image_path,
            sensor_suggestions=sensor_suggestions,
            constraints=constraints,
            vlm_name=st.session_state.get("vlm_name", "qwen"),
        )
    )


def _init_deployment_chat_state() -> None:
    if "deployment_messages" not in st.session_state:
        st.session_state.deployment_messages = []
    if "pending_deployment_user_text" not in st.session_state:
        st.session_state.pending_deployment_user_text = None


def _render_deployment_results(recommendations: list[dict[str, Any]]) -> None:
    """Display deployment recommendations in left column."""
    if not recommendations:
        st.caption("Deployment recommendations will appear here after running deployment.")
        return
    for rec in recommendations:
        act_id = rec.get("activity_id", "")
        sensor_type = rec.get("sensor_type", "")
        behavior = rec.get("behavior", "")
        segments = rec.get("recommended_segments") or []
        alts = rec.get("alternative_segments") or []
        with st.expander(f"Activity {act_id}: {sensor_type} — {behavior}", expanded=True):
            st.markdown("**Recommended segments**")
            for seg in segments:
                coverage = seg.get("coverage") or {}
                placement = seg.get("placement") or {}
                st.markdown(
                    f"- **{seg.get('segment_id', '')}** (priority: {seg.get('priority', '')}) "
                    f"— {seg.get('installation_location', '')}"
                )
                if placement:
                    st.caption(
                        "  Placement: "
                        f"x={placement.get('x_percent')}%, y={placement.get('y_percent')}%, "
                        f"{placement.get('mounting')}, height={placement.get('height_m')}m"
                    )
                if coverage:
                    st.caption(
                        "  Coverage: "
                        f"{coverage.get('coverage_score')} · Feasibility: {coverage.get('feasibility_score')} · "
                        f"Occlusion risk: {coverage.get('occlusion_risk')}"
                    )
                if seg.get("rationale"):
                    st.caption(f"  {seg['rationale']}")
            if alts:
                st.markdown("**Alternatives**")
                for seg in alts:
                    st.markdown(
                        f"- **{seg.get('segment_id', '')}** (priority: {seg.get('priority', '')}) "
                        f"— {seg.get('installation_location', '')}"
                    )


def _render_deployment_visualization(
    image_path: Path,
    grid: dict[str, Any],
    recommendations: list[dict[str, Any]],
) -> None:
    """Draw grid and sensor positions on floor plan and display in right column."""
    st.markdown(
        "<h4 style='margin-bottom: 0.6rem;'>🗺️ Floor plan overlay</h4>",
        unsafe_allow_html=True,
    )
    st.caption("Grid segments (blue); segments with sensors (green).")
    g = (grid or {}).get("grid")
    if not g or not (g.get("segments") if isinstance(g, dict) else None):
        st.info("Run deployment to see grid and sensor positions on the floor plan.")
        return
    try:
        from interface.utils.deployment_viz import draw_deployment_overlay

        overlay = draw_deployment_overlay(image_path, grid, recommendations)
        st.image(overlay, width='stretch')
    except Exception as e:
        st.warning(f"Visualization failed: {e}")


def _render_grid_panel(grid: dict[str, Any]) -> None:
    """Display grid summary in right column."""
    st.markdown(
        "<h4 style='margin-bottom: 0.6rem;'>📐 Grid Segments</h4>",
        unsafe_allow_html=True,
    )
    st.caption("Floor plan divided into segments for deployment (from SegmentAgent).")
    if not grid or not grid.get("grid"):
        st.info("No grid yet. Run deployment to segment the floor plan.")
        return
    g = grid.get("grid", {})
    rows = g.get("rows", 0)
    cols = g.get("columns", 0)
    segments = g.get("segments") or []
    st.metric("Rows", rows)
    st.metric("Columns", cols)
    st.metric("Segments", len(segments))
    st.markdown("---")
    st.markdown("**Segment list**")
    for seg in segments[:20]:
        seg_id = seg.get("id", "")
        desc = (seg.get("description") or "")[:60]
        room = seg.get("room", "")
        st.caption(f"**{seg_id}** {room} — {desc}")
    if len(segments) > 20:
        st.caption(f"… and {len(segments) - 20} more.")


def _render_evaluation_summary(summary: dict[str, Any]) -> None:
    st.markdown("**Evaluation summary**")
    if not summary:
        st.caption("Run deployment to compute coverage and feasibility metrics.")
        return
    col_a, col_b = st.columns(2)
    with col_a:
        st.metric("Coverage", f"{summary.get('coverage_percent', 0)}%")
        st.metric("Sensors", summary.get("sensor_count", 0))
    with col_b:
        st.metric("Feasibility", summary.get("average_feasibility", 0))
        st.metric("Constraint violations", summary.get("constraint_violations", 0))
    st.caption(f"Average occlusion risk: {summary.get('average_occlusion_risk', 0)}")


def _render_deployment_chat(image_path: Path | None) -> None:
    """Left column top: Deployment Manager chat. On send: respond and show in chat."""
    _init_deployment_chat_state()

    st.markdown(
        "<h4 style='margin-bottom: 0.6rem;'>💬 Deployment Manager Chat</h4>",
        unsafe_allow_html=True,
    )
    st.caption("Ask about the deployment plan, request modifications, or clarification.")

    chat_box = st.container(height=320, border=True)
    with chat_box:
        for m in reversed(st.session_state.deployment_messages):
            with st.chat_message(m.get("role", "assistant")):
                st.markdown(m.get("content", ""))

    pending = st.session_state.get("pending_deployment_user_text")
    if pending:
        try:
            from agent.sensor_deployment.deployment_manager_agent import DeploymentManagerAgent
            from interface.services.storage import load_sensor_suggestions as _load_sugg

            async def _manager_respond():
                agent = DeploymentManagerAgent(llm_name=st.session_state.get("chat_llm_name", "gpt"))
                try:
                    return await agent.respond(
                        user_instruction=pending,
                        sensor_suggestions=_load_sugg(),
                        temperature=0.7,
                        max_tokens=8000,
                    )
                finally:
                    await agent.close()

            with st.spinner("Deployment manager responding…"):
                result = _run(_manager_respond())
                reply = (result.get("response") or "").strip() or "Done."
                st.session_state.deployment_messages.append({"role": "assistant", "content": reply})
        except Exception as e:
            st.session_state.deployment_messages.append(
                {"role": "assistant", "content": f"Error: {e}"}
            )
        st.session_state.pending_deployment_user_text = None
        st.rerun()

    user_text = st.chat_input("Ask about deployment or request changes…")
    if not user_text:
        return
    st.session_state.deployment_messages.append({"role": "user", "content": user_text})
    st.session_state.pending_deployment_user_text = user_text
    st.rerun()


def render_deployment_panel() -> None:
    """Layout: left = manager chat + results; right = grid + constraints. Run Segment→Deployment on first run or button."""
    if not st.session_state.get("environment_info"):
        st.info("Complete **Activity Analysis** first (upload floor plan and analyze).")
        return

    sensor_suggestions = load_sensor_suggestions()
    if not sensor_suggestions:
        st.info(
            "Complete **Sensor Grounding** first (run sensor reasoning). "
            "Sensor suggestions are required for deployment."
        )
        return

    image_path = (
        Path(st.session_state.uploaded_image_path)
        if st.session_state.get("uploaded_image_path")
        else None
    )
    if not image_path or not image_path.exists():
        st.info("Upload a floor plan image in **Activity Analysis** to run deployment (Segment + Deployment agents need the image).")
        return

    constraints = load_constraints()
    grid = load_deployment_grid()
    recommendations = load_deployment_recommendations()
    evaluation_summary = load_evaluation_summary()

    # Run deployment pipeline on first entry (no recommendations) or when user clicks "Re-run deployment"
    run_key = "deployment_run_requested"
    should_run = st.session_state.get(run_key) or not recommendations
    if should_run:
        with st.spinner("Segmenting floor plan and computing deployment recommendations…"):
            try:
                grid_result, recs, summary = _run_deployment_pipeline(
                    image_path=image_path,
                    sensor_suggestions=sensor_suggestions,
                    constraints=constraints,
                )
                save_deployment_grid(grid_result)
                save_deployment_recommendations(recs)
                save_evaluation_summary(summary)
                grid = grid_result
                recommendations = recs
                evaluation_summary = summary
            except Exception as e:
                st.error(f"Deployment failed: {e}")
                import traceback
                st.code(traceback.format_exc())
        st.session_state[run_key] = False
        if recommendations:
            st.rerun()

    # Two columns: left = chat + results, right = grid + constraints
    col_left, col_right = st.columns([1, 1])

    with col_left:
        _render_deployment_chat(image_path)
        st.markdown("---")
        st.markdown("**Deployment result**")
        _render_deployment_results(recommendations)
        if recommendations:
            if st.button("🔄 Re-run deployment", type="secondary", width='stretch'):
                st.session_state[run_key] = True
                st.rerun()

    with col_right:
        _render_deployment_visualization(image_path, grid, recommendations)
        st.markdown("---")
        _render_evaluation_summary(evaluation_summary)
        st.markdown("---")
        _render_grid_panel(grid)
        st.markdown("---")
        st.markdown("**Constraints**")
        if constraints:
            st.json(constraints)
        else:
            st.caption("No constraints (from Sensor Grounding).")
