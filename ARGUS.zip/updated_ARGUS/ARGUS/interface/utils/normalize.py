from __future__ import annotations

from typing import Dict, List


def dedupe_preserve_order(items: List[str]) -> List[str]:
    """
    Remove empty items and deduplicate (preserve order).
    Duplicate objects (tags) are not allowed within the same room.
    """
    seen = set()
    out: List[str] = []
    for x in items:
        x = (x or "").strip()
        if not x:
            continue
        if x in seen:
            continue
        seen.add(x)
        out.append(x)
    return out


def normalize_environment_info(env: Dict[str, List[str]] | None) -> Dict[str, List[str]]:
    """Normalize environment_info: preserve room order, deduplicate objects in each room."""
    normalized: Dict[str, List[str]] = {}
    for room, objs in (env or {}).items():
        normalized[room] = dedupe_preserve_order(list(objs or []))
    return normalized

