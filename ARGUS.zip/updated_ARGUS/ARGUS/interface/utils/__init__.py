"""
Utilities for ARGUS Streamlit interface.
"""

