"""
Draw deployment grid and sensor positions on the floor plan image.
Uses segment row/column to compute cell bounds (equal grid division).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from PIL import Image, ImageDraw, ImageFont


def _segment_bounds_from_grid(
    segment: dict[str, Any],
    rows: int,
    columns: int,
    img_width: int,
    img_height: int,
) -> tuple[int, int, int, int]:
    """Compute pixel bounds (left, top, right, bottom) for a segment from row/column."""
    row = int(segment.get("row", 1))
    col = int(segment.get("column", 1))
    row = max(1, min(row, rows))
    col = max(1, min(col, columns))
    cell_w = img_width / columns
    cell_h = img_height / rows
    left = int((col - 1) * cell_w)
    right = int(col * cell_w)
    top = int((row - 1) * cell_h)
    bottom = int(row * cell_h)
    return left, top, right, bottom


def _build_segment_sensors(
    recommendations: list[dict[str, Any]],
) -> dict[str, list[tuple[str, str]]]:
    """Build segment_id -> list of (sensor_type, label) from deployment recommendations."""
    out: dict[str, list[tuple[str, str]]] = {}
    for rec in recommendations:
        sensor_type = (rec.get("sensor_type") or "").strip()
        behavior = (rec.get("behavior") or "").strip()
        activity_id = rec.get("activity_id", "")
        label = behavior or f"Activity {activity_id}" or sensor_type
        for seg in rec.get("recommended_segments") or []:
            seg_id = (seg.get("segment_id") or "").strip()
            if not seg_id:
                continue
            if seg_id not in out:
                out[seg_id] = []
            out[seg_id].append((sensor_type, label))
    return out


def draw_deployment_overlay(
    image_path: Path,
    grid: dict[str, Any],
    recommendations: list[dict[str, Any]],
    *,
    segment_outline: str = "blue",
    segment_with_sensor_fill: str = "rgba(100,200,100,80)",
    segment_with_sensor_outline: str = "green",
    text_color: str = "white",
    text_outline_color: str = "black",
) -> Image.Image:
    """
    Draw grid segments and sensor positions on the floor plan image.
    Returns a new PIL Image (original unchanged). Segment bounds are derived from row/column.
    """
    img = Image.open(image_path).convert("RGBA")
    width, height = img.size
    draw = ImageDraw.Draw(img, "RGBA")

    g = grid.get("grid") if isinstance(grid.get("grid"), dict) else grid
    if not g:
        return img.convert("RGB")

    rows = int(g.get("rows") or 1)
    columns = int(g.get("columns") or 1)
    segments = g.get("segments") or []
    if not segments:
        return img.convert("RGB")

    segment_sensors = _build_segment_sensors(recommendations)

    # Font: try system fonts, then default
    font_small = ImageFont.load_default()
    for path in (
        "/System/Library/Fonts/Helvetica.ttc",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    ):
        try:
            font_small = ImageFont.truetype(path, 10)
            break
        except Exception:
            continue

    for seg in segments:
        left, top, right, bottom = _segment_bounds_from_grid(
            seg, rows, columns, width, height
        )
        seg_id = (seg.get("id") or "").strip()
        has_sensor = seg_id in segment_sensors

        if has_sensor:
            draw.rectangle(
                [left, top, right, bottom],
                outline=segment_with_sensor_outline,
                width=3,
                fill=(100, 200, 100, 80),
            )
        else:
            draw.rectangle(
                [left, top, right, bottom],
                outline=segment_outline,
                width=2,
            )

        # Segment ID at center-top of cell
        cx = (left + right) // 2
        cy_top = top + 4
        if seg_id:
            draw.text((cx - 10, cy_top), seg_id, fill=text_color, font=font_small)
            draw.text((cx - 11, cy_top - 1), seg_id, fill=text_outline_color, font=font_small)

        # Sensor label(s) below segment ID
        if has_sensor:
            sensors = segment_sensors[seg_id]
            for i, (stype, label) in enumerate(sensors[:2]):
                line = f"{stype}: {label[:20]}..." if len(label) > 20 else f"{stype}: {label}"
                y_off = cy_top + 14 + i * 12
                draw.text((left + 4, y_off), line, fill=text_color, font=font_small)
            if len(sensors) > 2:
                draw.text((left + 4, cy_top + 14 + 2 * 12), f"+{len(sensors)-2} more", fill=text_color, font=font_small)

    return img.convert("RGB")
