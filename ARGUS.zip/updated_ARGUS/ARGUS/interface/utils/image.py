from __future__ import annotations

import io
from pathlib import Path

from PIL import Image


def get_display_width(image_source) -> int:
    """
    Dynamically calculate display width based on image size.
    If the image is small, enlarge it; if large, shrink it.
    """
    try:
        # Handle different types of image sources
        if isinstance(image_source, (str, Path)):
            img = Image.open(image_source)
        elif hasattr(image_source, "read"):
            img = Image.open(image_source)
            # Reset file pointer so it can be read again later
            try:
                image_source.seek(0)
            except Exception:
                pass
        elif isinstance(image_source, (bytes, bytearray)):
            img = Image.open(io.BytesIO(image_source))
        else:
            return 400

        img_width = img.width

        # If image width is less than 400px, enlarge display
        if img_width < 400:
            return 1000
        elif img_width < 800:
            return 800
        else:
            return 600
    except Exception:
        # If unable to read image size, use default value
        return 400

