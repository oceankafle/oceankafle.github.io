"""
ArgusSense Interface module.
Used to implement the user interface.
"""

