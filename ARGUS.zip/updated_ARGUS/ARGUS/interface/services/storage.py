from __future__ import annotations

from typing import Dict, List, Any

from agent.utils import load_activity_analysis, save_activity_analysis


def load_constraints() -> Dict[str, Any]:
    """Load grounding constraints from shared activity_analysis.json."""
    data = load_activity_analysis()
    return data.get("constraints", {}) or {}


def save_constraints(constraints: Dict[str, Any]) -> None:
    """Save grounding constraints to shared activity_analysis.json."""
    data = load_activity_analysis()
    data["constraints"] = constraints
    save_activity_analysis(data)


def load_environment_info() -> Dict[str, List[str]]:
    data = load_activity_analysis()
    return data.get("environment_info", {}) or {}


def save_environment_info(environment_info: Dict[str, List[str]]) -> None:
    data = load_activity_analysis()
    data["environment_info"] = environment_info
    save_activity_analysis(data)


def save_activities(activities: list[dict[str, Any]]) -> None:
    data = load_activity_analysis()
    data["activities"] = activities
    save_activity_analysis(data)


def load_activities() -> list[dict[str, Any]]:
    data = load_activity_analysis()
    return data.get("activities", []) or []


def load_sensor_suggestions() -> list[dict[str, Any]]:
    """Load sensor suggestions from shared activity_analysis.json (from grounding)."""
    data = load_activity_analysis()
    return data.get("sensor_suggestions", []) or []


def save_sensor_suggestions(sensor_suggestions: list[dict[str, Any]]) -> None:
    """Save sensor suggestions to shared activity_analysis.json."""
    data = load_activity_analysis()
    data["sensor_suggestions"] = sensor_suggestions
    save_activity_analysis(data)


def load_deployment_grid() -> Dict[str, Any]:
    """Load deployment grid (from SegmentAgent) from shared activity_analysis.json."""
    data = load_activity_analysis()
    return data.get("deployment_grid", {}) or {}


def save_deployment_grid(grid: Dict[str, Any]) -> None:
    """Save deployment grid to shared activity_analysis.json."""
    data = load_activity_analysis()
    data["deployment_grid"] = grid
    save_activity_analysis(data)


def load_deployment_recommendations() -> list[dict[str, Any]]:
    """Load deployment recommendations from shared activity_analysis.json."""
    data = load_activity_analysis()
    return data.get("deployment_recommendations", []) or []


def save_deployment_recommendations(recommendations: list[dict[str, Any]]) -> None:
    """Save deployment recommendations to shared activity_analysis.json."""
    data = load_activity_analysis()
    data["deployment_recommendations"] = recommendations
    save_activity_analysis(data)


def load_evaluation_summary() -> Dict[str, Any]:
    """Load deterministic deployment evaluation metrics."""
    data = load_activity_analysis()
    return data.get("evaluation_summary", {}) or {}


def save_evaluation_summary(summary: Dict[str, Any]) -> None:
    """Save deterministic deployment evaluation metrics."""
    data = load_activity_analysis()
    data["evaluation_summary"] = summary
    save_activity_analysis(data)
