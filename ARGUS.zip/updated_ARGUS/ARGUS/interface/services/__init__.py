"""
Service layer for ARGUS Streamlit interface (IO, agents, etc.).
"""

