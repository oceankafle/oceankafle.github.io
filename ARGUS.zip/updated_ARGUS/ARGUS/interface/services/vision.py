from __future__ import annotations

from pathlib import Path
from typing import Dict, List

from agent.activity_analysis.vision_agent import VisionAgent


async def analyze_image(image_path: Path, vlm_name: str = "qwen") -> Dict[str, List[str]]:
    """Analyze image using Vision Agent."""
    agent = VisionAgent(vlm_name=vlm_name)
    try:
        result = await agent.analyze(
            image_path=image_path,
            temperature=0.7,
            max_tokens=2000,
        )
        return result
    finally:
        await agent.close()
