"""
Sensor Grounding page: layout mirrors Activity Analysis.
Left: manager chat (top) + sensor reasoning results (bottom).
Right: constraints from shared activity_analysis.json.
First entry: run reasoning (no constraints) and show results.
On manager message: update constraints in JSON, re-run reasoning, update results.
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

import streamlit as st

from interface.services.storage import (
    load_activities,
    load_constraints,
    save_constraints,
    save_sensor_suggestions,
)


def _run(coro):
    return asyncio.run(coro)


async def _sensor_reasoning_async(
    *,
    image_path: Path | None,
    constraints: dict[str, Any],
    llm_name: str,
) -> dict[str, Any]:
    """Run suggest + close in one event loop to avoid 'Event loop is closed' on close()."""
    from agent.sensor_grounding.sensor_suggestion_agent import SensorSuggestionAgent
    from agent.sensor_grounding.sensor_verifier_agent import SensorVerifierAgent

    suggestion_agent = SensorSuggestionAgent(llm_name=llm_name)
    try:
        suggestions = await suggestion_agent.suggest(
            constraints=constraints, temperature=0.7, max_tokens=8000
        )
    finally:
        await suggestion_agent.close()

    if not suggestions:
        return {"sensor_suggestions": [], "verified": False}

    if image_path and image_path.exists():
        verifier_agent = SensorVerifierAgent(vlm_name="nvidia")
        try:
            verified = await verifier_agent.verify(
                sensor_suggestions=suggestions,
                constraints=constraints,
                image_path=image_path,
                temperature=0.7,
                max_tokens=8000,
            )
            return {"sensor_suggestions": verified, "verified": True}
        finally:
            await verifier_agent.close()

    return {"sensor_suggestions": suggestions, "verified": False}


def _run_sensor_reasoning(
    *,
    image_path: Path | None,
    constraints: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Run sensor suggestion (and optional verification) using activity_analysis data."""
    if constraints is None:
        constraints = {}
    llm_name = st.session_state.get("chat_llm_name", "gemini")
    return _run(
        _sensor_reasoning_async(
            image_path=image_path,
            constraints=constraints,
            llm_name=llm_name,
        )
    )


def _init_grounding_chat_state() -> None:
    if "grounding_messages" not in st.session_state:
        st.session_state.grounding_messages = []
    if "last_grounding_result" not in st.session_state:
        st.session_state.last_grounding_result = None
    if "pending_grounding_user_text" not in st.session_state:
        st.session_state.pending_grounding_user_text = None


def _render_sensor_results(result: dict[str, Any] | None) -> None:
    """Display sensor suggestions / verified results in left column."""
    if result is None:
        st.caption("Sensor reasoning results will appear here.")
        return
    suggestions = result.get("sensor_suggestions") or []
    verified = result.get("verified", False)
    if not suggestions:
        st.info("No sensor suggestions generated for the current activity sequences.")
        return
    if verified:
        st.caption("Verified against floor plan; infeasible suggestions filtered out.")
    for item in suggestions:
        act_id = item.get("activity_id", "")
        desc = item.get("activity_description", "")
        sensors = item.get("behavior_sensors") or []
        with st.expander(f"Activity {act_id}: {desc}", expanded=True):
            if not sensors:
                st.caption("No sensor suggestions")
                continue
            for bs in sensors:
                st.markdown(
                    f"- **Behavior**: {bs.get('behavior', '')} → **Sensor**: {bs.get('sensor_type', '')} "
                    f"· Area: {bs.get('installation_area', '')} · Location: {bs.get('installation_location', '')}"
                )
                rationale = (bs.get("rationale") or "").strip()
                if rationale:
                    st.caption(f"  Rationale: {rationale}")
                if "feasible" in bs:
                    st.caption(f"  Feasible: {'Yes' if bs.get('feasible') else 'No'}")


def _render_constraints_panel(constraints: dict[str, Any]) -> None:
    """Display constraints in right column (from shared activity_analysis.json)."""
    st.markdown(
        "<h4 style='margin-bottom: 0.6rem;'>📋 Deployment Constraints</h4>",
        unsafe_allow_html=True,
    )
    st.caption("Constraints are saved to activity_analysis.json and used for sensor reasoning.")
    if not constraints:
        st.info("No constraints yet. Send a message to the manager (left) to set constraints.")
        return
    categories = [
        ("privacy", "Privacy"),
        ("budget", "Budget"),
        ("installation", "Installation"),
        ("coverage", "Coverage"),
        ("sensor_preferences", "Sensor preferences"),
        ("general_notes", "General notes"),
    ]
    for key, label in categories:
        val = constraints.get(key)
        if val is None:
            continue
        if isinstance(val, dict):
            with st.expander(f"**{label}**", expanded=True):
                st.json(val)
        elif isinstance(val, str) and val.strip():
            with st.expander(f"**{label}**", expanded=True):
                st.markdown(val)
        else:
            with st.expander(f"**{label}**", expanded=False):
                st.json(val)


def _render_grounding_chat(image_path: Path | None) -> None:
    """Left column top: manager chat. On send: update constraints, save to JSON, re-run reasoning."""
    _init_grounding_chat_state()

    st.markdown(
        "<h4 style='margin-bottom: 0.6rem;'>💬 Grounding Manager Chat</h4>",
        unsafe_allow_html=True,
    )
    st.caption("Describe deployment constraints (e.g. no sensors in bedroom, wireless only). Sending a message updates constraints and re-runs sensor reasoning.")

    chat_box = st.container(height=360, border=True)
    with chat_box:
        for m in reversed(st.session_state.grounding_messages):
            with st.chat_message(m.get("role", "assistant")):
                st.markdown(m.get("content", ""))

    pending = st.session_state.get("pending_grounding_user_text")
    if pending:
        try:
            from agent.sensor_grounding.grounding_manager_agent import GroundingManagerAgent

            async def _manager_then_reasoning():
                agent = GroundingManagerAgent(llm_name=st.session_state.get("chat_llm_name", "gemini"))
                try:
                    return await agent.analyze_constraints(
                        user_requirements=pending,
                        temperature=0.7,
                        max_tokens=8000,
                    )
                finally:
                    await agent.close()

            with st.spinner("Manager updating constraints and re-running sensor reasoning…"):
                manager_result = _run(_manager_then_reasoning())
                constraints = manager_result.get("constraints", {}) or {}
                save_constraints(constraints)
                result = _run_sensor_reasoning(
                    image_path=image_path,
                    constraints=constraints,
                )
                st.session_state.last_grounding_result = result
                save_sensor_suggestions(result.get("sensor_suggestions", []))
                reply = "Constraints updated and sensor reasoning re-run with new constraints."
                st.session_state.grounding_messages.append({"role": "assistant", "content": reply})
        except Exception as e:
            st.session_state.grounding_messages.append(
                {"role": "assistant", "content": f"Error: {e}"}
            )
        st.session_state.pending_grounding_user_text = None
        st.rerun()

    user_text = st.chat_input("Describe sensor deployment constraints…")
    if not user_text:
        return
    st.session_state.grounding_messages.append({"role": "user", "content": user_text})
    st.session_state.pending_grounding_user_text = user_text
    st.rerun()


def render_grounding_panel() -> None:
    """Layout: left = manager chat + results; right = constraints. First entry runs reasoning once."""
    if not st.session_state.get("environment_info"):
        st.info(
            "Complete **Activity Analysis** first (upload floor plan and analyze) to set environment info."
        )
        return

    activities = load_activities()
    activities_with_sequence = [a for a in activities if (a.get("sequence") or [])]
    if not activities_with_sequence:
        st.info(
            "Complete **Activity Analysis** and add activities with behavior sequences, then use \"Next step\" to come here for sensor reasoning."
        )
        return

    _init_grounding_chat_state()
    image_path = (
        Path(st.session_state.uploaded_image_path)
        if st.session_state.get("uploaded_image_path")
        else None
    )

    # First entry: run one pass without constraints, save result, then show layout
    if st.session_state.last_grounding_result is None:
        with st.spinner("Running initial sensor reasoning (no constraints)…"):
            try:
                result = _run_sensor_reasoning(image_path=image_path, constraints={})
                st.session_state.last_grounding_result = result
                save_sensor_suggestions(result.get("sensor_suggestions", []))
            except Exception as e:
                st.error(f"Initial reasoning failed: {e}")
                import traceback
                st.code(traceback.format_exc())
            else:
                st.rerun()
        return

    # Two columns: left = chat + results, right = constraints (like Activity Analysis)
    col_left, col_right = st.columns([1, 1])

    with col_left:
        _render_grounding_chat(image_path=image_path)
        st.markdown("---")
        st.markdown("**Sensor reasoning result**")
        _render_sensor_results(st.session_state.get("last_grounding_result"))

    with col_right:
        constraints = load_constraints()
        _render_constraints_panel(constraints)
