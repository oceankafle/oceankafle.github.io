from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Optional

import streamlit as st

from agent.activity_analysis.manager_agent import ManagerAgent
from interface.services.storage import save_environment_info as persist_environment_info
from interface.utils.normalize import normalize_environment_info


def _run(coro):
    return asyncio.run(coro)


def _init_chat_state() -> None:
    if "chat_messages" not in st.session_state:
        st.session_state.chat_messages = []
    if "chat_llm_name" not in st.session_state:
        st.session_state.chat_llm_name = "gemini"
    if "chat_debug" not in st.session_state:
        st.session_state.chat_debug = False
    if "last_activity_result" not in st.session_state:
        st.session_state.last_activity_result = None
    if "pending_user_text" not in st.session_state:
        st.session_state.pending_user_text = None
    if "pending_stage" not in st.session_state:
        # None | "manager_reply" | "update_pipeline"
        st.session_state.pending_stage = None
    if "pending_plan" not in st.session_state:
        st.session_state.pending_plan = None


def render_activity_analysis_chat(*, image_path: Optional[Path]) -> None:
    """
    Use Streamlit native chat UI (NO custom CSS):
    - st.chat_message for bubbles (user vs assistant)
    - st.chat_input for paper-plane send button / native style
    - st.container(height=..., border=True) for a scrollable chat area
    """
    _init_chat_state()

    st.markdown(
        "<h4 style='margin-bottom: 0.6rem;'>💬 Activity Analysis Chat</h4>",
        unsafe_allow_html=True,
    )

    # if not image_path:
    #     st.info(
    #         "Tip: You have not uploaded a floor plan yet. You can describe your needs first and I will give an action plan; after uploading an image I can generate/verify the activity sequence."
    #     )

    # Scrollable chat area (native)
    chat_box = st.container(height=360, border=True)
    with chat_box:
        # Newest messages at the top
        for m in reversed(st.session_state.chat_messages):
            with st.chat_message(m.get("role", "assistant")):
                st.markdown(m.get("content", ""))

    # Pending pipeline (two-stage) AFTER rendering chat_box
    pending = st.session_state.get("pending_user_text")
    stage = st.session_state.get("pending_stage")
    if pending and stage:
        agent = ManagerAgent(llm_name=st.session_state.chat_llm_name)
        try:
            if stage == "manager_reply":
                with st.spinner("Manager agent is generating a reply..."):
                    plan = _run(
                        agent.analyze(
                            user_input=pending,
                            temperature=0.7,
                            max_tokens=8000,
                            debug=bool(st.session_state.chat_debug),
                        )
                    )
                if plan.get("error"):
                    reply = f"Chat processing failed: {plan.get('error')}"
                    st.session_state.chat_messages.append(
                        {"role": "assistant", "content": reply}
                    )
                    st.session_state.last_activity_result = {"type": "plan", "plan": plan}
                    st.session_state.pending_user_text = None
                    st.session_state.pending_stage = None
                    st.session_state.pending_plan = None
                    st.rerun()

                reply = (plan.get("response") or "").strip() or "Analysis complete."
                st.session_state.chat_messages.append({"role": "assistant", "content": reply})
                st.session_state.pending_plan = plan

                # no image -> finish
                if not (image_path and image_path.exists()):
                    updated_env = plan.get("updated_environment_info")
                    if isinstance(updated_env, dict) and updated_env:
                        normalized = normalize_environment_info(updated_env)
                        st.session_state.environment_info = normalized
                        persist_environment_info(normalized)
                    st.session_state.last_activity_result = {"type": "plan", "plan": plan}
                    st.session_state.pending_user_text = None
                    st.session_state.pending_stage = None
                    st.session_state.pending_plan = None
                    st.rerun()

                st.session_state.pending_stage = "update_pipeline"
                st.rerun()

            if stage == "update_pipeline":
                plan = st.session_state.get("pending_plan") or {}
                with st.spinner(
                    "Analysis agent is analyzing and updating the activity list..."
                ):
                    updated_data = _run(
                        agent.process_and_update(
                            user_input=pending,
                            image_path=image_path,
                            temperature=0.7,
                            max_tokens=8000,
                            debug=bool(st.session_state.chat_debug),
                            return_intermediates=True,
                            plan_override=plan,
                        )
                    )

                if updated_data.get("error"):
                    st.error(f"Update failed: {updated_data.get('error')}")
                else:
                    if isinstance(updated_data.get("environment_info"), dict):
                        normalized = normalize_environment_info(updated_data["environment_info"])
                        st.session_state.environment_info = normalized
                        persist_environment_info(normalized)

                st.session_state.last_activity_result = {
                    "type": "updated",
                    "updated_data": updated_data,
                }
                st.session_state.pending_user_text = None
                st.session_state.pending_stage = None
                st.session_state.pending_plan = None
                st.rerun()
        finally:
            try:
                _run(agent.close())
            except Exception:
                pass

    # Native chat input (paper-plane button)
    user_text = st.chat_input(
        "Describe the activity (e.g., I want to detect an elder cooking in the kitchen)."
    )
    if not user_text:
        return

    st.session_state.chat_messages.append({"role": "user", "content": user_text})
    st.session_state.pending_user_text = user_text
    st.session_state.pending_stage = "manager_reply"
    st.session_state.pending_plan = None
    st.rerun()

