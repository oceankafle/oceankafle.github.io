"""
ARGUS Interactive Interface (Streamlit)
Environment info management + activity analysis chat.
"""

from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st

# Add project root directory to path (so `agent/`, `prompt/`, `interface/` are importable)
repo_root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(repo_root))

from interface.services.storage import load_environment_info, save_environment_info
from interface.ui.chat_panel import render_activity_analysis_chat
from interface.ui.activity_results import render_activity_results
from interface.ui.image_panel import render_image_panel
from interface.ui.room_editor import render_room_editor
from interface.ui.grounding_panel import render_grounding_panel
from interface.ui.deployment_panel import render_deployment_panel
from interface.ui.sidebar import (
    PAGE_ACTIVITY_ANALYSIS,
    PAGE_SENSOR_GROUNDING,
    PAGE_SENSOR_DEPLOYMENT,
    render_sidebar_summary,
)
from interface.ui.styles import configure_page, inject_css
from interface.utils.normalize import normalize_environment_info

configure_page()
inject_css()


def _init_session_state() -> None:
    if "environment_info" not in st.session_state:
        loaded_env = load_environment_info() or {}
        normalized_env = normalize_environment_info(loaded_env)
        st.session_state.environment_info = normalized_env
        if normalized_env != loaded_env:
            save_environment_info(normalized_env)

    if "uploaded_image_path" not in st.session_state:
        st.session_state.uploaded_image_path = None

    if "analysis_result" not in st.session_state:
        st.session_state.analysis_result = None


def _render_step_header() -> None:
    st.markdown("### Define the activity goal")
    st.caption(
        "ARGUS will analyze your request and break it into actions, objects, "
        "and spatial context."
    )


_init_session_state()

st.title("🏠 ARGUS")

current_page = render_sidebar_summary()

if current_page == PAGE_ACTIVITY_ANALYSIS:
    _render_step_header()

    with st.expander("Environment setup (optional)", expanded=False):
        col_env_left, col_env_right = st.columns([1, 1])

        with col_env_left:
            render_image_panel()

        with col_env_right:
            render_room_editor()

    st.markdown("### Describe the activity")
    image_path = (
        Path(st.session_state.uploaded_image_path)
        if st.session_state.get("uploaded_image_path")
        else None
    )
    render_activity_analysis_chat(image_path=image_path)

    st.markdown("---")
    st.markdown("### 🧠 ARGUS Activity Understanding")
    st.caption(
    "ARGUS decomposes your request into structured activities grounded in the environment."
    )
    render_activity_results()

elif current_page == PAGE_SENSOR_GROUNDING:
    st.markdown("## Step 2: Sensor Grounding")
    st.caption("Review the activity sequence and generate sensor suggestions.")
    st.markdown("---")
    render_grounding_panel()

else:
    st.markdown("## Step 3: Sensor Deployment")
    st.caption("Use the grounded sensors to build a deployment plan.")
    st.markdown("---")
    render_deployment_panel()

st.markdown("---")
st.markdown(
    "<div style='text-align: center; color: gray;'>"
    "ARGUS - Automated Sensor Deployment System | Environment Information Management Interface"
    "</div>",
    unsafe_allow_html=True,
)